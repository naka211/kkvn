-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2015 at 08:57 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kkvn`
--

-- --------------------------------------------------------

--
-- Table structure for table `analk_assets`
--

CREATE TABLE IF NOT EXISTS `analk_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_asset_name` (`name`),
  KEY `idx_lft_rgt` (`lft`,`rgt`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=173 ;

--
-- Dumping data for table `analk_assets`
--

INSERT INTO `analk_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 0, 307, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":{"6":1},"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 16, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 17, 44, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.options":[],"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 45, 46, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 47, 48, 1, 'com_installer', 'com_installer', '{"core.admin":[],"core.manage":{"7":0},"core.delete":{"7":0},"core.edit.state":{"7":0}}'),
(11, 1, 49, 50, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 51, 52, 1, 'com_login', 'com_login', '{}'),
(13, 1, 53, 54, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 55, 56, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 57, 58, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 59, 60, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 61, 62, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 63, 118, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(20, 1, 119, 120, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 121, 122, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(23, 1, 123, 124, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 125, 128, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.options":[],"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(26, 1, 129, 130, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 18, 25, 2, 'com_content.category.2', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 24, 126, 127, 1, 'com_users.category.7', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(34, 1, 131, 132, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(35, 1, 133, 134, 1, 'com_tags', 'com_tags', '{"core.admin":[],"core.manage":[],"core.manage":[],"core.delete":[],"core.edit.state":[]}'),
(36, 1, 135, 136, 1, 'com_contenthistory', 'com_contenthistory', '{}'),
(37, 1, 137, 138, 1, 'com_ajax', 'com_ajax', '{}'),
(38, 1, 139, 140, 1, 'com_postinstall', 'com_postinstall', '{}'),
(39, 18, 64, 65, 2, 'com_modules.module.1', 'Main Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"module.edit.frontend":[]}'),
(40, 18, 66, 67, 2, 'com_modules.module.2', 'Login', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(41, 18, 68, 69, 2, 'com_modules.module.3', 'Popular Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(42, 18, 70, 71, 2, 'com_modules.module.4', 'Recently Added Articles', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(43, 18, 72, 73, 2, 'com_modules.module.8', 'Toolbar', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(44, 18, 74, 75, 2, 'com_modules.module.9', 'Quick Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(45, 18, 76, 77, 2, 'com_modules.module.10', 'Logged-in Users', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(46, 18, 78, 79, 2, 'com_modules.module.12', 'Admin Menu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(47, 18, 80, 81, 2, 'com_modules.module.13', 'Admin Submenu', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(48, 18, 82, 83, 2, 'com_modules.module.14', 'User Status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(49, 18, 84, 85, 2, 'com_modules.module.15', 'Title', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 18, 86, 87, 2, 'com_modules.module.16', 'Login Form', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 18, 88, 89, 2, 'com_modules.module.17', 'Breadcrumbs', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"module.edit.frontend":[]}'),
(52, 18, 90, 91, 2, 'com_modules.module.79', 'Multilanguage status', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 18, 92, 93, 2, 'com_modules.module.86', 'Joomla Version', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(54, 18, 94, 95, 2, 'com_modules.module.87', 'JoomGallery News', ''),
(55, 1, 141, 300, 1, 'com_joomgallery', 'JoomGallery', '{"core.admin":[],"core.manage":[],"joom.upload":{"2":1},"joom.upload.inown":[],"core.create":[],"joom.create.inown":{"2":1},"core.delete":{"2":1},"core.edit":{"2":1},"core.edit.state":{"2":1},"core.edit.own":{"2":1}}'),
(59, 27, 19, 20, 3, 'com_content.article.1', 'Giới thiệu', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(60, 55, 142, 157, 2, 'com_joomgallery.category.4', 'Thắng cảnh', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(65, 1, 301, 302, 1, 'com_recharge', 'com_recharge', '{}'),
(66, 1, 303, 304, 1, 'com_orders', 'com_orders', '{}'),
(67, 60, 143, 144, 3, 'com_joomgallery.image.3', 'Thắng cảnh thumb', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(68, 60, 145, 146, 3, 'com_joomgallery.image.4', 'Hình 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(69, 60, 147, 148, 3, 'com_joomgallery.image.5', 'Hình 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(70, 55, 158, 171, 2, 'com_joomgallery.category.5', 'Con người', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(71, 70, 159, 160, 3, 'com_joomgallery.image.6', 'Con người thumb', ''),
(72, 55, 172, 185, 2, 'com_joomgallery.category.6', 'Biển cả - Núi rừng', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(73, 55, 186, 201, 2, 'com_joomgallery.category.7', 'Hoa', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(74, 72, 173, 174, 3, 'com_joomgallery.image.7', 'Biển cả thumb', ''),
(75, 73, 187, 188, 3, 'com_joomgallery.image.8', 'Hoa thumb', ''),
(76, 60, 149, 150, 3, 'com_joomgallery.image.9', 'Hình 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(77, 70, 161, 162, 3, 'com_joomgallery.image.10', 'Con người 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(78, 70, 163, 164, 3, 'com_joomgallery.image.11', 'Con người 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(79, 73, 189, 190, 3, 'com_joomgallery.image.12', 'Hoa 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(80, 73, 191, 192, 3, 'com_joomgallery.image.13', 'Hoa 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(81, 73, 193, 194, 3, 'com_joomgallery.image.14', 'Hoa 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(82, 72, 175, 176, 3, 'com_joomgallery.image.15', 'Biển cả 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(83, 72, 177, 178, 3, 'com_joomgallery.image.16', 'Biển cả 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(84, 72, 179, 180, 3, 'com_joomgallery.image.17', 'Biển cả 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(87, 18, 96, 97, 2, 'com_modules.module.91', 'JoomSearch', ''),
(88, 55, 202, 215, 2, 'com_joomgallery.category.8', 'Tình yêu', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(89, 88, 203, 204, 3, 'com_joomgallery.image.18', 'Tình yêu thumb', ''),
(90, 55, 216, 229, 2, 'com_joomgallery.category.9', 'Đất nước đổi mới', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(91, 90, 217, 218, 3, 'com_joomgallery.image.19', 'Đất nước đổi mới thumb', ''),
(92, 55, 230, 243, 2, 'com_joomgallery.category.10', 'Thể thao', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(93, 55, 244, 257, 2, 'com_joomgallery.category.11', 'Ẩm thực', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(94, 55, 258, 271, 2, 'com_joomgallery.category.12', 'Sáng tạo - nghệ thuật', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(95, 55, 272, 285, 2, 'com_joomgallery.category.13', 'Động vật', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(96, 55, 286, 299, 2, 'com_joomgallery.category.14', 'Chủ đề khác', '{"joom.upload":[],"joom.upload.inown":[],"core.create":{"6":1,"3":1},"joom.create.inown":[],"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(97, 92, 231, 232, 3, 'com_joomgallery.image.20', 'Thể thao thumb', ''),
(98, 93, 245, 246, 3, 'com_joomgallery.image.21', 'Ẩm thực thumb', ''),
(99, 94, 259, 260, 3, 'com_joomgallery.image.22', 'Sáng tạo nghệ thuật thumb', ''),
(100, 95, 273, 274, 3, 'com_joomgallery.image.23', 'Động vật thumb', ''),
(101, 96, 287, 288, 3, 'com_joomgallery.image.24', 'Chủ đề khác thumb', ''),
(102, 60, 151, 152, 3, 'com_joomgallery.image.25', 'Thắng cảnh 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(103, 60, 153, 154, 3, 'com_joomgallery.image.26', 'Thắng cảnh 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(104, 70, 165, 166, 3, 'com_joomgallery.image.27', 'Con người 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(105, 70, 167, 168, 3, 'com_joomgallery.image.28', 'Con người 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(106, 70, 169, 170, 3, 'com_joomgallery.image.29', 'Con người 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(107, 72, 181, 182, 3, 'com_joomgallery.image.30', 'Núi rừng 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(108, 72, 183, 184, 3, 'com_joomgallery.image.31', 'Núi rừng 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(109, 73, 195, 196, 3, 'com_joomgallery.image.32', 'Hoa 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(110, 73, 197, 198, 3, 'com_joomgallery.image.33', 'Hoa 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(111, 88, 205, 206, 3, 'com_joomgallery.image.34', 'Tình yêu 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(112, 88, 207, 208, 3, 'com_joomgallery.image.35', 'Tình yêu 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(113, 88, 209, 210, 3, 'com_joomgallery.image.36', 'Tình yêu 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(114, 88, 211, 212, 3, 'com_joomgallery.image.37', 'Tình yêu 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(115, 88, 213, 214, 3, 'com_joomgallery.image.38', 'Tình yêu 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(116, 90, 219, 220, 3, 'com_joomgallery.image.39', 'Đất nước 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(117, 90, 221, 222, 3, 'com_joomgallery.image.40', 'Đất nước 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(118, 90, 223, 224, 3, 'com_joomgallery.image.41', 'Đất nước 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(119, 90, 225, 226, 3, 'com_joomgallery.image.42', 'Đất nước 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(120, 90, 227, 228, 3, 'com_joomgallery.image.43', 'Đất nước 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(121, 92, 233, 234, 3, 'com_joomgallery.image.44', 'Thể thao 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(122, 92, 235, 236, 3, 'com_joomgallery.image.45', 'Thể thao 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(123, 92, 237, 238, 3, 'com_joomgallery.image.46', 'Thể thao 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(124, 92, 239, 240, 3, 'com_joomgallery.image.47', 'Thể thao 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(125, 92, 241, 242, 3, 'com_joomgallery.image.48', 'Thể thao 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(126, 93, 247, 248, 3, 'com_joomgallery.image.49', 'Ẩm thực 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(127, 93, 249, 250, 3, 'com_joomgallery.image.50', 'Ẩm thực 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(128, 93, 251, 252, 3, 'com_joomgallery.image.51', 'Ẩm thực 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(129, 93, 253, 254, 3, 'com_joomgallery.image.52', 'Ẩm thực 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(130, 93, 255, 256, 3, 'com_joomgallery.image.53', 'Ẩm thực 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(131, 94, 261, 262, 3, 'com_joomgallery.image.54', 'Sáng tạo 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(132, 94, 263, 264, 3, 'com_joomgallery.image.55', 'Sáng tạo 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(133, 94, 265, 266, 3, 'com_joomgallery.image.56', 'Sáng tạo 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(134, 94, 267, 268, 3, 'com_joomgallery.image.57', 'Sáng tạo 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(135, 94, 269, 270, 3, 'com_joomgallery.image.58', 'Sáng tạo 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(136, 95, 275, 276, 3, 'com_joomgallery.image.59', 'Động vật 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(137, 95, 277, 278, 3, 'com_joomgallery.image.60', 'Động vật 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(138, 95, 279, 280, 3, 'com_joomgallery.image.61', 'Động vật 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(139, 95, 281, 282, 3, 'com_joomgallery.image.62', 'Động vật 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(140, 95, 283, 284, 3, 'com_joomgallery.image.63', 'Động vật 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(141, 96, 289, 290, 3, 'com_joomgallery.image.64', 'Khác 1', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(142, 96, 291, 292, 3, 'com_joomgallery.image.65', 'Khác 2', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(143, 96, 293, 294, 3, 'com_joomgallery.image.66', 'Khác 3', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(144, 96, 295, 296, 3, 'com_joomgallery.image.67', 'Khác 4', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(145, 96, 297, 298, 3, 'com_joomgallery.image.68', 'Khác 5', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(146, 8, 26, 33, 2, 'com_content.category.8', 'Tin tức', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(147, 146, 27, 28, 3, 'com_content.article.2', 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(148, 146, 29, 30, 3, 'com_content.article.3', 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh (2)', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(149, 146, 31, 32, 3, 'com_content.article.4', 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh (3)', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(150, 18, 98, 99, 2, 'com_modules.module.92', 'Tin tức', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(151, 8, 34, 43, 2, 'com_content.category.9', 'Thông tin', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(152, 151, 35, 36, 3, 'com_content.article.5', 'Mua tác phẩm', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(153, 151, 37, 38, 3, 'com_content.article.6', 'Bản quyền tác phẩm', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(154, 151, 39, 40, 3, 'com_content.article.7', 'Thanh toán online', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(155, 151, 41, 42, 3, 'com_content.article.8', 'Quy định', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(156, 18, 100, 101, 2, 'com_modules.module.93', 'Thông tin', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(157, 18, 102, 103, 2, 'com_modules.module.94', 'Bảo trợ bởi', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(158, 18, 104, 105, 2, 'com_modules.module.95', 'Liên hệ', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(159, 27, 21, 22, 3, 'com_content.article.9', 'Thông tin cuối trang', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(160, 18, 106, 107, 2, 'com_modules.module.96', 'Tác phẩm chọn lọc', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(161, 18, 108, 109, 2, 'com_modules.module.97', 'Tác phẩm mới', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(162, 18, 110, 111, 2, 'com_modules.module.98', 'Tác phẩm đang được yêu thích nhất', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(164, 60, 155, 156, 3, 'com_joomgallery.image.70', 'Thắng cảnh 6', '{"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(165, 18, 112, 113, 2, 'com_modules.module.99', 'Thành viên mới', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(166, 73, 199, 200, 3, 'com_joomgallery.image.71', 'Hoa nghệ thuật', ''),
(168, 27, 23, 24, 3, 'com_content.article.10', 'Cám ơn đã theo dõi', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(170, 18, 114, 115, 2, 'com_modules.module.100', 'Newsletter', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}'),
(171, 1, 305, 306, 1, 'com_jnews', 'jNews', '{}'),
(172, 18, 116, 117, 2, 'com_modules.module.101', 'UserMenu', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"module.edit.frontend":[]}');

-- --------------------------------------------------------

--
-- Table structure for table `analk_associations`
--

CREATE TABLE IF NOT EXISTS `analk_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_banners`
--

CREATE TABLE IF NOT EXISTS `analk_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_banner_clients`
--

CREATE TABLE IF NOT EXISTS `analk_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_banner_tracks`
--

CREATE TABLE IF NOT EXISTS `analk_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_categories`
--

CREATE TABLE IF NOT EXISTS `analk_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `analk_categories`
--

INSERT INTO `analk_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES
(1, 0, 0, 0, 15, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '{}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 9, 10, 1, 'uncategorised', 'com_users', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 42, '2011-01-01 00:00:01', 0, '0000-00-00 00:00:00', 0, '*', 1),
(8, 146, 1, 11, 12, 1, 'tin-tuc', 'com_content', 'Tin tức', 'tin-tuc', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","image_alt":""}', '', '', '{"author":"","robots":""}', 468, '2015-08-14 08:04:44', 0, '2015-08-14 08:04:44', 0, '*', 1),
(9, 151, 1, 13, 14, 1, 'thong-tin', 'com_content', 'Thông tin', 'thong-tin', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":"","image_alt":""}', '', '', '{"author":"","robots":""}', 468, '2015-08-17 06:32:56', 0, '2015-08-17 06:32:56', 0, '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table `analk_contact_details`
--

CREATE TABLE IF NOT EXISTS `analk_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_content`
--

CREATE TABLE IF NOT EXISTS `analk_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `analk_content`
--

INSERT INTO `analk_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 59, 'Giới thiệu', 'khoanh-khac', '<p>In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.</p>', '', 1, 2, '2015-08-05 04:59:24', 468, '', '2015-08-14 08:16:21', 468, 0, '0000-00-00 00:00:00', '2015-08-05 04:59:24', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 2, '', '', 1, 17, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(2, 147, 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh', 'da-nang-trip-du-lich-ket-hop-chup-anh', 'In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br />', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', 1, 8, '2015-08-14 08:18:48', 468, '', '2015-08-14 08:19:34', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 3, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(3, 148, 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh (2)', 'da-nang-trip-du-lich-ket-hop-chup-anh-2', 'In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br />', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', 1, 8, '2015-08-14 08:18:48', 468, '', '2015-08-14 08:19:44', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 2, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(4, 149, 'Đà Nẵng Trip- Du lịch kết hợp chụp ảnh (3)', 'da-nang-trip-du-lich-ket-hop-chup-anh-3', 'In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br />', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', 1, 8, '2015-08-14 08:18:48', 468, '', '2015-08-14 08:19:53', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 3, 1, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(5, 152, 'Mua tác phẩm', 'mua-tac-pham', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', '', 1, 9, '2015-08-14 08:18:48', 468, '', '2015-08-17 06:33:54', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 3, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(6, 153, 'Bản quyền tác phẩm', 'ban-quyen-tac-pham', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', '', 1, 9, '2015-08-14 08:18:48', 468, '', '2015-08-17 06:34:21', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 2, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(7, 154, 'Thanh toán online', 'thanh-toan-online', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', '', 1, 9, '2015-08-14 08:18:48', 468, '', '2015-08-17 06:34:44', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(8, 155, 'Quy định', 'quy-dinh', 'Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br /><br /> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.', '', 1, 9, '2015-08-14 08:18:48', 468, '', '2015-08-17 06:35:01', 468, 0, '0000-00-00 00:00:00', '2015-08-14 08:18:48', '0000-00-00 00:00:00', '{"image_intro":"images\\/2.jpg","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 2, 0, '', '', 1, 1, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(9, 159, 'Thông tin cuối trang', 'thong-tin-cuoi-trang', 'Bản quyền thuộc về Hội Truyền Thông Số Việt Nam. Giấy phép cung cấp mạng xã hội trực tuyến số 43/GXN - TTĐT.<br /> Giấy phép tổ chức thi tác phẩm nhiếp ảnh "Khoảnh khắc Việt Nam" số 152/MTNATL-NA ban hành ngày 05/4/2013.<br /> Chịu trách nhiệm nội dung: Ông Nguyễn Lâm Thanh - Tổng thư ký', '', 1, 2, '2015-08-17 06:48:53', 468, '', '2015-08-17 06:48:53', 0, 0, '0000-00-00 00:00:00', '2015-08-17 06:48:53', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 1, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(10, 168, 'Cám ơn đã theo dõi', 'cam-on-da-theo-doi', 'Chúng tôi đã lưu email của bạn, cám ơn bạn đã theo dõi<br /><br />Khoảnh khắc Việt Nam', '', 1, 2, '2015-09-13 17:57:45', 468, '', '2015-09-13 17:57:45', 0, 0, '0000-00-00 00:00:00', '2015-09-13 17:57:45', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 1, 0, '', '', 1, 6, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_contentitem_tag_map`
--

CREATE TABLE IF NOT EXISTS `analk_contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_tag` (`tag_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';

-- --------------------------------------------------------

--
-- Table structure for table `analk_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `analk_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_content_rating`
--

CREATE TABLE IF NOT EXISTS `analk_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_content_types`
--

CREATE TABLE IF NOT EXISTS `analk_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) DEFAULT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `analk_content_types`
--

INSERT INTO `analk_content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES
(1, 'Article', 'com_content.article', '{"special":{"dbtable":"#__content","key":"id","type":"Content","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"introtext", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"attribs", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"asset_id"}, "special":{"fulltext":"fulltext"}}', 'ContentHelperRoute::getArticleRoute', '{"formFile":"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml", "hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(2, 'Contact', 'com_contact.contact', '{"special":{"dbtable":"#__contact_details","key":"id","type":"Contact","prefix":"ContactTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"address", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"image", "core_urls":"webpage", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"con_position":"con_position","suburb":"suburb","state":"state","country":"country","postcode":"postcode","telephone":"telephone","fax":"fax","misc":"misc","email_to":"email_to","default_con":"default_con","user_id":"user_id","mobile":"mobile","sortname1":"sortname1","sortname2":"sortname2","sortname3":"sortname3"}}', 'ContactHelperRoute::getContactRoute', '{"formFile":"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml","hideFields":["default_con","checked_out","checked_out_time","version","xreference"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[ {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ] }'),
(3, 'Newsfeed', 'com_newsfeeds.newsfeed', '{"special":{"dbtable":"#__newsfeeds","key":"id","type":"Newsfeed","prefix":"NewsfeedsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"numarticles":"numarticles","cache_time":"cache_time","rtl":"rtl"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{"formFile":"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml","hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(4, 'User', 'com_users.user', '{"special":{"dbtable":"#__users","key":"id","type":"User","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"null","core_alias":"username","core_created_time":"registerdate","core_modified_time":"lastvisitDate","core_body":"null", "core_hits":"null","core_publish_up":"null","core_publish_down":"null","access":"null", "core_params":"params", "core_featured":"null", "core_metadata":"null", "core_language":"null", "core_images":"null", "core_urls":"null", "core_version":"null", "core_ordering":"null", "core_metakey":"null", "core_metadesc":"null", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{}}', 'UsersHelperRoute::getUserRoute', ''),
(5, 'Article Category', 'com_content.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContentHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(6, 'Contact Category', 'com_contact.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContactHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(7, 'Newsfeeds Category', 'com_newsfeeds.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(8, 'Tag', 'com_tags.tag', '{"special":{"dbtable":"#__tags","key":"tag_id","type":"Tag","prefix":"TagsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path"}}', 'TagsHelperRoute::getTagRoute', '{"formFile":"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml", "hideFields":["checked_out","checked_out_time","version", "lft", "rgt", "level", "path", "urls", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(9, 'Banner', 'com_banners.banner', '{"special":{"dbtable":"#__banners","key":"id","type":"Banner","prefix":"BannersTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"null","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"null", "asset_id":"null"}, "special":{"imptotal":"imptotal", "impmade":"impmade", "clicks":"clicks", "clickurl":"clickurl", "custombannercode":"custombannercode", "cid":"cid", "purchase_type":"purchase_type", "track_impressions":"track_impressions", "track_clicks":"track_clicks"}}', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml", "hideFields":["checked_out","checked_out_time","version", "reset"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "imptotal", "impmade", "reset"], "convertToInt":["publish_up", "publish_down", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"cid","targetTable":"#__banner_clients","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(10, 'Banners Category', 'com_banners.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special": {"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(11, 'Banner Client', 'com_banners.client', '{"special":{"dbtable":"#__banner_clients","key":"id","type":"Client","prefix":"BannersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml", "hideFields":["checked_out","checked_out_time"], "ignoreChanges":["checked_out", "checked_out_time"], "convertToInt":[], "displayLookup":[]}'),
(12, 'User Notes', 'com_users.note', '{"special":{"dbtable":"#__user_notes","key":"id","type":"Note","prefix":"UsersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml", "hideFields":["checked_out","checked_out_time", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time"], "convertToInt":["publish_up", "publish_down"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(13, 'User Notes Category', 'com_users.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `analk_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `analk_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_extensions`
--

CREATE TABLE IF NOT EXISTS `analk_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10068 ;

--
-- Dumping data for table `analk_extensions`
--

INSERT INTO `analk_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MAILTO_XML_DESCRIPTION","group":"","filename":"mailto"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":"","filename":"wrapper"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_BANNERS_XML_DESCRIPTION","group":"","filename":"banners"}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":"","save_history":"1","history_limit":10}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTACT_XML_DESCRIPTION","group":"","filename":"contact"}', '{"show_contact_category":"hide","save_history":"1","history_limit":10,"show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","allow_vcard_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_category_crumb":"0","metakey":"","metadesc":"","robots":"","author":"","rights":"","xreference":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"vi-VN","site":"vi-VN"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MEDIA_XML_DESCRIPTION","group":"","filename":"media"}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{"template_positions_display":"0","upload_limit":"2","image_formats":"gif,bmp,jpg,jpeg,png","source_formats":"txt,less,ini,xml,js,php,css","font_formats":"woff,ttf,otf","compressed_formats":"zip"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","info_block_position":"0","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"0","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_tags":"1","show_icons":"1","show_print_icon":"1","show_email_icon":"1","show_hits":"1","show_noauth":"0","urls_position":"0","show_publishing_options":"1","show_article_options":"1","save_history":"1","history_limit":10,"show_urls_images_frontend":"0","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"left","float_fulltext":"left","category_layout":"_:blog","show_category_heading_title_text":"1","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_cat_tags":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"0","num_intro_articles":"5","num_columns":"0","num_links":"0","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_featured":"show","show_feed_link":"1","feed_summary":"0","feed_show_readmore":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"9":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"NONE","filter_tags":"","filter_attributes":""},"2":{"filter_type":"NH","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_USERS_XML_DESCRIPTION","group":"","filename":"users"}', '{"allowUserRegistration":"1","new_usertype":"2","guest_usergroup":"9","sendpassword":"1","useractivation":"0","mail_to_admin":"0","captcha":"","frontend_userparams":"1","site_language":"0","change_login_name":"0","reset_count":"10","reset_time":"1","minimum_length":"4","minimum_integers":"0","minimum_symbols":"0","minimum_uppercase":"0","save_history":"1","history_limit":5,"mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{"name":"com_tags","type":"component","creationDate":"December 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"COM_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '{"tag_layout":"_:default","save_history":"1","history_limit":5,"show_tag_title":"0","tag_list_show_tag_image":"0","tag_list_show_tag_description":"0","tag_list_image":"","show_tag_num_items":"0","tag_list_orderby":"title","tag_list_orderby_direction":"ASC","show_headings":"0","tag_list_show_date":"0","tag_list_show_item_image":"0","tag_list_show_item_description":"0","tag_list_item_maximum_characters":0,"return_any_or_all":"1","include_children":"0","maximum":200,"tag_list_language_filter":"all","tags_layout":"_:default","all_tags_orderby":"title","all_tags_orderby_direction":"ASC","all_tags_show_tag_image":"0","all_tags_show_tag_descripion":"0","all_tags_tag_maximum_characters":20,"all_tags_show_tag_hits":"0","filter_field":"1","show_pagination_limit":"1","show_pagination":"2","show_pagination_results":"1","tag_field_ajax_mode":"1","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(30, 'com_contenthistory', 'component', 'com_contenthistory', '', 1, 1, 1, 0, '{"name":"com_contenthistory","type":"component","creationDate":"May 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_CONTENTHISTORY_XML_DESCRIPTION","group":"","filename":"contenthistory"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(31, 'com_ajax', 'component', 'com_ajax', '', 1, 1, 1, 0, '{"name":"com_ajax","type":"component","creationDate":"August 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_AJAX_XML_DESCRIPTION","group":"","filename":"ajax"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(32, 'com_postinstall', 'component', 'com_postinstall', '', 1, 1, 1, 1, '{"name":"com_postinstall","type":"component","creationDate":"September 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"COM_POSTINSTALL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":"","filename":"simplepie"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":"","filename":"phputf8"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"13.1","description":"LIB_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '{"mediaversion":"4892fc7771044d3dee35ee76a041e02d"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(104, 'IDNA Convert', 'library', 'idna_convert', '', 0, 1, 1, 1, '{"name":"IDNA Convert","type":"library","creationDate":"2004","author":"phlyLabs","copyright":"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de","authorEmail":"phlymail@phlylabs.de","authorUrl":"http:\\/\\/phlylabs.de","version":"0.8.0","description":"LIB_IDNA_XML_DESCRIPTION","group":"","filename":"idna_convert"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(105, 'FOF', 'library', 'fof', '', 0, 1, 1, 1, '{"name":"FOF","type":"library","creationDate":"2015-04-22 13:15:32","author":"Nicholas K. Dionysopoulos \\/ Akeeba Ltd","copyright":"(C)2011-2015 Nicholas K. Dionysopoulos","authorEmail":"nicholas@akeebabackup.com","authorUrl":"https:\\/\\/www.akeebabackup.com","version":"2.4.3","description":"LIB_FOF_XML_DESCRIPTION","group":"","filename":"fof"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(106, 'PHPass', 'library', 'phpass', '', 0, 1, 1, 1, '{"name":"PHPass","type":"library","creationDate":"2004-2006","author":"Solar Designer","copyright":"","authorEmail":"solar@openwall.com","authorUrl":"http:\\/\\/www.openwall.com\\/phpass\\/","version":"0.3","description":"LIB_PHPASS_XML_DESCRIPTION","group":"","filename":"phpass"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":"","filename":"mod_articles_archive"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":"","filename":"mod_articles_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_articles_popular"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":"","filename":"mod_banners"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":"","filename":"mod_breadcrumbs"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":"","filename":"mod_custom"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":"","filename":"mod_feed"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":"","filename":"mod_footer"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":"","filename":"mod_login"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":"","filename":"mod_menu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":"","filename":"mod_articles_news"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":"","filename":"mod_random_image"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_RELATED_XML_DESCRIPTION","group":"","filename":"mod_related_items"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":"","filename":"mod_search"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":"","filename":"mod_stats"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":"","filename":"mod_syndicate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":"","filename":"mod_users_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":"","filename":"mod_whosonline"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":"","filename":"mod_wrapper"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":"","filename":"mod_articles_category"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":"","filename":"mod_articles_categories"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":"","filename":"mod_languages"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '{"name":"mod_finder","type":"module","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FINDER_XML_DESCRIPTION","group":"","filename":"mod_finder"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":"","filename":"mod_custom"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_FEED_XML_DESCRIPTION","group":"","filename":"mod_feed"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LATEST_XML_DESCRIPTION","group":"","filename":"mod_latest"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":"","filename":"mod_logged"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":"","filename":"mod_login"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MENU_XML_DESCRIPTION","group":"","filename":"mod_menu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_popular"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":"","filename":"mod_quickicon"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATUS_XML_DESCRIPTION","group":"","filename":"mod_status"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":"","filename":"mod_submenu"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TITLE_XML_DESCRIPTION","group":"","filename":"mod_title"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":"","filename":"mod_toolbar"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":"","filename":"mod_multilangstatus"}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 0, 1, 0, '{"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_VERSION_XML_DESCRIPTION","group":"","filename":"mod_version"}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{"name":"mod_stats_admin","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":"","filename":"mod_stats_admin"}', '{"serverinfo":"0","siteinfo":"0","counter":"0","increase":"0","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{"name":"mod_tags_popular","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_POPULAR_XML_DESCRIPTION","group":"","filename":"mod_tags_popular"}', '{"maximum":"5","timeframe":"alltime","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{"name":"mod_tags_similar","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_SIMILAR_XML_DESCRIPTION","group":"","filename":"mod_tags_similar"}', '{"maximum":"5","matchtype":"any","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":"","filename":"gmail"}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LDAP_XML_DESCRIPTION","group":"","filename":"ldap"}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(403, 'plg_content_contact', 'plugin', 'contact', 'content', 0, 1, 1, 0, '{"name":"plg_content_contact","type":"plugin","creationDate":"January 2014","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.2","description":"PLG_CONTENT_CONTACT_XML_DESCRIPTION","group":"","filename":"contact"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":"","filename":"emailcloak"}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":"","filename":"loadmodule"}', '{"style":"xhtml"}', '', '', 0, '2011-09-18 15:22:50', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":"","filename":"pagebreak"}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 1, 1, 0, '{"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":"","filename":"pagenavigation"}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 0, '{"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_VOTE_XML_DESCRIPTION","group":"","filename":"vote"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"Copyright (C) 2014 by Marijn Haverbeke <marijnh@gmail.com> and others","authorEmail":"marijnh@gmail.com","authorUrl":"http:\\/\\/codemirror.net\\/","version":"5.3","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":"","filename":"codemirror"}', '{"lineNumbers":"1","lineWrapping":"1","matchTags":"1","matchBrackets":"1","marker-gutter":"1","autoCloseTags":"1","autoCloseBrackets":"1","autoFocus":"1","theme":"default","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"name":"plg_editors_none","type":"plugin","creationDate":"September 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_NONE_XML_DESCRIPTION","group":"","filename":"none"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2014","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com","version":"4.1.7","description":"PLG_TINY_XML_DESCRIPTION","group":"","filename":"tinymce"}', '{"skin":"0","skin_admin":"0","mode":"1","mobile":"0","entity_encoding":"raw","lang_mode":"1","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"1","invalid_elements":"script,applet,iframe","valid_elements":"","extended_elements":"","html_height":"550","html_width":"750","resizing":"1","resize_horizontal":"1","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","colors":"1","table":"1","smilies":"1","hr":"1","link":"1","media":"1","print":"1","directionality":"1","fullscreen":"1","alignment":"1","visualchars":"1","visualblocks":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","image_advtab":"1","advlist":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":"","filename":"article"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":"","filename":"image"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":"","filename":"pagebreak"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_READMORE_XML_DESCRIPTION","group":"","filename":"readmore"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":"","filename":"categories"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":"","filename":"contacts"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":"","filename":"newsfeeds"}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 1, 1, 1, '{"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":"","filename":"languagefilter"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0);
INSERT INTO `analk_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 0, 1, 0, '{"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_P3P_XML_DESCRIPTION","group":"","filename":"p3p"}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CACHE_XML_DESCRIPTION","group":"","filename":"cache"}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":"","filename":"debug"}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_LOG_XML_DESCRIPTION","group":"","filename":"log"}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 0, 1, 1, '{"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_REDIRECT_XML_DESCRIPTION","group":"","filename":"redirect"}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":"","filename":"remember"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEF_XML_DESCRIPTION","group":"","filename":"sef"}', '', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":"","filename":"logout"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":"","filename":"contactcreator"}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '{"autoregister":"1","mail_to_user":"1","forceLogout":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":"","filename":"profile"}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":"","filename":"joomla"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":"","filename":"languagecode"}', '', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 0, 1, 1, '{"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":"","filename":"joomlaupdate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 0, 1, 1, '{"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":"","filename":"extensionupdate"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 0, 1, 0, '{"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":"","filename":"recaptcha"}', '{"public_key":"","private_key":"","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '{"name":"plg_system_highlight","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION","group":"","filename":"highlight"}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":"","filename":"finder"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_categories","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CATEGORIES_XML_DESCRIPTION","group":"","filename":"categories"}', '', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_contacts","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTACTS_XML_DESCRIPTION","group":"","filename":"contacts"}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_content","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_CONTENT_XML_DESCRIPTION","group":"","filename":"content"}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_newsfeeds","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION","group":"","filename":"newsfeeds"}', '', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(447, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_tags","type":"plugin","creationDate":"February 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(448, 'plg_twofactorauth_totp', 'plugin', 'totp', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_totp","type":"plugin","creationDate":"August 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION","group":"","filename":"totp"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(449, 'plg_authentication_cookie', 'plugin', 'cookie', 'authentication', 0, 1, 1, 0, '{"name":"plg_authentication_cookie","type":"plugin","creationDate":"July 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_AUTH_COOKIE_XML_DESCRIPTION","group":"","filename":"cookie"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(450, 'plg_twofactorauth_yubikey', 'plugin', 'yubikey', 'twofactorauth', 0, 0, 1, 0, '{"name":"plg_twofactorauth_yubikey","type":"plugin","creationDate":"September 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.2.0","description":"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION","group":"","filename":"yubikey"}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(451, 'plg_search_tags', 'plugin', 'tags', 'search', 0, 1, 1, 0, '{"name":"plg_search_tags","type":"plugin","creationDate":"March 2014","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_SEARCH_TAGS_XML_DESCRIPTION","group":"","filename":"tags"}', '{"search_limit":"50","show_tagged_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(503, 'beez3', 'template', 'beez3', '', 0, 1, 1, 0, '{"name":"beez3","type":"template","creationDate":"25 November 2009","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"3.1.0","description":"TPL_BEEZ3_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","templatecolor":"nature"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(504, 'hathor', 'template', 'hathor', '', 1, 1, 1, 0, '{"name":"hathor","type":"template","creationDate":"May 2010","author":"Andrea Tarr","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"hathor@tarrconsulting.com","authorUrl":"http:\\/\\/www.tarrconsulting.com","version":"3.0.0","description":"TPL_HATHOR_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"showSiteName":"0","colourChoice":"0","boldText":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(506, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{"name":"protostar","type":"template","creationDate":"4\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(507, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{"name":"isis","type":"template","creationDate":"3\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_ISIS_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{"templateColor":"","logoFile":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (en-GB)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"name":"English (en-GB)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.2","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (en-GB)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"name":"English (en-GB)","type":"language","creationDate":"2013-03-07","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.2","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"name":"files_joomla","type":"file","creationDate":"June 2015","author":"Joomla! Project","copyright":"(C) 2005 - 2015 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.4.3","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'Vietnamese-VN', 'language', 'vi-VN', '', 0, 1, 0, 0, '{"name":"Vietnamese-VN","type":"language","creationDate":"December 2013","author":"Vietnamese Translation Team Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"Vietnamese language pack for Joomla! 3.2","group":"","filename":"install"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'Vietnamese-VN', 'language', 'vi-VN', '', 1, 1, 0, 0, '{"name":"Vietnamese-VN","type":"language","creationDate":"December 2013","author":"Vietnamese Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"Vietnamese administration language for Joomla! 3.2","group":"","filename":"install"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'Vietnamese Language Pack', 'package', 'pkg_vi-VN', '', 0, 1, 1, 0, '{"name":"Vietnamese Language Pack","type":"package","creationDate":"December 2013","author":"Vietnamese Translation Team","copyright":"Copyright (C) 2013 joomlaviet.info and Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"3.2.1.1 Joomla Vietnamese Language Package","group":"","filename":"pkg_vi-VN"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'plg_system_nnframework', 'plugin', 'nnframework', 'system', 0, 1, 1, 0, '{"name":"plg_system_nnframework","type":"plugin","creationDate":"July 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"https:\\/\\/www.nonumber.nl","version":"15.7.25915","description":"PLG_SYSTEM_NNFRAMEWORK_DESC","group":"","filename":"nnframework"}', '{"max_list_count":"2500"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10005, 'plg_editors-xtd_articlesanywhere', 'plugin', 'articlesanywhere', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_articlesanywhere","type":"plugin","creationDate":"August 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"https:\\/\\/www.nonumber.nl","version":"4.0.0","description":"PLG_EDITORS-XTD_ARTICLESANYWHERE_DESC","group":"","filename":"articlesanywhere"}', '[]', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'plg_system_articlesanywhere', 'plugin', 'articlesanywhere', 'system', 0, 1, 1, 0, '{"name":"plg_system_articlesanywhere","type":"plugin","creationDate":"August 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"https:\\/\\/www.nonumber.nl","version":"4.0.0","description":"PLG_SYSTEM_ARTICLESANYWHERE_DESC","group":"","filename":"articlesanywhere"}', '{"article_tag":"article","@notice_articles_tag":"NN_ONLY_AVAILABLE_IN_PRO","@notice_limit":"NN_ONLY_AVAILABLE_IN_PRO","@notice_ordering":"NN_ONLY_AVAILABLE_IN_PRO","@notice_ordering_direction":"NN_ONLY_AVAILABLE_IN_PRO","ignore_language":"0","ignore_access":"0","ignore_state":"0","use_ellipsis":"1","place_comments":"1","@notice_articles":"NN_ONLY_AVAILABLE_IN_PRO","@notice_components":"NN_ONLY_AVAILABLE_IN_PRO","@notice_otherareas":"NN_ONLY_AVAILABLE_IN_PRO","button_text":"Article","enable_frontend":"1","data_title_enable":"1","data_text_enable":"1","data_text_type":"text","data_text_length":"","data_text_strip":"0","data_readmore_enable":"1","data_readmore_text":"","data_readmore_class":"","@notice_div_enable":"NN_ONLY_AVAILABLE_IN_PRO","@notice_content_type":"NN_ONLY_AVAILABLE_IN_PRO"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'plg_editors-xtd_modulesanywhere', 'plugin', 'modulesanywhere', 'editors-xtd', 0, 1, 1, 0, '{"name":"plg_editors-xtd_modulesanywhere","type":"plugin","creationDate":"August 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"https:\\/\\/www.nonumber.nl","version":"4.0.0","description":"PLG_EDITORS-XTD_MODULESANYWHERE_DESC","group":"","filename":"modulesanywhere"}', '[]', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10009, 'plg_system_modulesanywhere', 'plugin', 'modulesanywhere', 'system', 0, 1, 1, 0, '{"name":"plg_system_modulesanywhere","type":"plugin","creationDate":"August 2015","author":"NoNumber (Peter van Westen)","copyright":"Copyright \\u00a9 2015 NoNumber All Rights Reserved","authorEmail":"peter@nonumber.nl","authorUrl":"https:\\/\\/www.nonumber.nl","version":"4.0.0","description":"PLG_SYSTEM_MODULESANYWHERE_DESC","group":"","filename":"modulesanywhere"}', '{"module_tag":"module","modulepos_tag":"modulepos","handle_loadposition":"0","activate_jumper":"0","style":"none","styles":"none,division,tabs,well","override_style":"1","@notice_override_settings":"NN_ONLY_AVAILABLE_IN_PRO","ignore_access":"0","ignore_state":"0","ignore_assignments":"1","ignore_caching":"0","@notice_show_edit":"NN_ONLY_AVAILABLE_IN_PRO","place_comments":"1","@notice_articles":"NN_ONLY_AVAILABLE_IN_PRO","@notice_components":"NN_ONLY_AVAILABLE_IN_PRO","@notice_otherareas":"NN_ONLY_AVAILABLE_IN_PRO","button_text":"Module","enable_frontend":"1","@notice_div_enable":"NN_ONLY_AVAILABLE_IN_PRO","@notice_div_width":"NN_ONLY_AVAILABLE_IN_PRO","@notice_div_height":"NN_ONLY_AVAILABLE_IN_PRO","@notice_div_float":"NN_ONLY_AVAILABLE_IN_PRO","@notice_div_class":"NN_ONLY_AVAILABLE_IN_PRO"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10010, 'JoomGallery', 'component', 'com_joomgallery', '', 1, 1, 0, 0, '{"name":"JoomGallery","type":"component","creationDate":"2015\\/07\\/26","author":"JoomGallery::ProjectTeam","copyright":"This component is released under the GNU\\/GPL License","authorEmail":"team@joomgallery.net","authorUrl":"http:\\/\\/www.joomgallery.net","version":"3.2.2","description":"JoomGallery 3 is a native Joomla! 3.x gallery component","group":"","filename":"joomgallery"}', '{"extended_config":0,"sef_image":0}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10012, 'PLG_USER_PROFILEPICTURE', 'plugin', 'profilepicture', 'user', 0, 1, 1, 0, '{"name":"PLG_USER_PROFILEPICTURE","type":"plugin","creationDate":"June 2015","author":"Mosets Consulting","copyright":"(C) 2012-present Mosets Consulting. All rights reserved.","authorEmail":"mtree@mosets.com","authorUrl":"www.mosets.com","version":"2.0.0","description":"PLG_USER_PROFILEPICTURE_XML_DESCRIPTION","group":"","filename":"profilepicture"}', '{"maxUploadSizeInBytes":"800000"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10013, 'Profile Picture Package', 'package', 'pkg_profilepicture', '', 0, 1, 1, 0, '{"name":"Profile Picture Package","type":"package","creationDate":"June 2015","author":"Mosets Consulting","copyright":"","authorEmail":"","authorUrl":"","version":"2.0.0","description":"Profile Picture Package","group":"","filename":"pkg_profilepicture"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10014, 'PLG_JOOMGALLERY_JOOMADDITIONALIMAGEFIELDS', 'plugin', 'joomadditionalimagefields', 'joomgallery', 0, 1, 1, 0, '{"name":"PLG_JOOMGALLERY_JOOMADDITIONALIMAGEFIELDS","type":"plugin","creationDate":"08\\/11\\/2012","author":"JoomlaGallery::ProjektTeam","copyright":"(C) 2012 Open Source Matters. All rights reserved.","authorEmail":"team@joomgallery.net","authorUrl":"www.joomgallery.net","version":"1.1","description":"PLG_JOOMGALLERY_JOOMADDITIONALIMAGEFIELDS_XML_DESCRIPTION","group":"","filename":"joomadditionalimagefields"}', '{"display_after_thumb":"1","display_after_detailimage":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10032, 'Profile Cover', 'library', 'profilepicture', '', 0, 1, 1, 0, '{"name":"Profile Cover","type":"library","creationDate":"August 2015","author":"Mosets Consulting - T.Trung","copyright":"","authorEmail":"nttrung211@gmail","authorUrl":"","version":"2.0.0","description":"LIB_PROFILECOVER_XML_DESCRIPTION","group":"","filename":"profilepicture"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10033, 'PLG_USER_PROFILECOVER', 'plugin', 'profilecover', 'user', 0, 1, 1, 0, '{"name":"PLG_USER_PROFILECOVER","type":"plugin","creationDate":"August 2015","author":"Mosets Consulting - T.Trung","copyright":"(C) 2012-present Mosets Consulting. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"","version":"2.0.0","description":"PLG_USER_PROFILECOVER_XML_DESCRIPTION","group":"","filename":"profilecover"}', '{"maxUploadSizeInBytes":"2000000"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10034, 'Profile Cover Package', 'package', 'pkg_profilecover', '', 0, 1, 1, 0, '{"name":"Profile Cover Package","type":"package","creationDate":"August 2015","author":"Mosets Consulting - T.Trung","copyright":"","authorEmail":"","authorUrl":"","version":"2.0.0","description":"Profile Cover Package","group":"","filename":"pkg_profilepicture"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10037, 'com_recharge', 'component', 'com_recharge', '', 1, 1, 0, 0, '{"name":"com_recharge","type":"component","creationDate":"2015-08-06","author":"Nguyen Thanh Trung","copyright":"Copyright (C) 2015. All rights reserved.","authorEmail":"nttrung211@yahoo.com","authorUrl":"","version":"1.0.0","description":"N\\u1ea1p th\\u1ebb","group":"","filename":"recharge"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10038, 'com_orders', 'component', 'com_orders', '', 1, 1, 0, 0, '{"name":"com_orders","type":"component","creationDate":"2015-08-06","author":"Nguyen Thanh Trung","copyright":"Copyright (C) 2015. All rights reserved.","authorEmail":"nttrung211@yahoo.com","authorUrl":"","version":"1.0.0","description":"","group":"","filename":"orders"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10039, 'kkvn', 'template', 'kkvn', '', 0, 1, 1, 0, '{"name":"kkvn","type":"template","creationDate":"12\\/08\\/2015","author":"T.Trung","copyright":"Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":"","filename":"templateDetails"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10040, 'JoomGallery vi-VN', 'file', 'JoomGalleryvi-VN', '', 0, 1, 0, 0, '{"name":"JoomGallery vi-VN","type":"file","creationDate":"2013-06-16","author":"JoomGallery::ProjectTeam","copyright":"Copyright (C) 2008 - 2013 JoomGallery::ProjectTeam. All rights reserved.","authorEmail":"team@joomgallery.net","authorUrl":"http:\\/\\/www.joomgallery.net\\/","version":"3.1","description":"\\n    <div align=\\"center\\">\\n      <table border=\\"0\\" width=\\"100%\\">\\n        <tr>\\n          <td width=\\"100%\\" colspan=\\"2\\">\\n            <div align=\\"center\\">\\n              <h3>Vietnamese Translation for JoomGallery 3.x<\\/h3>\\n              <br \\/><strong>by: <a href=\\"https:\\/\\/www.transifex.com\\/projects\\/p\\/joomgallery3\\/language\\/vi_VN\\/\\" target=\\"_blank\\">JoomGallery::TranslationTeam::Vietnamese<\\/a><\\/strong>\\n              <br \\/>(based on a translation by: Viet D\\u0169ng)\\n            <\\/div>\\n            <hr \\/>\\n          <\\/td>\\n        <\\/tr>\\n        <tr>\\n          <td width=\\"25%\\"><u><strong>Translated areas:<\\/strong><\\/u><\\/td>\\n          <td width=\\"75%\\">Website (Frontend) excl. EXIF- and IPTC-Tags<\\/td>\\n        <\\/tr>\\n        <tr>\\n          <td width=\\"25%\\"><u><strong>Translation version:<\\/strong><\\/u><\\/td>\\n          <td width=\\"75%\\">3.1<\\/td>\\n        <\\/tr>\\n        <td width=\\"100%\\" colspan=\\"2\\"><hr \\/><\\/td>\\n        <tr>\\n          <td width=\\"25%\\"><u><strong>JoomGallery-Website:<\\/strong><\\/u><\\/td>\\n          <td width=\\"75%\\"><a href=\\"http:\\/\\/www.en.joomgallery.net\\" target=\\"_blank\\">http:\\/\\/www.en.joomgallery.net<\\/a><\\/td>\\n        <\\/tr>\\n        <\\/tr>\\n        <td width=\\"100%\\" colspan=\\"2\\"><hr \\/><\\/td>\\n        <tr>\\n      <\\/table>\\n    <\\/div>","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10043, 'mod_joomsearch', 'module', 'mod_joomsearch', '', 0, 1, 0, 0, '{"name":"mod_joomsearch","type":"module","creationDate":"18.03.2013","author":"JoomGallery::Project Team","copyright":"(C) 2009 - 2013 JoomGallery::Project Team","authorEmail":"team@joomgallery.net","authorUrl":"www.joomgallery.net","version":"3.0 BETA","description":"MOD_JOOMSEARCH_DESC","group":"","filename":"mod_joomsearch"}', '{"moduleclass_sfx":"","itemid":"","ajaxsearch":"1","defcatid":"","defsubcats":"1","syncjoom":"0","limit":"10","defcatorimg":"1","defsearchimgdescr":"1","defsearchcomments":"0","defsearchauthors":"0","defsearchcatdescr":"0","showusrpanel":"1","usrlimit":"0","usrcatorimg":"0","usrsearchimgdescr":"1","usrsearchcomments":"0","usrsearchauthors":"0","usrsearchcatdescr":"0","layout":"default","inputboxwidth":"0","resultwidth":"100","resultheight":"200","srchbtnshow":"0","srchbtntext":"","srchbtnimg":"0","srchbtnpos":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10046, 'mod_special_gallery', 'module', 'mod_special_gallery', '', 0, 1, 1, 0, '{"name":"mod_special_gallery","type":"module","creationDate":"August 2015","author":"T.Trung","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"","version":"1.0.0","description":"Hi\\u1ec3n th\\u1ecb h\\u00ecnh \\u1ea3nh ch\\u1ecdn l\\u1ecdc","group":"","filename":"mod_special_gallery"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10047, 'mod_new_gallery', 'module', 'mod_new_gallery', '', 0, 1, 1, 0, '{"name":"mod_new_gallery","type":"module","creationDate":"August 2015","author":"T.Trung","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"","version":"1.0.0","description":"Hi\\u1ec3n th\\u1ecb h\\u00ecnh \\u1ea3nh m\\u1edbi nh\\u1ea5t","group":"","filename":"mod_new_gallery"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10048, 'mod_like_gallery', 'module', 'mod_like_gallery', '', 0, 1, 1, 0, '{"name":"mod_like_gallery","type":"module","creationDate":"August 2015","author":"T.Trung","copyright":"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.","authorEmail":"nttrung211@gmail.com","authorUrl":"","version":"1.0.0","description":"Hi\\u1ec3n th\\u1ecb h\\u00ecnh \\u1ea3nh \\u0111\\u01b0\\u1ee3c y\\u00eau th\\u00edch nh\\u1ea5t","group":"","filename":"mod_like_gallery"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10058, 'jNews Module', 'module', 'mod_jnews', '', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Module","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10059, 'jNews', 'component', 'com_jnews', '', 1, 1, 0, 0, '{"name":"jNews","type":"component","creationDate":"January 2014","author":"Joobi Limited","copyright":"Copyright (C) 2006-2014 Joobi Limited All rights reserved","authorEmail":"support@joobi.co","authorUrl":"http:\\/\\/www.joobi.co","version":"8.3.1","description":" jNews the ultimate mailing system for Joomla CMS.","group":"","filename":"jnews"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10060, 'jNews Forward to Friend', 'plugin', 'forwardtofriend', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Forward to Friend","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10061, 'jNews Content Plugin', 'plugin', 'jnewsbot', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Content Plugin","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(10062, 'jNews Social Share Plugin', 'plugin', 'jnewsshare', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Social Share Plugin","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(10063, 'jNews User Synchronization', 'plugin', 'jnewssyncuser', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"jNews User Synchronization","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 20, 0),
(10064, 'jNews Tag: Date and Time', 'plugin', 'tagdatetime', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Tag: Date and Time","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(10065, 'jNews Tag: Site Links', 'plugin', 'tagsite', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Tag: Site Links","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10066, 'jNews Tag: Subscriber', 'plugin', 'tagsubscriber', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Tag: Subscriber","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(10067, 'jNews Tag: Subscriptions', 'plugin', 'tagsubscription', 'jnews', 0, 1, 1, 0, '{"legacy":false,"name":"jNews Tag: Subscriptions","type":"plugin","creationDate":"September 2015","author":"Joobi Limited","copyright":"Copyright (C) 2006 - 2012 Joobi Limited. All rights reserved.","authorEmail":"support@joobi.co","authorUrl":"www.joobi.co","version":"8.3.1","description":"","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_follow`
--

CREATE TABLE IF NOT EXISTS `analk_follow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `follow_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_followup`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_followup` (
  `followup_id` smallint(10) unsigned NOT NULL,
  `list_id` smallint(10) unsigned NOT NULL,
  PRIMARY KEY (`followup_id`,`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_listmailings`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_listmailings` (
  `list_id` int(10) unsigned NOT NULL,
  `mailing_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`list_id`,`mailing_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_jnews_listmailings`
--

INSERT INTO `analk_jnews_listmailings` (`list_id`, `mailing_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_lists`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_lists` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `list_name` varchar(101) NOT NULL DEFAULT '',
  `list_desc` text NOT NULL,
  `list_type` tinyint(2) NOT NULL DEFAULT '1',
  `sendername` varchar(64) NOT NULL DEFAULT '',
  `senderemail` varchar(64) NOT NULL DEFAULT '',
  `bounceadres` varchar(64) NOT NULL DEFAULT '',
  `color` varchar(30) DEFAULT NULL,
  `layout` text NOT NULL,
  `template` int(9) NOT NULL DEFAULT '0',
  `subscribemessage` text NOT NULL,
  `unsubscribemessage` text NOT NULL,
  `unsubscribesend` tinyint(1) NOT NULL DEFAULT '1',
  `unsubscribenotifyadmin` tinyint(1) NOT NULL DEFAULT '1',
  `notifyadminmsg` text NOT NULL,
  `subnotifysend` tinyint(1) NOT NULL DEFAULT '1',
  `subnotifymsg` text NOT NULL,
  `auto_add` tinyint(1) NOT NULL DEFAULT '0',
  `user_choose` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` int(10) NOT NULL DEFAULT '0',
  `delay_min` int(2) NOT NULL DEFAULT '0',
  `delay_max` int(2) NOT NULL DEFAULT '7',
  `follow_up` int(10) NOT NULL DEFAULT '0',
  `html` tinyint(1) NOT NULL DEFAULT '1',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `createdate` int(11) NOT NULL DEFAULT '0',
  `acc_level` varchar(200) NOT NULL DEFAULT '24,25,7,8',
  `acc_id` varchar(200) NOT NULL DEFAULT 'all',
  `notification` tinyint(1) NOT NULL DEFAULT '0',
  `owner` int(11) NOT NULL DEFAULT '0',
  `footer` tinyint(1) NOT NULL DEFAULT '1',
  `notify_id` int(10) NOT NULL DEFAULT '0',
  `next_date` int(11) NOT NULL DEFAULT '0',
  `start_date` date NOT NULL,
  `params` text,
  `siteend` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_name` (`list_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `analk_jnews_lists`
--

INSERT INTO `analk_jnews_lists` (`id`, `list_name`, `list_desc`, `list_type`, `sendername`, `senderemail`, `bounceadres`, `color`, `layout`, `template`, `subscribemessage`, `unsubscribemessage`, `unsubscribesend`, `unsubscribenotifyadmin`, `notifyadminmsg`, `subnotifysend`, `subnotifymsg`, `auto_add`, `user_choose`, `cat_id`, `delay_min`, `delay_max`, `follow_up`, `html`, `hidden`, `published`, `createdate`, `acc_level`, `acc_id`, `notification`, `owner`, `footer`, `notify_id`, `next_date`, `start_date`, `params`, `siteend`) VALUES
(1, 'Khoảnh khắc Việt Nam', '', 1, '', '', '', NULL, '', 12, '', 'This is a confirmation email that you have been unsubscribed from our list. We are sorry that you decided to unsubscribe. But if you decide to re-subscribe you can always do so on our site. Should you have any question please contact our webmaster.', 1, 1, '', 1, '', 0, 0, 0, 0, 0, 0, 1, 0, 1, 1442228551, '25,24,8,7', 'all', 0, 468, 1, 0, 0, '0000-00-00', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_listssubscribers`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_listssubscribers` (
  `list_id` smallint(11) unsigned NOT NULL,
  `subscriber_id` int(11) unsigned NOT NULL,
  `subdate` int(11) unsigned DEFAULT NULL,
  `unsubdate` int(11) unsigned DEFAULT '0',
  `unsubscribe` tinyint(1) DEFAULT '0',
  `params` text,
  PRIMARY KEY (`list_id`,`subscriber_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_jnews_listssubscribers`
--

INSERT INTO `analk_jnews_listssubscribers` (`list_id`, `subscriber_id`, `subdate`, `unsubdate`, `unsubscribe`, `params`) VALUES
(1, 4, 1442203476, 0, 0, NULL),
(1, 3, 1442203493, 0, 0, NULL),
(1, 2, 1442203499, 0, 0, NULL),
(1, 5, 1442203513, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_mailings`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_mailings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_id` int(10) NOT NULL DEFAULT '0',
  `mailing_type` tinyint(2) NOT NULL DEFAULT '1',
  `template_id` smallint(11) NOT NULL DEFAULT '0',
  `issue_nb` int(10) NOT NULL DEFAULT '0',
  `subject` varchar(120) NOT NULL DEFAULT '',
  `fromname` varchar(64) NOT NULL DEFAULT '',
  `fromemail` varchar(64) NOT NULL DEFAULT '',
  `frombounce` varchar(64) NOT NULL DEFAULT '',
  `htmlcontent` longtext NOT NULL,
  `textonly` longtext NOT NULL,
  `attachments` text NOT NULL,
  `images` text NOT NULL,
  `send_date` int(11) NOT NULL DEFAULT '0',
  `delay` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `html` tinyint(1) NOT NULL DEFAULT '1',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `createdate` int(11) NOT NULL DEFAULT '0',
  `acc_level` int(2) NOT NULL DEFAULT '0',
  `author_id` int(11) NOT NULL DEFAULT '0',
  `follow_up` int(10) unsigned NOT NULL DEFAULT '0',
  `cat_id` varchar(250) NOT NULL DEFAULT '0:0',
  `delay_min` int(2) NOT NULL DEFAULT '0',
  `delay_max` int(2) NOT NULL DEFAULT '7',
  `notify_id` int(10) unsigned NOT NULL DEFAULT '0',
  `next_date` int(11) unsigned NOT NULL DEFAULT '0',
  `start_date` int(11) unsigned NOT NULL DEFAULT '0',
  `smart_date` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `analk_jnews_mailings`
--

INSERT INTO `analk_jnews_mailings` (`id`, `list_id`, `mailing_type`, `template_id`, `issue_nb`, `subject`, `fromname`, `fromemail`, `frombounce`, `htmlcontent`, `textonly`, `attachments`, `images`, `send_date`, `delay`, `visible`, `html`, `published`, `createdate`, `acc_level`, `author_id`, `follow_up`, `cat_id`, `delay_min`, `delay_max`, `notify_id`, `next_date`, `start_date`, `smart_date`) VALUES
(1, 1, 1, 12, 1, 'Khoảnh khắc Việt Nam', '', '', '', '<div style="background-color: #ffffff;">\r\n<p> </p>\r\n<table style="height: 100%;" border="0" width="100%" cellspacing="0" cellpadding="0" bgcolor="#9edaf4">\r\n<tbody>\r\n<tr>\r\n<td align="center" valign="top">\r\n<table border="0" width="600" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td colspan="2" valign="middle">\r\n<div>\r\n<h1><img src="http://www.joobi.co/images/newsletter_templates/simplicity/jnews_logo.png" alt="" width="241px" height="91px" border="0" /></h1>\r\n</div>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="middle">\r\n<div>\r\n<h3>Your Top Communication Partner</h3>\r\n</div>\r\n</td>\r\n<td valign="bottom" width="30%">\r\n<div style="text-align: right;">\r\n<h5>{tag:date}</h5>\r\n</div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<table border="0" width="600" cellspacing="0" cellpadding="0" bgcolor="#ffffff">\r\n<tbody>\r\n<tr>\r\n<td align="center" valign="top">\r\n<table border="0" width="600" cellspacing="30" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<h2>jNews is now out in the market!</h2>\r\n</td>\r\n<td style="margin-top: 20px;" rowspan="2"><img src="http://joobi.co/images/jnews_newsletter.png" alt="" width="130px" height="215px" border="0" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top">\r\n<p>Hi {tag:firstname},<br /><br /> This 2012, we are coming out with a application that will bring email marketing to the next generation. This is jNews. <br /><br /> jNews is our newest products, an email marketing application for Joomla 1.5, 1.6, 1.7 and 2.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want. {tag:share name=facebook,linkedin,twitter}</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top">\r\n<table border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td class="readmore" align="center" valign="center" width="113px" height="38px;"><a href="#">Live Demo</a></td>\r\n<td style="width: 30px;" width="10"> </td>\r\n<td class="readmore" align="center" valign="center" width="113px" height="38px;"><a href="#">Documentation</a></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align="center" valign="top">\r\n<table border="0" width="600" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td colspan="2"><hr width="560px" size="1" /></td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="280">\r\n<table border="0" width="100%" cellspacing="30" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<div>\r\n<h4>Need Help?</h4>\r\n<p>Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\r\n<ul>\r\n<li>Live Chat</li>\r\n<li>Support</li>\r\n<li>Forum</li>\r\n</ul>\r\n</div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n<td valign="top" width="280">\r\n<table border="0" width="100%" cellspacing="30" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<div>\r\n<h4>Spread the News</h4>\r\n<p>Know someone who might be interested in this newsletter? {tag:fwdtofriend name=Forward to a friend.}</p>\r\n<br /><br />\r\n<p>Would you like to {tag:subscriptions}?<br /> Not interested any more? {tag:unsubscribe}</p>\r\n</div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td align="center" valign="top">\r\n<table border="0" width="600" cellspacing="0" cellpadding="0" bgcolor="#9edaf4">\r\n<tbody>\r\n<tr>\r\n<td valign="top">\r\n<table border="0" width="100%" cellspacing="30" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td colspan="2" align="center" valign="middle">\r\n<div><a class="footer" href="#">This email contains graphics, if you don''t see them {tag:viewonline name=view it in your browser}.</a><br /> <a class="footer" href="#">Powered by Joobi</a></div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>', '  \n\n \n \n\n\n \n \n\n\n \n \n\n \n  \n \n \n \n \n\n \n Your Top Communication Partner \n \n \n\n\n {tag:date} \n \n \n \n \n \n\n \n \n\n\n \n \n \n jNews is now out in the market! \n \n \n \n \n\nHi {tag:firstname},   This 2012, we are coming out with a application that will bring email marketing to the next generation. This is jNews.    jNews is our newest products, an email marketing application for Joomla 1.5, 1.6, 1.7 and 2.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want. {tag:share name=facebook,linkedin,twitter} \n \n \n \n\n\n \n \nLive Demo ( # ) \n  \nDocumentation ( # ) \n \n \n \n \n \n \n \n \n \n \n\n\n \n \n \n \n \n\n\n \n \n\n \n Need Help? \nShould you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them. \n\nLive Chat\nSupport\nForum\n\n \n \n \n \n \n \n\n\n \n \n\n \n Spread the News \nKnow someone who might be interested in this newsletter? {tag:fwdtofriend name=Forward to a friend.} \n  \nWould you like to {tag:subscriptions}?  Not interested any more? {tag:unsubscribe} \n \n \n \n \n \n \n \n \n \n \n \n \n\n\n \n \n\n\n \n \n\n This email contains graphics, if you don''t see them {tag:viewonline name=view it in your browser}.  Powered by Joobi', '', '', 0, 0, 1, 1, 0, 1442203402, 0, 468, 0, '', 0, 7, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_queue`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_queue` (
  `qid` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL DEFAULT '0',
  `issue_nb` int(10) NOT NULL DEFAULT '0',
  `subscriber_id` int(11) NOT NULL DEFAULT '0',
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `priority` tinyint(3) unsigned DEFAULT '3',
  `attempt` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `suspend` tinyint(1) NOT NULL DEFAULT '0',
  `send_date` int(11) unsigned DEFAULT NULL,
  `delay` int(10) NOT NULL DEFAULT '0',
  `acc_level` int(2) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `params` text,
  `block` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `sub_mail` (`mailing_id`,`subscriber_id`,`type`),
  KEY `senddate` (`send_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_stats_details`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_stats_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `subscriber_id` int(11) NOT NULL DEFAULT '0',
  `sentdate` int(11) unsigned DEFAULT NULL,
  `html` tinyint(1) NOT NULL DEFAULT '0',
  `read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sub_mail` (`mailing_id`,`subscriber_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_stats_global`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_stats_global` (
  `mailing_id` int(11) NOT NULL DEFAULT '0',
  `sentdate` int(11) unsigned DEFAULT NULL,
  `html_sent` int(11) NOT NULL DEFAULT '0',
  `text_sent` int(11) NOT NULL DEFAULT '0',
  `html_read` int(11) NOT NULL DEFAULT '0',
  `failed` int(11) NOT NULL DEFAULT '0',
  `sent` int(11) NOT NULL DEFAULT '0',
  `pending` int(11) NOT NULL DEFAULT '0',
  `bounces` int(11) NOT NULL DEFAULT '0',
  `unsub` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mailing_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_jnews_stats_global`
--

INSERT INTO `analk_jnews_stats_global` (`mailing_id`, `sentdate`, `html_sent`, `text_sent`, `html_read`, `failed`, `sent`, `pending`, `bounces`, `unsub`) VALUES
(1, 1442203402, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_subscribers`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `receive_html` tinyint(1) NOT NULL DEFAULT '1',
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `blacklist` tinyint(1) NOT NULL DEFAULT '0',
  `timezone` time NOT NULL DEFAULT '00:00:00',
  `language_iso` varchar(10) NOT NULL DEFAULT 'eng',
  `ip` varchar(100) DEFAULT NULL,
  `subscribe_date` int(11) NOT NULL DEFAULT '0',
  `params` text,
  `column1` varchar(255) NOT NULL,
  `column2` varchar(255) NOT NULL,
  `column3` varchar(255) NOT NULL,
  `column4` varchar(255) NOT NULL,
  `column5` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `date` (`subscribe_date`),
  KEY `joomlauserid` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `analk_jnews_subscribers`
--

INSERT INTO `analk_jnews_subscribers` (`id`, `user_id`, `name`, `email`, `receive_html`, `confirmed`, `blacklist`, `timezone`, `language_iso`, `ip`, `subscribe_date`, `params`, `column1`, `column2`, `column3`, `column4`, `column5`) VALUES
(1, 468, 'Super User', 'nttrung211@gmail.com', 1, 1, 0, '00:00:00', 'eng', NULL, 1438509048, NULL, '', '', '', '', ''),
(2, 469, 'Trung aaa', 'nttrung211@yahoo.com', 1, 1, 0, '00:00:00', '', NULL, 1439148805, NULL, '', '', '', '', ''),
(3, 470, 'Nguyen Thanh Trung', 'trung@mywebcreations.dk', 1, 1, 0, '00:00:00', '', NULL, 1440364516, NULL, '', '', '', '', ''),
(4, 485, 'thai nguyen', 'thai@gmail.com', 1, 1, 0, '00:00:00', '', NULL, 1441918882, NULL, '', '', '', '', ''),
(5, 486, 'Thai Nguyen', 'thaind@gmail.com', 1, 1, 0, '00:00:00', '', NULL, 0, NULL, '', '', '', '', ''),
(7, 0, 'trung', 'abc@abc.com', 1, 1, 0, '00:00:00', 'vi-VN', '', 1442222995, NULL, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_templates`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_templates` (
  `template_id` smallint(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `description` text,
  `body` longtext,
  `altbody` longtext,
  `created` int(10) unsigned DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT '1',
  `premium` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` smallint(10) unsigned NOT NULL DEFAULT '99',
  `namekey` varchar(50) NOT NULL,
  `styles` text,
  `thumbnail` text NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT '1',
  `csstyle` text NOT NULL,
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `namekey` (`namekey`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=81 ;

--
-- Dumping data for table `analk_jnews_templates`
--

INSERT INTO `analk_jnews_templates` (`template_id`, `name`, `description`, `body`, `altbody`, `created`, `published`, `premium`, `ordering`, `namekey`, `styles`, `thumbnail`, `availability`, `csstyle`) VALUES
(1, 'Entwine (black)', 'A classic two columns layout designed with a twist of modern curves in black color, highlighting headline titles valuable for your newsletter to attract more customer, best for promos and events.', '<table style="width: 100%; margin: 0pt auto; background-color:#4c4c4c; color: #333333; font-family: Arial,Tahoma,Geneva,Kalimati,sans-serif;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table style="margin: auto; width: 700px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" align="right" valign="top"><img src="media/com_jnews/templates/entwine/black/topleft_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td>\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td height="58" bgcolor="#323232">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td style="width: 70%;">\n<h1><img src="http://www.joobi.co/images/newsletter_templates/entwine/black/logo-big.png" border="0" alt="jnews logo" style="margin-left: 20px;display:block;margin:0;" /></h1>\n</td>\n<td style="width: 30%;" align="right">\n<h6>{tag:date}</h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="background-color: #ffffff; height: 58px; text-align: center;" height="58">\n<h2>jNews is now out in the market!</h2>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/black/topright_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 700px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style=" font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;"><span style="font-size: 12px; color: #4c4c4c;">joobi</span></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 680px; background-color: #ffffff;" border="0" cellspacing="20" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 250px;" width="250" align="left" valign="top">\n<p style="text-align: center; width: 250px;"><img src="http://joobi.co/images/jnews_newsletter.png" border="0" alt="jNews Upgrade" width="130" height="215" style="display: block; border: 0; margin: 0px auto;" /></p>\n<h3>What is it in for you?</h3>\n<ul>\n<li>Template Management</li>\n<li>Queue Management</li>\n<li>Advanced Statistics</li>\n<li>Sending Process</li>\n</ul>\n</td>\n<td valign="top">\n<p>Hi {tag:name},</p>\n<br />\n<p>This 2010, we are coming out with a application that will bring email marketing to the next generation. This is jNews.<br /><br /> jNews is our newest products, an email marketing application for Joomla 1.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want.</p>\n<br />\n<p>{tag:share name=facebook,linkedin,twitter}</p>\n<br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 49px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jmarket/Itemid,49/controller,product-display/eid,82/task,show/"> Product Presentation </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/Help/jNews/Table-of-Contents-jNews.html"> Documentation </a><br /></td>\n</tr>\n</tbody>\n</table>\n<hr style="width: 98%;" />\n<p style="font-size:12px;">Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\n<br /><br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 55px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jtickets/Itemid,147/controller,ticket/"> Support </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_agora/Itemid,60/"> Forum </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/organization/about/welcome-to-joobi-live-support.html"> Live Admin </a></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td colspan="2" align="center">Would you like to change your subscription? {tag:subscriptions}<br /> Not interested any more? {tag:unsubscribe}</td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 702px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" valign="top"><img src="media/com_jnews/templates/entwine/black/bottom_left_black.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td style="width: 686px;">\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#ffffff"><span style="font-size: 16px; color: #fff;"> joobi </span></td>\n</tr>\n<tr>\n<td height="118" bgcolor="#232323">\n<table border="0" cellspacing="5" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#232323">\n<table border="0" cellspacing="0" cellpadding="5" width="100%">\n<tbody>\n<tr>\n<td>\n<h5>Latest Testimonials</h5>\n<h6>It feels to me that live chat is the absolute best way to provide customer support...</h6>\n<br /> <a href="#"> Read more </a></td>\n<td>\n<h5>More Powerful Features!</h5>\n<h6>Wanted to design your own newsletter template? Check our jNews PRO version.</h6>\n<br /> <a href="#"> See more </a></td>\n<td valign="bottom"><img src="http://www.joobi.co/images/newsletter_templates/entwine/black/logo-small.png" border="0" alt="jnewsletter logo" style="margin:0 0 0 20px;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="text-align:center;" align="center" valign="top" bgcolor="#4c4c4c"><br />\n<h6>This email contains graphics, so if you don''t see them, {tag:viewonline name=view it in your browser}.</h6>\n<br />\n<h6>Powered by Joobi</h6>\n<h6><br /><br /></h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/black/bottom_right_black.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>', '', 1285292068, 1, 0, 99, 'entwine_black', 'a:16:{s:8:"color_bg";s:7:"#4c4c4c";s:8:"style_h1";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:36px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h2";s:198:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:30px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:8:"style_h3";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:8:"style_h4";s:217:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:18px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:10px; 	margin-left:0pt; 	text-align:left;";s:8:"style_h5";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:14px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h6";s:182:"	color:#FFFFFF; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:7:"style_a";s:108:"color:#d7a306; 	text-decoration:none; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";s:8:"style_ul";s:88:"line-height:200%; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";s:8:"style_li";s:88:"line-height:200%; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";s:15:"aca_unsubscribe";s:108:"color:#d7a306; 	text-decoration:none; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";s:13:"aca_subscribe";s:108:"color:#d7a306; 	text-decoration:none; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";s:11:"aca_content";s:109:"	color:#333333; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px; 	margin:0; 	padding:0;";s:9:"aca_title";s:211:"	color:#333333; 	display:block; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0; 	margin-right:0; 	margin-bottom:30px; 	margin-left:0;";s:12:"aca_readmore";s:108:"	background-color: #333333;     font-family: Arial,Tahoma,Geneva,Kalimati,sans-serif;     padding: 3px 10px;";s:10:"aca_online";s:108:"color:#d7a306; 	text-decoration:none; 	font-family:Arial,Tahoma,Geneva,Kalimati,sans-serif; 	font-size:12px;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/entwine_black.png', 1, '#outlook a{padding:0;} \nimg{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}\n\nbody, p, td{\n	color:#333333;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	margin:0;\n	padding:0;\n}\n\na, .online, .subscriptions, .unsubscribe, .online{\n	color:#d7a306;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\nh1, h1 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:36px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh2, h2 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:30px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nh3, h3 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:24px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:30px;\n	margin-left:0pt;\n}\n\nh4, h4 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:18px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:10px;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh5, h5 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:14px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh6, h6 a{\n	color:#FFFFFF;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nul,li{\n	line-height:150%;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.readmore{\n	background-color: #333333;\n    font-family: Arial,Helvetica,Serif;\n    padding: 3px 10px;\n}\n\n.readmore a{\n	color:#ffffff;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}'),
(2, 'Entwine (blue)', 'A classic two columns layout designed with a twist of modern curves in blue color, highlighting headline titles valuable for your newsletter to attract more customer, best for promos and events.', '<table style="width: 100%; margin: 0pt auto; background-color:#08395a; color: #333333; font-family: Arial,Tahoma,Geneva,Kalimati,sans-serif;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table style="margin: auto; width: 700px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" align="right" valign="top"><img src="media/com_jnews/templates/entwine/blue/topleft_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td>\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td height="58" bgcolor="#1a79a9">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td style="width: 70%;">\n<h1><img src="http://www.joobi.co/images/newsletter_templates/entwine/blue/logo-big.png" border="0" alt="jnews logo" style="margin-left: 20px;display:block;margin:0;" /></h1>\n</td>\n<td style="width: 30%;" align="right">\n<h6>{tag:date}</h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="background-color: #ffffff; height: 58px; text-align: center;" height="58">\n<h2>jNews is now out in the market!</h2>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/blue/topright_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 700px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style=" font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;"><span style="font-size: 12px; color: #003300;">joobi</span></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 680px; background-color: #ffffff;" border="0" cellspacing="20" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 250px;" width="250" align="left" valign="top">\n<p style="text-align: center; width: 250px;"><img src="http://joobi.co/images/jnews_newsletter.png" border="0" alt="jNews Upgrade" width="130" height="215" style="display: block; border: 0; margin: 0px auto;" /></p>\n<h3>What is it in for you?</h3>\n<ul>\n<li>Template Management</li>\n<li>Queue Management</li>\n<li>Advanced Statistics</li>\n<li>Sending Process</li>\n</ul>\n</td>\n<td valign="top">\n<p>Hi {tag:name},</p>\n<br />\n<p>This 2010, we are coming out with a application that will bring email marketing to the next generation. This is jNews.<br /><br /> jNews is our newest products, an email marketing application for Joomla 1.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want.</p>\n<br />\n<p>{tag:share name=facebook,linkedin,twitter}</p>\n<br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 49px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jmarket/Itemid,49/controller,product-display/eid,82/task,show/"> Product Presentation </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/Help/jNews/Table-of-Contents-jNews.html"> Documentation </a><br /></td>\n</tr>\n</tbody>\n</table>\n<hr style="width: 98%;" />\n<p style="font-size:12px;">Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\n<br /><br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 55px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jtickets/Itemid,147/controller,ticket/"> Support </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_agora/Itemid,60/"> Forum </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/organization/about/welcome-to-joobi-live-support.html"> Live Admin </a></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td colspan="2" align="center">Would you like to change your subscription? {tag:subscriptions}<br /> Not interested any more? {tag:unsubscribe}</td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 702px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" valign="top"><img src="media/com_jnews/templates/entwine/blue/bottom_left_blue.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td style="width: 686px;">\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#ffffff"><span style="font-size: 16px; color: #fff;"> joobi </span></td>\n</tr>\n<tr>\n<td height="118" bgcolor="#025b87">\n<table border="0" cellspacing="5" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#025b87">\n<table border="0" cellspacing="0" cellpadding="5" width="100%">\n<tbody>\n<tr>\n<td>\n<h5>Latest Testimonials</h5>\n<h6>It feels to me that live chat is the absolute best way to provide customer support...</h6>\n<br /> <a href="#"> Read more </a></td>\n<td>\n<h5>More Powerful Features!</h5>\n<h6>Wanted to design your own newsletter template? Check our jNews PRO version.</h6>\n<br /> <a href="#"> See more </a></td>\n<td valign="bottom"><img src="http://www.joobi.co/images/newsletter_templates/entwine/blue/logo-small.png" border="0" alt="jnewsletter logo" style="margin:0 0 0 20px;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="text-align:center;" align="center" valign="top" bgcolor="#08395A"><br />\n<h6>This email contains graphics, so if you don''t see them, {tag:viewonline name=view it in your browser}.</h6>\n<br />\n<h6>Powered by Joobi</h6>\n<h6><br /><br /></h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/blue/bottom_right_blue.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>', '', 1285292068, 1, 0, 99, 'entwine_blue', 'a:16:{s:8:"color_bg";s:7:"#08395a";s:8:"style_h1";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:36px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h2";s:198:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:30px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:8:"style_h3";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:8:"style_h4";s:217:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:18px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:10px; 	margin-left:0pt; 	text-align:left;";s:8:"style_h5";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:14px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h6";s:182:"	color:#FFFFFF; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:7:"style_a";s:91:"	color:#08395A; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_ul";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_li";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:15:"aca_unsubscribe";s:91:"	color:#08395A; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:13:"aca_subscribe";s:91:"	color:#08395A; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:11:"aca_content";s:91:"	color:#333333; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	margin:0; 	padding:0;";s:9:"aca_title";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:12:"aca_readmore";s:90:"	background-color: #025B87;     font-family: Arial,Helvetica,Serif;     padding: 3px 10px;";s:10:"aca_online";s:91:"	color:#FFFFFF; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/entwine_blue.png', 1, '#outlook a{padding:0;} \nimg{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}\n\nbody, p, td{\n	color:#333333;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	margin:0;\n	padding:0;\n}\n\na, .online, .subscriptions, .unsubscribe{\n	color:#08395A;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.online{\n	color:#FFFFFF;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n\nh1, h1 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:36px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh2, h2 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:30px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nh3, h3 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:24px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:30px;\n	margin-left:0pt;\n}\n\nh4, h4 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:18px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:10px;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh5, h5 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:14px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh6, h6 a{\n	color:#FFFFFF;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nul,li{\n	line-height:150%;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.readmore{\n	background-color: #025B87;\n    font-family: Arial,Helvetica,Serif;\n    padding: 3px 10px;\n}\n\n.readmore a{\n	color:#ffffff;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}'),
(3, 'Acajoom Template', 'A simple single column template suitable for any kind of occasions with a clean and sharp designed to align your company''s identity. The default newsletter template mostly used in Acajoom. \r\n', '<table style="width: 100%; margin: 0pt auto; background-color:#f1f1f1; color: #333333;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="530" bgcolor="#f1f1f1">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#ffffff"><img src="media/com_jnews/templates/acajoom/tpl0_top_header.jpg" border="0" alt="Newsletter" width="530" height="137" style="display:block;" /></td>\n</tr>\n<tr>\n<td colspan="3" bgcolor="#ffffff"><img src="media/com_jnews/templates/acajoom/tpl0_underban.jpg" border="0" width="530" height="22" style="display:block;" /></td>\n</tr>\n<tr>\n<td width="15" valign="top" bgcolor="#ffffff"><img src="media/com_jnews/templates/acajoom/tpl0_spacer.gif" border="0" width="15" height="1" style="display:block;" /></td>\n<td width="500" valign="top" bgcolor="#ffffff">\n<table border="0" cellspacing="15" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="2"><img src="media/com_jnews/templates/acajoom/spacer.png" border="0" height="20px" /></td>\n</tr>\n<tr>\n<td colspan="2" align="center">\n<h2>jNews is now out in the market</h2>\n</td>\n</tr>\n<tr>\n<td colspan="2"><img src="media/com_jnews/templates/acajoom/spacer.png" border="0" height="20px" /></td>\n</tr>\n<tr>\n<td width="180px" valign="top"><img src="http://joobi.co/images/jnews_newsletter.png" border="0" style="display:block;" /></td>\n<td width="320px" valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="4">\n<p>Hi {tag:name},</p>\n<br />\n<p>This 2010, we are coming out with an application that will bring email marketing to the next generation. This is jNews.</p>\n<br />\n<p>jNews is our newest products, an email marketing application for Joomla 1.5 with the most powerful and coolest features ever marking sure that your communications yields the best results that you want best.</p>\n<br /> {tag:share name=facebook,linkedin,twitter}<br /> <br /> <br /></td>\n</tr>\n<tr>\n<td style="width: 5px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jmarket/Itemid,49/controller,product-display/eid,82/task,show/">Product Presentation</a></td>\n<td style="width: 6px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/Help/jNews/Table-of-Contents-jNews.html">Documentation</a></td>\n<td style="width: 5px;"></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td colspan="2"><br /> \n<hr />\n<p>Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\n<br /></td>\n</tr>\n<tr>\n<td colspan="2" width="100%">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td style="width: 37px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jtickets/Itemid,147/controller,ticket/">Support</a></td>\n<td style="width: 15px;" width="15px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_agora/Itemid,60/">Forum</a></td>\n<td style="width: 15px;" width="15px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/organization/about/welcome-to-joobi-live-support.html">Live Admin</a></td>\n<td style="width: 20px;"></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td colspan="2"><br />\n<p>Your Subscription: {tag:subscriptions} | {tag:unsubscribe}</p>\n<br /></td>\n</tr>\n</tbody>\n</table>\n</td>\n<td width="15" valign="top" bgcolor="#ffffff"><img src="media/com_jnews/templates/acajoom/tpl0_spacer.gif" border="0" alt="1" width="15" height="1" style="display:block;" /></td>\n</tr>\n<tr>\n<td colspan="3"><img src="media/com_jnews/templates/acajoom/tpl0_abovefooter.jpg" border="0" alt="." width="530" height="22" style="display:block;" /></td>\n</tr>\n<tr>\n<td style="border-top: 1px solid #aeaeae;" colspan="3" height="60" align="center" valign="middle" bgcolor="#cacaca">\n<p class="footerText"><a href="http://www.joobi.co"><img src="media/com_jnews/templates/acajoom/tpl0_powered_by.gif" border="0" alt="Powered by Joobi" height="20" style="display:block;" /></a></p>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>', '', 1285292068, 1, 0, 99, 'acajoom_template', 'a:16:{s:8:"color_bg";s:7:"#f1f1f1";s:8:"style_h1";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:36px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h2";s:198:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:30px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:8:"style_h3";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:8:"style_h4";s:217:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:18px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:10px; 	margin-left:0pt; 	text-align:left;";s:8:"style_h5";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:14px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h6";s:182:"	color:#FFFFFF; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:7:"style_a";s:91:"	color:#43adde; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_ul";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_li";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:15:"aca_unsubscribe";s:91:"	color:#43adde; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:13:"aca_subscribe";s:91:"	color:#43adde; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:11:"aca_content";s:91:"	color:#333333; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	margin:0; 	padding:0;";s:9:"aca_title";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:12:"aca_readmore";s:109:"	background-color: #454545;     font-family: Arial,Helvetica,Serif;     padding: 3px 10px; text-align:center;";s:10:"aca_online";s:91:"	color:#43adde; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/acajoom_template.png', 1, '#outlook a{padding:0;} \nimg{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}\n\nbody, p, td{\n	color:#333333;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	margin:0;\n	padding:0;\n}\n\na, .online, .subscriptions, .unsubscribe, .online{\n	color:#43adde;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\nh1, h1 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:36px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh2, h2 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:30px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nh3, h3 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:24px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:30px;\n	margin-left:0pt;\n}\n\nh4, h4 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:18px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:10px;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh5, h5 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:14px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh6, h6 a{\n	color:#FFFFFF;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nul,li{\n	line-height:150%;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.readmore{\n	background-color: #454545;\n        font-family: Arial,Helvetica,Serif;\n        padding: 3px 10px;\n        text-align:center;\n}\n\n.readmore a{\n	color:#ffffff;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	text-align:center;\n}'),
(4, 'Elegant Navy', 'A unique and beautiful two layout newsletter template designed to present current news and let your customers updated.', '<style type="text/css">\n	a{border-top:1px solid #000;}\n</style>\n\n<table cellpadding="0" cellspacing="0" border="0" style="width:100%;margin:0; background-color: #054669; color: #ffffff; font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n	<tbody>\n		<tr>\n			<td align="center">\n				<table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto;width:575px;">\n					<tbody>\n						<tr>\n							<td style="width:14px">&nbsp;</td>\n							<td style="width:547px;">\n								<table style="width: 547px; height: 70px;" border="0" cellspacing="0">\n									<tbody>\n										<tr>\n											<td style="background-color: #ffffff;width:147px;height:70px;padding:0;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;" valign="top" width="146px" height="70px">\n												<img src="http://www.joobi.co/images/newsletter_templates/elegant/jnews_logo.png">\n											</td>\n											<td style="text-align: left; padding: 10px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;background-color:#054669;" bgcolor="#054669">\n												<span style="font-size: 2em; color: #fff;">\n													LOGO &amp;trade\n												</span>\n												<br/>\n												<span style="font-size: 1em; color: #fff;">\n													a very wonderful tagline\n												</span>\n											</td>\n											<td style="text-align: right; padding-right: 10px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;background-color:#054669;" bgcolor="#054669" valign="bottom">\n												<span style="font-size: 13px; color: #fff;">\n													{tag:date}\n												</span>\n											</td>\n										</tr>\n									</tbody>\n								</table>\n								<table style="width: 547px;" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFF">\n									<tbody>\n										<tr>\n											<td align="left" valign="top" height="35px">\n												<img src="media/com_jnews/templates/elegant/elegant.gif" border="0" style="display:block;margin:0;float:none;"/>\n											</td>\n										</tr>\n									</tbody>\n								</table>\n								<table style="width: 547px; height: 70px; background-color: #fff;" border="0" cellspacing="0">\n									<tbody>\n										<tr>\n											<td style="padding: 20px 15px 15px 20px; text-align: justify; background-color: #fff; width: 340px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;" valign="top">\n												<span style="color: #329aa7; font-size: 19px;">\n													Lorem ipsum dolor sit amet \n												</span> \n												<br /> \n												<span style="color: #000; font-size: 12px;">\n													"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\n												</span>\n												<br /><br />\n												<table cellpadding="0" cellspacing="0" border="0">\n													<tbody>\n														<tr>\n															<td>\n															</td>\n															<td align="right" style="height:22px; border: 1px solid #329aa7; background-color: #025b87; padding: 2px 8px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n																<span >\n																	<a href="#" style="text-decoration: none; color: #fff; font-size: 12px;">\n																		Read more\n																	</a>\n																</span>\n															</td>\n														</tr>\n													</tbody>\n												</table>\n											</td>\n											<td style="padding: 20px 15px 15px 0;" valign="top">\n												<div style="border: 1px solid #C9C9C9; background-color: #ededed; padding: 4px;">\n													<img src="media/com_jnews/templates/elegant/sample-image.png" border="0" width="172" height="167" style="display:block;margin:0;float:none;width:172px;height:167px;"/>\n												</div>\n											</td>\n										</tr>\n									</tbody>\n								</table>\n							</td>\n							<td style="width:14px">&nbsp;</td>\n						</tr>\n						<tr>\n							<td style="width:14px;background-color: #709a3e;padding:1px 0 0 0;">&nbsp;</td>\n							<td style="background-color:#fff;">\n								<table style="width: 547px; background-color:#fff;" border="0" cellspacing="0" bgcolor="#fff">\n									<tbody>\n										<tr>\n											<td valign="top" style="color: #fff; font-size: 13px;tex-decoration:none; background-color: #709a3e; padding: 2px 8px 0;border:none;width:56px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n												Featured\n											</td>\n											<td>\n												&nbsp;\n											</td>\n										</tr>\n									</tbody>\n								</table>\n							</td>\n							<td style="width:14px">&nbsp;</td>\n						</tr>\n						<tr>\n							<td style="width:14px">&nbsp;</td>\n							<td>\n								<table style="width: 547px; height: 70px; background-color: #fff;" border="0" cellspacing="0">\n									<tbody>\n										<tr>\n											<td style="padding: 20px 0 15px 15px;" valign="top">\n												<div style="border: 1px solid #C9C9C9; background-color: #ededed; padding: 4px;">\n													<img src="media/com_jnews/templates/elegant/sample-image.png" border="0" width="172" height="167" style="display:block;margin:0;float:none;width:172px;height:167px;"/>\n												</div>\n											</td>\n											<td style="padding: 20px 15px 15px 20px; text-align: justify; background-color: #fff; width: 340px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;" valign="top">\n												<table cellpadding="0" cellspacing="0" border="0">\n													<tbody>\n														<tr>\n															<td colspan="2" style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;width: 100%; color: #fff; font-size: 19px; text-decoration: none; border: 1px solid #329aa7; background-color: #025b87;">\n																<span style="padding-left: 10px;">\n																	Lorem ipsum dolor sit amet\n																</span>\n															</td>\n														</tr>\n														<tr>\n															<td colspan="2" style="padding:5px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n															<span style="color: #000; font-size: 12px;">\n																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat..."\n															</span>\n															<br /><br />\n															</td>\n														</tr>\n														<tr>\n															<td style="width:285px;">\n																&nbsp;\n															</td>\n															<td style="height:22px;width:100px;border: 1px solid #329aa7; background-color: #025b87; padding: 2px 8px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n																<span >\n																	<a href="#" style="text-decoration: none; color: #fff; font-size: 12px;">\n																		Read more\n																	</a>\n																</span>\n															</td>\n														</tr>\n													</tbody>\n												</table>\n											</td>\n										</tr>\n										<tr>\n											<td style="padding: 20px 0 15px 15px;" valign="top">\n												<div style="border: 1px solid #C9C9C9; background-color: #ededed; padding: 4px;">\n													<img src="media/com_jnews/templates/elegant/sample-image.png" border="0" width="172" height="167" style="display:block;margin:0;float:none;width:172px;height:167px;"/>\n												</div>\n											</td>\n											<td style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;padding: 20px 15px 15px 20px; text-align: justify; background-color: #fff; width: 340px;" valign="top">\n												<table cellpadding="0" cellspacing="0" border="0">\n													<tbody>\n														<tr>\n															<td colspan="2" style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;width: 100%; color: #fff; font-size: 19px; text-decoration: none; border: 1px solid #329aa7; background-color: #025b87;">\n																<span style="padding-left: 10px;">\n																	Lorem ipsum dolor sit amet\n																</span>\n															</td>\n														</tr>\n														<tr>\n															<td colspan="2" style="padding:5px;">\n															<span style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;color: #000; font-size: 12px;">\n																"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat..."\n															</span>\n															<br /><br />\n															</td>\n														</tr>\n														<tr>\n															<td style="width:285px;">\n																&nbsp;\n															</td>\n															<td style="height:22px;width:100px;border: 1px solid #329aa7; background-color: #025b87; padding: 2px 8px;font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n																<span >\n																	<a href="#" style="text-decoration: none; color: #fff; font-size: 12px;">\n																		Read more\n																	</a>\n																</span>\n															</td>\n														</tr>\n													</tbody>\n												</table>\n											</td>\n										</tr>\n										<tr>\n											<td colspan="2" style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n												<p style="text-align: center; font-size: 12px; color: #000000;">\n													Would you like to change your subscription? {tag:subscriptions}\n													<br /> \n													Not interested any more? {tag:unsubscribe}\n												</p>\n											</td>\n										</tr>\n									</tbody>\n								</table>\n							</td>\n							<td style="width:14px">&nbsp;</td>\n						</tr>\n					</tbody>\n				</table>\n				<table style="width: 100%; background-color: #054669;" border="0" cellspacing="0">\n					<tbody>\n						<tr>\n							<td valign="top" bgcolor="#709a3e" height="20px"> </td>\n							<td style="width: 547px; background-color: #ffffff;" valign="top"> </td>\n							<td valign="top" bgcolor="#709a3e"> </td>\n						</tr>\n						<tr bgcolor="#156e9f">\n							<td colspan="3" align="top" height="80px" style="font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;">\n								<center>\n									<div style="color: #fffff; font-size: 11px; text-align: center; padding-bottom: 5px;">\n										<span style="color: #ffffff;">\n											This email contains graphics, so if you don''t see them, {tag:viewonline name=view it in your browser}.\n										</span>\n									</div>\n								</center>\n								<center>\n									<div style="width: 99%; color: #fff; font-size: 12px; text-align: center;">\n										Powered by Joobi\n									</div>\n								</center>\n							</td>\n						</tr>\n					</tbody>\n				</table>\n			</td>\n		</tr>\n	</tbody>\n</table>', '', 1285292068, 1, 0, 99, 'elegant_navy', 'a:11:{s:8:"color_bg";s:7:"#054669";s:8:"style_h1";s:28:"font-size: 2em; color: #fff;";s:8:"style_h2";s:176:"font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;width: 100%; color: #fff; font-size: 19px; text-decoration: none; border: 1px solid #329aa7; background-color: #025b87;";s:8:"style_h3";s:32:"color: #329aa7; font-size: 19px;";s:8:"style_h4";s:28:"font-size: 1em; color: #fff;";s:8:"style_h5";s:29:"font-size: 13px; color: #fff;";s:8:"style_h6";s:72:"color: #fffff; font-size: 11px; text-align: center; padding-bottom: 5px;";s:7:"style_a";s:15:"color: #329AA7;";s:15:"aca_unsubscribe";s:109:"font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;text-align: center; font-size: 12px; color: #000000;";s:13:"aca_subscribe";s:109:"font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;text-align: center; font-size: 12px; color: #000000;";s:10:"aca_online";s:72:"color: #fffff; font-size: 11px; text-align: center; padding-bottom: 5px;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/elegant_navy.png', 1, 'body, p{font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;color: #000; font-size: 12px;}');
INSERT INTO `analk_jnews_templates` (`template_id`, `name`, `description`, `body`, `altbody`, `created`, `published`, `premium`, `ordering`, `namekey`, `styles`, `thumbnail`, `availability`, `csstyle`) VALUES
(12, 'Simplicity', 'Bring out the best of your content with this light and clean simple newsletter.', '<div style="background-color:#FFFFFF;">\n<p> </p>\n<table style="height: 100%;" border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#9edaf4">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="600">\n<tbody>\n<tr>\n<td valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="2" valign="middle">\n<div>\n<h1><img src="http://www.joobi.co/images/newsletter_templates/simplicity/jnews_logo.png" border="0" width="241px" height="91px" /></h1>\n</div>\n</td>\n</tr>\n<tr>\n<td valign="middle">\n<div>\n<h3>Your Top Communication Partner</h3>\n</div>\n</td>\n<td width="30%" valign="bottom">\n<div style="text-align:right;">\n<h5>{tag:date}</h5>\n</div>\n</td>\n</tr>\n<tr>\n</tr>\n</tbody>\n</table>\n<table border="0" cellspacing="0" cellpadding="0" width="600" bgcolor="#ffffff">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table border="0" cellspacing="30" cellpadding="0" width="600">\n<tbody>\n<tr>\n<td>\n<h2>jNews is now out in the market!</h2>\n</td>\n<td style="margin-top:20px;" rowspan="2"><img src="http://joobi.co/images/jnews_newsletter.png" border="0" width="130px" height="215px" /></td>\n</tr>\n<tr>\n<td valign="top">\n<p>Hi {tag:firstname},<br /><br /> This 2012, we are coming out with a application that will bring email marketing to the next generation. This is jNews. <br /><br /> jNews is our newest products, an email marketing application for Joomla 1.5, 1.6, 1.7 and 2.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want. {tag:share name=facebook,linkedin,twitter}</p>\n</td>\n</tr>\n<tr>\n<td valign="top">\n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td class="readmore" width="113px" height="38px;" align="center" valign="center" background="media/com_jnews/templates/simplicity/images/bttn.png"><a href="#">Live Demo</a></td>\n<td style="width: 30px;" width="10"></td>\n<td class="readmore" width="113px" height="38px;" align="center" valign="center" background="media/com_jnews/templates/simplicity/images/bttn.png"><a href="#">Documentation</a></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td align="center" valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="600">\n<tbody>\n<tr>\n<td colspan="2">\n<hr width="560px" size="1" />\n</td>\n</tr>\n<tr>\n<td width="280" valign="top">\n<table border="0" cellspacing="30" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td valign="top">\n<div>\n<h4>Need Help?</h4>\n<p>Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\n<ul>\n<li>Live Chat</li>\n<li>Support</li>\n<li>Forum</li>\n</ul>\n</div>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td width="280" valign="top">\n<table border="0" cellspacing="30" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td valign="top">\n<div>\n<h4>Spread the News</h4>\n<p>Know someone who might be interested in this newsletter? {tag:fwdtofriend name=Forward to a friend.}</p>\n<br /><br />\n<p>Would you like to {tag:subscriptions}?<br /> Not interested any more? {tag:unsubscribe}</p>\n</div>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td align="center" valign="top">\n<table border="0" cellspacing="0" cellpadding="0" width="600" bgcolor="#9edaf4">\n<tbody>\n<tr>\n<td valign="top">\n<table border="0" cellspacing="30" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="2" align="center" valign="middle">\n<div><a class="footer" href="#">This email contains graphics, if you don''t see them {tag:viewonline name=view it in your browser}.</a><br /> <a class="footer" href="#">Powered by Joobi</a></div>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</div>', '', 1319652945, 1, 1, 99, 'simplicity', 'a:12:{s:8:"color_bg";s:7:"#FFFFFF";s:8:"style_h1";s:197:"color:#ffffff; display:block; font-family:Arial,Helvetica,Serif; font-size:48px; font-weight:bold; line-height:100%; margin-bottom:0px; margin-left:0; margin-right:0; margin-top:0; text-align:left;";s:8:"style_h2";s:182:"color:#355f77; display:block; font-family:Arial,Helvetica,Serif; font-size:24px; font-weight:normal; line-height:100%; margin-bottom:0px; margin-left:0; margin-right:0; margin-top:0;";s:8:"style_h3";s:216:"color:#4f88a7; display:block; font-family:Arial,Helvetica,Serif; font-size:14px; font-weight:normal; line-height:100%; margin-bottom:30px; margin-left:0; margin-right:0; margin-top:0; text-shadow:1px 0px 0px #aee0f6;";s:8:"style_h4";s:200:"color:#355f77; display:block; font-family:Arial,Helvetica,Serif; font-size:18px; font-weight:normal; line-height:100%; margin-bottom:10px; margin-left:0; margin-right:0; margin-top:0; text-align:left;";s:8:"style_h5";s:216:"color:#4f88a7; display:block; font-family:Arial,Helvetica,Serif; font-size:13px; font-weight:normal; line-height:100%; margin-bottom:30px; margin-left:0; margin-right:0; margin-top:0; text-shadow:1px 0px 0px #aee0f6;";s:7:"style_a";s:87:"color:#416e86; font-family:Arial,Helvetica,Serif; font-size:13px; text-decoration:none;";s:8:"style_ul";s:83:"color:#416e86; font-family:Arial,Helvetica,Serif; font-size:13px; line-height:200%;";s:8:"readmore";s:173:"background-color:#b5e2f7; background-repeat:no-repeat; height:38px; margin-bottom:10px; margin-left:10px; margin-right:10px; margin-top:10px; text-align:center; width:113px;";s:16:"style_aca_online";s:87:"color:#416e86; font-family:Arial,Helvetica,Serif; font-size:13px; text-decoration:none;";s:21:"style_aca_unsubscribe";s:87:"color:#416e86; font-family:Arial,Helvetica,Serif; font-size:13px; text-decoration:none;";s:13:"subscriptions";s:87:"color:#416e86; font-family:Arial,Helvetica,Serif; font-size:13px; text-decoration:none;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/simplicity_tmbl.png', 1, '#outlook a{padding:0;} \nimg{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}\n\nbody, p, td{\n	color:#1e1f1f;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n	line-height:150%;\n	margin:0;\n	padding:0;\n}\n\na, .online, .subscriptions, .unsubscribe{\n	color:#416e86;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n}\n\nh1, h1 a{\n	color:#ffffff;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:48px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0;\n	margin-right:0;\n	margin-bottom:0px;\n	margin-left:0;\n	text-align:left;\n}\n\nh2, h2 a{\n	color:#355f77;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:24px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0;\n	margin-right:0;\n	margin-bottom:0px;\n	margin-left:0;\n	\n}\n\nh3, h3 a{\n	color:#4f88a7;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:14px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0;\n	margin-right:0;\n	margin-bottom:30px;\n	margin-left:0;\n	text-shadow:1px 0px 0px #aee0f6;\n}\n\nh4, h4 a{\n	color:#355f77;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:18px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0;\n	margin-right:0;\n	margin-bottom:10px;\n	margin-left:0;\n	text-align:left;\n}\n\nh5, h5 a{\n	color:#4f88a7;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0;\n	margin-right:0;\n	margin-bottom:30px;\n	margin-left:0;\n	text-shadow:1px 0px 0px #aee0f6;\n}\n\nul, li{\n	color:#416e86;\n	line-height:200%;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n}\n\n.readmore{\n	background-color:#b5e2f7;\n	background-repeat:no-repeat;\n	margin-top:10px;\n	margin-right:10px;\n	margin-bottom:10px;\n	margin-left:10px;\n	width:113px;\n	height:38px; \n	text-align:center;\n}\n\n.readmore a{\n	color:#416e86;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n}\n\n.footer, .footer a {\n	color:#4f88a7;\n	font-family:Arial,Helvetica,Serif;\n	font-size:13px;\n	text-align:center;\n}'),
(13, 'Entwine (green)', 'A classic two columns layout designed with a twist of modern curves in green color, highlighting headline titles valuable for your newsletter to attract more customer, best for promos and events.', '<table style="width: 100%; margin: 0pt auto; background-color:#003300; color: #333333; font-family: Arial,Tahoma,Geneva,Kalimati,sans-serif;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td align="center" valign="top">\n<table style="margin: auto; width: 700px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" align="right" valign="top"><img src="media/com_jnews/templates/entwine/green/topleft_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td>\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td height="58" bgcolor="#4f7e11">\n<table border="0" cellspacing="0" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td style="width: 70%;">\n<h1><img src="http://www.joobi.co/images/newsletter_templates/entwine/green/logo-big.png" border="0" alt="jnews logo" style="margin-left: 20px;display:block;margin:0;" /></h1>\n</td>\n<td style="width: 30%;" align="right">\n<h6>{tag:date}</h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="background-color: #ffffff; height: 58px; text-align: center;" height="58">\n<h2>jNews is now out in the market!</h2>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/green/topright_header.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 700px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style=" font-family: Arial, Tahoma, Geneva, Kalimati, sans-serif;"><span style="font-size: 12px; color: #003300;">joobi</span></td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 680px; background-color: #ffffff;" border="0" cellspacing="20" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 250px;" width="250" align="left" valign="top">\n<p style="text-align: center; width: 250px;"><img src="http://joobi.co/images/jnews_newsletter.png" border="0" alt="jNews Upgrade" width="130" height="215" style="display: block; border: 0; margin: 0px auto;" /></p>\n<h3>What is it in for you?</h3>\n<ul>\n<li>Template Management</li>\n<li>Queue Management</li>\n<li>Advanced Statistics</li>\n<li>Sending Process</li>\n</ul>\n</td>\n<td valign="top">\n<p>Hi {tag:name},</p>\n<br />\n<p>This 2010, we are coming out with a application that will bring email marketing to the next generation. This is jNews.<br /><br /> jNews is our newest products, an email marketing application for Joomla 1.5 with the most powerful and coolest features ever making sure that your communications yields the best results that you want.</p>\n<br />\n<p>{tag:share name=facebook,linkedin,twitter}</p>\n<br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 49px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jmarket/Itemid,49/controller,product-display/eid,82/task,show/"> Product Presentation </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/Help/jNews/Table-of-Contents-jNews.html"> Documentation </a><br /></td>\n</tr>\n</tbody>\n</table>\n<hr style="width: 98%;" />\n<p style="font-size:12px;">Should you have questions, comments, feature requests, do not hesitate to contact our support or chat live with them.</p>\n<br /><br /> \n<table border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 55px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_jtickets/Itemid,147/controller,ticket/"> Support </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/component/option,com_agora/Itemid,60/"> Forum </a></td>\n<td style="width: 20px;"></td>\n<td class="readmore"><a href="http://www.joobi.co/organization/about/welcome-to-joobi-live-support.html"> Live Admin </a></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td colspan="2" align="center">Would you like to change your subscription? {tag:subscriptions}<br /> Not interested any more? {tag:unsubscribe}</td>\n</tr>\n</tbody>\n</table>\n<table style="margin: auto; width: 702px; height: 70px;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td style="width: 8px;" rowspan="2" valign="top"><img src="media/com_jnews/templates/entwine/green/bottom_left_green.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n<td style="width: 686px;">\n<table style="width: 100%;" border="0" cellspacing="0" cellpadding="0">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#ffffff"><span style="font-size: 16px; color: #fff;"> joobi </span></td>\n</tr>\n<tr>\n<td height="118" bgcolor="#4f7e11">\n<table border="0" cellspacing="5" cellpadding="0" width="100%">\n<tbody>\n<tr>\n<td colspan="3" bgcolor="#4f7e11">\n<table border="0" cellspacing="0" cellpadding="5" width="100%">\n<tbody>\n<tr>\n<td>\n<h5>Latest Testimonials</h5>\n<h6>It feels to me that live chat is the absolute best way to provide customer support...</h6>\n<br /> <a href="#"> Read more </a></td>\n<td>\n<h5>More Powerful Features!</h5>\n<h6>Wanted to design your own newsletter template? Check our jNews PRO version.</h6>\n<br /> <a href="#"> See more </a></td>\n<td valign="bottom"><img src="http://www.joobi.co/images/newsletter_templates/entwine/green/logo-small.png" border="0" alt="jnewsletter logo" style="margin:0 0 0 20px;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n<tr>\n<td style="text-align:center;" align="center" valign="top" bgcolor="#003300"><br />\n<h6>This email contains graphics, so if you don''t see them, {tag:viewonline name=view it in your browser}.</h6>\n<br />\n<h6>Powered by Joobi</h6>\n<h6><br /><br /></h6>\n</td>\n</tr>\n</tbody>\n</table>\n</td>\n<td style="width: 8px;" rowspan="2" align="left" valign="top"><img src="media/com_jnews/templates/entwine/green/bottom_right_green.png" border="0" alt="jnews logo" style="display:block;margin:0;" /></td>\n</tr>\n</tbody>\n</table>\n</td>\n</tr>\n</tbody>\n</table>', '', 1285292068, 1, 0, 99, 'entwine_green', 'a:16:{s:8:"color_bg";s:7:"#003300";s:8:"style_h1";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:36px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h2";s:198:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:30px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:8:"style_h3";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:8:"style_h4";s:217:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:18px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:10px; 	margin-left:0pt; 	text-align:left;";s:8:"style_h5";s:214:"	color:#FFFFFF; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:14px; 	font-weight:bold; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt; 	text-align:left;";s:8:"style_h6";s:182:"	color:#FFFFFF; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:0pt; 	margin-left:0pt;";s:7:"style_a";s:90:"color:#003300; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_ul";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:8:"style_li";s:71:"	line-height:150%; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:15:"aca_unsubscribe";s:90:"color:#003300; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:13:"aca_subscribe";s:90:"color:#003300; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";s:11:"aca_content";s:91:"	color:#333333; 	font-family:Arial,Helvetica,Serif; 	font-size:12px; 	margin:0; 	padding:0;";s:9:"aca_title";s:90:"	background-color: #003300;     font-family: Arial,Helvetica,Serif;     padding: 3px 10px;";s:12:"aca_readmore";s:199:"	color:#333333; 	display:block; 	font-family:Arial,Helvetica,Serif; 	font-size:24px; 	font-weight:normal; 	line-height:100%; 	margin-top:0pt; 	margin-right:0pt; 	margin-bottom:30px; 	margin-left:0pt;";s:10:"aca_online";s:91:"	color:#4f7e11; 	text-decoration:none; 	font-family:Arial,Helvetica,Serif; 	font-size:12px;";}', 'http://www.joobi.co/images/newsletter_templates/thumbnails/entwine_green.png', 1, '#outlook a{padding:0;} \nimg{border:0; height:auto; line-height:100%; outline:none; text-decoration:none;}\n\nbody, p, td{\n	color:#333333;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	margin:0;\n	padding:0;\n}\n\na, .online, .subscriptions, .unsubscribe{\n	color:#003300;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.online{\n	color:#4f7e11;\n	text-decoration:none;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n\nh1, h1 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:36px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh2, h2 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:30px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nh3, h3 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:24px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:30px;\n	margin-left:0pt;\n}\n\nh4, h4 a{\n	color:#333333;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:18px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:10px;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh5, h5 a{\n	color:#FFFFFF;\n	display:block;\n	font-family:Arial,Helvetica,Serif;\n	font-size:14px;\n	font-weight:bold;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n	text-align:left;\n}\n\nh6, h6 a{\n	color:#FFFFFF;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n	font-weight:normal;\n	line-height:100%;\n	margin-top:0pt;\n	margin-right:0pt;\n	margin-bottom:0pt;\n	margin-left:0pt;\n}\n\nul,li{\n	line-height:150%;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}\n\n.readmore{\n	background-color: #003300;\n    font-family: Arial,Helvetica,Serif;\n    padding: 3px 10px;\n}\n\n.readmore a{\n	color:#ffffff;\n	font-family:Arial,Helvetica,Serif;\n	font-size:12px;\n}'),
(14, 'Bliss (blue)', 'A blend of perfect yet subtle joy and serenity taken from its clean minimalistic design.', NULL, NULL, NULL, 1, 0, 99, 'bliss_blue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/bliss_blue.png', 0, ''),
(15, 'Bliss (green)', 'A blend of perfect yet subtle joy and serenity taken from its clean minimalistic design.', NULL, NULL, NULL, 1, 0, 99, 'bliss_green', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/bliss_green.png', 0, ''),
(16, 'Bliss (orange)', 'A blend of perfect yet subtle joy and serenity taken from its clean minimalistic design.', NULL, NULL, NULL, 1, 0, 99, 'bliss_orange', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/bliss_orange.png', 0, ''),
(17, 'Bliss (red)', 'A blend of perfect yet subtle joy and serenity taken from its clean minimalistic design.', NULL, NULL, NULL, 1, 0, 99, 'bliss_red', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/bliss_red.png', 0, ''),
(18, 'Delight (lightgreen)', 'A suitable template suited for your business, personal, organization, or recreational newsletters.', NULL, NULL, NULL, 1, 0, 99, 'delight_lightgreen', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/delight_lightgreen.png', 0, ''),
(19, 'Delight (orange)', 'A suitable template suited for your business, personal, organization, or recreational newsletters.', NULL, NULL, NULL, 1, 0, 99, 'delight_orange', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/delight_orange.png', 0, ''),
(20, 'Delight (orchid)', 'A suitable template suited for your business, personal, organization, or recreational newsletters.', NULL, NULL, NULL, 1, 0, 99, 'delight_orchid', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/delight_orchid.png', 0, ''),
(21, 'Delight (steelblue)', 'A suitable template suited for your business, personal, organization, or recreational newsletters.', NULL, NULL, NULL, 1, 0, 99, 'delight_steelblue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/delight_steelblue.png', 0, ''),
(22, 'Delight (thistle)', 'A suitable template suited for your business, personal, organization, or recreational newsletters.', NULL, NULL, NULL, 1, 0, 99, 'delight_thistle', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/delight_thistle.png', 0, ''),
(23, 'Eldiario (black)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (black) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_black', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_black.png', 0, ''),
(24, 'Eldiario (blue)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (blue) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_blue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_blue.png', 0, ''),
(25, 'Eldiario (green)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (green) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_green', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_green.png', 0, ''),
(26, 'Eldiario (lightblue)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (lightblue) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_lightblue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_lightblue.png', 0, ''),
(27, 'Eldiario (lightgreen)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (lightgreen) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_lightgreen', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_lightgreen.png', 0, ''),
(28, 'Eldiario (lightred)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (lightred) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_lightred', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_lightred.png', 0, ''),
(29, 'Eldiario (red)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (red) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_red', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_red.png', 0, ''),
(30, 'Eldiario (white)', 'Engaged your customers with a clean newsletter template, well organize information. El Diario (white) can be used at its best with several contents.', NULL, NULL, NULL, 1, 0, 99, 'eldiario_white', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/eldiario_white.png', 0, ''),
(31, 'Flare (black)', 'Flame up with, Flare! Flare (black) is a combination of classical yet modern and simple beauty; the level of intensity that your newsletter needs.', NULL, NULL, NULL, 1, 0, 99, 'flare_black', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/flare_black.png', 0, ''),
(32, 'Flare (maroon)', 'Flame up with, Flare! Flare (maroon) is a combination of classical yet modern and simple beauty; the level of intensity that your newsletter needs.', NULL, NULL, NULL, 1, 0, 99, 'flare_maroon', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/flare_maroon.png', 0, ''),
(33, 'Flare (orange)', 'Flame up with, Flare! Flare (orange) is a combination of classical yet modern and simple beauty; the level of intensity that your newsletter needs.', NULL, NULL, NULL, 1, 0, 99, 'flare_orange', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/flare_orange.png', 0, ''),
(34, 'Flare (teal)', 'Flame up with, Flare! Flare (teal) is a combination of classical yet modern and simple beauty; the level of intensity that your newsletter needs.', NULL, NULL, NULL, 1, 0, 99, 'flare_teal', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/flare_teal.png', 0, ''),
(35, 'Optimum (darkblue)', 'Optimum (darkblue) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_darkblue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_darkblue.png', 0, ''),
(36, 'Optimum (darkgreen)', 'Optimum (darkgreen) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_darkgreen', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_darkgreen.png', 0, ''),
(37, 'Optimum (darkred)', 'Optimum (darkred) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_darkred', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_darkred.png', 0, ''),
(38, 'Optimum (lightblue)', 'Optimum (lightblue) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_lightblue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_lightblue.png', 0, ''),
(39, 'Optimum (lightgreen)', 'Optimum (lightgreen) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_lightgreen', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_lightgreen.png', 0, ''),
(40, 'Optimum (lightred)', 'Optimum (lightred) has a professional touch of modern and futuristic style, driving you to its optimal level. It is designed to guide your eyes to your important newsletter content using good balance of white space.', NULL, NULL, NULL, 1, 0, 99, 'optimum_lightred', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/optimum_lightred.png', 0, ''),
(41, 'Royale (gold)', 'Step aboard and see the timeless form of pattern and style, Royale in gold. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_gold', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_gold.png', 0, ''),
(42, 'Royale (blue)', 'Step aboard and see the timeless form of pattern and style, Royale in blue. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_blue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_blue.png', 0, ''),
(43, 'Royale (green)', 'Step aboard and see the timeless form of pattern and style, Royale in green. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_green', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_green.png', 0, ''),
(44, 'Royale (red)', 'Step aboard and see the timeless form of pattern and style, Royale in red. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_red', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_red.png', 0, ''),
(45, 'Royale (silver)', 'Step aboard and see the timeless form of pattern and style, Royale in silver. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_silver', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_silver.png', 0, ''),
(46, 'Royale (violet)', 'Step aboard and see the timeless form of pattern and style, Royale in violet. Paint your newsletter with royalty to present your pictures and website updates that would leave your customer with nothing but fabulous feelings.', NULL, NULL, NULL, 1, 0, 99, 'royale_violet', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/royale_violet.png', 0, ''),
(47, 'Christmas Company', 'Greet your employees, clients or partners a Merry Christmas.', NULL, NULL, 1291654431, 1, 0, 1, 'christmas_company', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/christmas_company.jpg', 0, ''),
(48, 'Christmas Family', 'Don''t forget your family and give them a heart-warming white Christmas.', NULL, NULL, 1291654431, 1, 0, 2, 'christmas_family', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/christmas_family.jpg', 0, ''),
(49, 'Christmas Friends', 'Bring fun to a snowy yet fun Holiday with your colleagues and friends.', NULL, NULL, 1291654431, 1, 0, 3, 'christmas_friends', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/christmas_friends.jpg', 0, ''),
(50, 'Christmas Religion', 'Send the spirit of Christmas and sincere wish to your churchmates, parents, or relatives.', NULL, NULL, 1291654431, 1, 0, 4, 'christmas_religion', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/christmas_religion.jpg', 0, ''),
(51, 'Christmas Special', 'Give happiness to your special someone this Christmas.', NULL, NULL, 1291654431, 1, 0, 5, 'christmas_special', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/christmas_special.jpg', 0, ''),
(52, 'Newyear Company', 'Wish a prosperous New Year to your business, clients and customers.', NULL, NULL, 1291654431, 1, 0, 6, 'newyear_company', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/newyear_company.jpg', 0, ''),
(53, 'Newyear Family', 'A heavenly soothing design for your family to put a smile.', NULL, NULL, 1291654431, 1, 0, 7, 'newyear_family', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/newyear_family.jpg', 0, ''),
(54, 'Newyear Friends', 'Send a refreshing year greeting specially designed for your friends.', NULL, NULL, 1291654431, 1, 0, 8, 'newyear_friends', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/newyear_friends.jpg', 0, ''),
(55, 'Newyear Religion', 'Do you have New Year resolution already? A conservative yet slick designed for your churchmates and friends.', NULL, NULL, 1291654431, 1, 0, 9, 'newyear_religion', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/newyear_religion.jpg', 0, ''),
(56, 'Newyear Special', 'Be unforgettable and melt her/his heart this New Year.', NULL, NULL, 1291654431, 1, 0, 10, 'newyear_special', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/newyear_special.jpg', 0, ''),
(57, 'Unison (purple)', 'Community designed newsletter, also suitable for business, portfolio, personal, organization or crecreational sites.', NULL, NULL, NULL, 1, 0, 99, 'unison_purple', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/unison_purple.jpg', 0, ''),
(58, 'Unison (green)', 'Community designed newsletter, also suitable for business, portfolio, personal, organization or crecreational sites.', NULL, NULL, NULL, 1, 0, 99, 'unison_green', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/unison_green.jpg', 0, ''),
(59, 'Unison (flesh)', 'Community designed newsletter, also suitable for business, portfolio, personal, organization or crecreational sites.', NULL, NULL, NULL, 1, 0, 99, 'unison_flesh', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/unison_flesh.jpg', 0, ''),
(60, 'Unison (brown)', 'Community designed newsletter, also suitable for business, portfolio, personal, organization or crecreational sites.', NULL, NULL, NULL, 1, 0, 99, 'unison_brown', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/unison_brown.jpg', 0, ''),
(61, 'Unison (blue)', 'Community designed newsletter, also suitable for business, portfolio, personal, organization or crecreational sites.', NULL, NULL, NULL, 1, 0, 99, 'unison_blue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/unison_blue.jpg', 0, ''),
(62, 'Compassion Christmas', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_christmas', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_christmas.jpg', 0, ''),
(63, 'Compassion Halloween', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_halloween', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_halloween.jpg', 0, ''),
(64, 'Compassion Independence', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_independence', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_independence.jpg', 0, ''),
(65, 'Compasion Newyear', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_newyear', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_newyear.jpg', 0, ''),
(66, 'Compasion Thanksgiving', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_thanksgiving', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_thanksgiving.jpg', 0, ''),
(67, 'Compassion Valentines', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_valentines', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_valentines.jpg', 0, ''),
(68, 'Compassion Womensday', 'Embrace change with Compassion which is best for photography, portfolio, blog and business newsletters.', NULL, NULL, NULL, 1, 0, 99, 'compassion_womensday', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/compassion_womensday.jpg', 0, ''),
(69, 'Silence (blue)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_blue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_blue.jpg', 0, ''),
(70, 'Silence (brown)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_brown', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_brown.jpg', 0, ''),
(71, 'Silence (darkblue)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkblue', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkblue.jpg', 0, ''),
(72, 'Silence (darkbrown)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkbrown', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkbrown.jpg', 0, ''),
(73, 'Silence (darkgreen)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkgreen', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkgreen.jpg', 0, ''),
(74, 'Silence (darkorange)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkorange', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkorange.jpg', 0, ''),
(75, 'Silence (darkred)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkred', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkred.jpg', 0, ''),
(76, 'Silence (darkviolet)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_darkviolet', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_darkviolet.jpg', 0, ''),
(77, 'Silence (green)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_green', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_green.jpg', 0, ''),
(78, 'Silence (orange)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_orange', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_orange.jpg', 0, ''),
(79, 'Silence (purple)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_purple', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_purple.jpg', 0, ''),
(80, 'Silence (red)', 'Highlight the contents with Silence suitable for your portfolio, photo blog, personal, business, organization or recreational newsletter.', NULL, NULL, NULL, 1, 0, 99, 'silence_red', NULL, 'http://www.joobi.co/images/newsletter_templates/thumbnails/silence_red.jpg', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_jnews_xonfig`
--

CREATE TABLE IF NOT EXISTS `analk_jnews_xonfig` (
  `akey` varchar(32) NOT NULL DEFAULT '',
  `text` varchar(254) NOT NULL DEFAULT '',
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`akey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_jnews_xonfig`
--

INSERT INTO `analk_jnews_xonfig` (`akey`, `text`, `value`) VALUES
('show_unsubscribelink', '1', 0),
('show_subscriptionlink', '1', 0),
('upload_url', '/media/com_jnews/upload', 0),
('sntag_norequired', '1', 0),
('sendmail_email', '', 0),
('subs_redirect_url', '', 0),
('subscribe_notification', '', 0),
('unsubscribe_notification', '', 0),
('component_theme', 'joobilist', 0),
('allow_fe_autoresponder', '0', 0),
('archive_link', 'standard', 0),
('component', 'jNews', 0),
('type', 'Core', 0),
('version', '8.3.1', 0),
('level', '1', 0),
('emailmethod', 'mail', 0),
('sendmail_from', '', 0),
('sendmail_name', '', 0),
('sendmail_path', '', 0),
('smtp_host', '', 0),
('smtp_port', '25', 0),
('smtp_auth_required', '', 0),
('smtp_secure', '', 0),
('smtp_username', '', 0),
('smtp_password', '', 0),
('embed_images', '0', 0),
('enable_statistics', '1', 0),
('statistics_per_subscriber', '1', 0),
('send_data', '1', 0),
('allow_unregistered', '1', 0),
('require_confirmation', '0', 0),
('redirectconfirm', '', 0),
('show_login', '1', 0),
('show_logout', '1', 0),
('send_unsubcribe', '1', 0),
('confirm_fromname', '', 0),
('confirm_fromemail', '', 0),
('confirm_html', '0', 0),
('time_zone', '0', 0),
('show_archive', '1', 0),
('pause_time', '20', 0),
('emails_between_pauses', '65', 0),
('wait_for_user', '0', 0),
('script_timeout', '0', 0),
('display_trace', '1', 0),
('send_log', '1', 0),
('send_auto_log', '0', 0),
('send_log_simple', '0', 0),
('send_log_closed', '1', 0),
('save_log', '0', 0),
('send_email', '1', 0),
('save_log_simple', '0', 0),
('save_log_file', '/administrator/components/com_jnews/com_jnews.log', 0),
('send_log_address', '@joobi.co', 0),
('send_log_name', 'jNews Mailing Report', 0),
('homesite', 'http://www.joobi.co', 0),
('report_site', 'http://www.joobi.co', 0),
('integration', '0', 0),
('cb_plugin', '1', 0),
('cb_listIds', '0', 0),
('cb_intro', '', 0),
('cb_showname', '1', 0),
('cb_checkLists', '1', 0),
('cb_showHTML', '1', 0),
('cb_defaultHTML', '1', 0),
('cb_integration', '0', 0),
('cb_pluginInstalled', '0', 0),
('cron_max_freq', '10', 0),
('cron_max_emails', '60', 0),
('last_cron', '', 0),
('next_cron', '1442115955', 0),
('last_sub_update', '1442203326', 0),
('next_autonews', '', 0),
('show_footer', '1', 0),
('show_signature', '1', 0),
('update_url', 'http://www.joobi.co/update/', 0),
('date_update', '1442227555', 0),
('update_message', '', 0),
('show_guide', '1', 0),
('news1', '0', 0),
('news2', '0', 0),
('news3', '0', 0),
('cron_setup', '0', 0),
('queuedate', '', 0),
('update_avail', '0', 0),
('show_tips', '1', 0),
('update_notification', '1', 0),
('show_lists', '1', 0),
('use_sef', '0', 0),
('listHTMLeditor', '1', 0),
('mod_pub', '1', 0),
('firstmailing', '0', 0),
('nblist', '9', 0),
('license', '', 0),
('token', '', 0),
('maintenance', '', 0),
('admin_debug', '0', 0),
('send_error', '1', 0),
('report_error', '1', 0),
('fullcheck', '0', 0),
('frequency', '0', 0),
('nb_days', '7', 0),
('date_type', '1', 0),
('arv_cat', '', 0),
('arv_sec', '', 0),
('maintenance_clear', '24', 0),
('clean_stats', '90', 0),
('maintenance_date', '', 0),
('mail_format', '0', 0),
('mail_encoding', '0', 0),
('showtag', '0', 0),
('show_author', '0', 0),
('addEmailRedLink', '0', 0),
('itemidAca', '999', 0),
('show_jcalpro', '0', 0),
('show_jlinks', '0', 0),
('column1_name', 'Column 1', 0),
('show_column1', '0', 0),
('column2_name', 'Column 2', 0),
('show_column2', '0', 0),
('column3_name', 'Column 3', 0),
('show_column3', '0', 0),
('column4_name', 'Column 4', 0),
('show_column4', '0', 0),
('column5_name', 'Column 5', 0),
('show_column5', '0', 0),
('url_pass', 'g3wp7EPWzB5ZI8', 0),
('subscription_notify', '0', 0),
('disabletooltip', '0', 0),
('minisendmail', '0', 0),
('word_wrap', '0', 0),
('effects', 'normal', 0),
('max_queue', '', 0),
('max_attempts', '', 0),
('sched_prior', '5', 0),
('ar_prior', '1', 0),
('sm_prior', '5', 0),
('j_cron', '2', 0),
('priord_list', '0', 0),
('priord_subs', '0', 0),
('show_unsubscribe', '0', 0),
('queue_status', '1', 0),
('captcha_code', 'y9Ym5YjyxLS5pCU', 0),
('smart_queue', '0', 0),
('sub_info_fields', '0', 0),
('enable_jsub', '0', 0),
('forced_html', '0', 0),
('use_tags', '1', 0),
('use_masterlists', '1', 0),
('list_creatorfe', '24,25,7,8', 0),
('allow_sn', '0', 0),
('show_sub_email', '0', 0),
('create_newsubsrows', '5', 0),
('use_backendview', '0', 0),
('cron_pass', 'E861IqGCC3nVM', 0),
('nextdate', '0', 0),
('lastdate', '0', 0),
('lasttime_cron_triggerred', '0', 0),
('show_unsubscribe_all', '1', 0),
('send_log_email', '', 0),
('dkim_activated', '1', 0),
('dkimpassphrase', '', 0),
('dkimprivate_key_path', '', 0),
('listname0', '', 0),
('listnames0', 'All mailings', 0),
('listype0', '1', 0),
('listshow0', '1', 0),
('classes0', '', 0),
('listlogo0', 'subscribers.png', 0),
('totallist0', '', 1),
('act_totallist0', '', 1),
('totalmailing0', '', 2),
('totalmailingsent0', '', 0),
('act_totalmailing0', '', 2),
('totalsubcribers0', '', 2),
('act_totalsubcribers0', '', 1),
('listname1', '_JNEWS_NEWSLETTER', 0),
('listnames1', '_JNEWS_MENU_NEWSLETTERS', 0),
('listype1', '1', 0),
('listshow1', '1', 0),
('classes1', 'newsletter', 0),
('listlogo1', 'newsletter.png', 0),
('totallist1', '', 1),
('act_totallist1', '', 1),
('totalmailing1', '', 2),
('totalmailingsent1', '', 0),
('act_totalmailing1', '', 2),
('totalsubcribers1', '', 0),
('act_totalsubcribers1', '', 0),
('listname2', '', 0),
('listnames2', '', 0),
('listype2', '', 0),
('listshow2', '', 0),
('classes2', 'jNews_Autoresponder', 0),
('listlogo2', '', 0),
('totallist2', '', 0),
('act_totallist2', '', 0),
('totalmailing2', '', 0),
('totalmailingsent2', '', 0),
('act_totalmailing2', '', 0),
('totalsubcribers2', '', 0),
('act_totalsubcribers2', '', 0),
('listname3', '', 0),
('listnames3', '', 0),
('listype3', '', 0),
('listshow3', '', 0),
('classes3', '', 0),
('listlogo3', '', 0),
('totallist3', '', 0),
('act_totallist3', '', 0),
('totalmailing3', '', 0),
('totalmailingsent3', '', 0),
('act_totalmailing3', '', 0),
('totalsubcribers3', '', 0),
('act_totalsubcribers3', '', 0),
('listname4', '', 0),
('listnames4', '', 0),
('listype4', '', 0),
('listshow4', '', 0),
('classes4', '', 0),
('listlogo4', '', 0),
('totallist4', '', 0),
('act_totallist4', '', 0),
('totalmailing4', '', 0),
('totalmailingsent4', '', 0),
('act_totalmailing4', '', 0),
('totalsubcribers4', '', 0),
('act_totalsubcribers4', '', 0),
('listname5', '', 0),
('listnames5', '', 0),
('listype5', '', 0),
('listshow5', '', 0),
('classes5', '', 0),
('listlogo5', '', 0),
('totallist5', '', 0),
('act_totallist5', '', 0),
('totalmailing5', '', 0),
('totalmailingsent5', '', 0),
('act_totalmailing5', '', 0),
('totalsubcribers5', '', 0),
('act_totalsubcribers5', '', 0),
('listname6', '', 0),
('listnames6', '', 0),
('listype6', '', 0),
('listshow6', '', 0),
('classes6', '', 0),
('listlogo6', '', 0),
('totallist6', '', 0),
('act_totallist6', '', 0),
('totalmailing6', '', 0),
('totalmailingsent6', '', 0),
('act_totalmailing6', '', 0),
('totalsubcribers6', '', 0),
('act_totalsubcribers6', '', 0),
('listname7', '', 0),
('listnames7', '', 0),
('listype7', '', 0),
('listshow7', '', 0),
('classes7', 'jNews_Autonews', 0),
('listlogo7', '', 0),
('totallist7', '', 0),
('act_totallist7', '', 0),
('totalmailing7', '', 0),
('totalmailingsent7', '', 0),
('act_totalmailing7', '', 0),
('totalsubcribers7', '', 0),
('act_totalsubcribers7', '', 0),
('listname8', '', 0),
('listnames8', '', 0),
('listype8', '', 0),
('listshow8', '', 0),
('classes8', '', 0),
('listlogo8', '', 0),
('totallist8', '', 0),
('act_totallist8', '', 0),
('totalmailing8', '', 0),
('totalmailingsent8', '', 0),
('act_totalmailing8', '', 0),
('totalsubcribers8', '', 0),
('act_totalsubcribers8', '', 0),
('activelist', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `imgtitle` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imgauthor` varchar(50) DEFAULT NULL,
  `imgtext` text NOT NULL,
  `imgdate` datetime NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `downloads` int(11) NOT NULL DEFAULT '0',
  `imgvotes` int(11) NOT NULL DEFAULT '0',
  `imgvotesum` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `imgfilename` varchar(255) NOT NULL DEFAULT '',
  `imgthumbname` varchar(255) NOT NULL DEFAULT '',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `owner` int(11) unsigned NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `useruploaded` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `special` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_catid` (`catid`),
  KEY `idx_owner` (`owner`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `analk_joomgallery`
--

INSERT INTO `analk_joomgallery` (`id`, `asset_id`, `catid`, `imgtitle`, `alias`, `imgauthor`, `imgtext`, `imgdate`, `hits`, `downloads`, `imgvotes`, `imgvotesum`, `access`, `published`, `hidden`, `imgfilename`, `imgthumbname`, `checked_out`, `owner`, `approved`, `useruploaded`, `ordering`, `params`, `metakey`, `metadesc`, `special`) VALUES
(3, 67, 4, 'Thắng cảnh thumb', 'thang-canh-thumb-3', '', '', '2015-08-10 03:21:17', 0, 0, 0, 0, 1, 1, 0, 'category_thumb_1_20150810_1054371634.jpg', 'category_thumb_1_20150810_1054371634.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(4, 68, 4, 'Hình 1', 'hinh-1-1-4', '', '', '2015-08-10 05:52:42', 2, 0, 0, 0, 1, 1, 0, 'hinh_1_1_20150810_1371744085.jpeg', 'hinh_1_1_20150810_1371744085.jpeg', 0, 469, 1, 1, 2, '', '', '', 0),
(5, 69, 4, 'Hình 2', 'hinh-2-5', '', '', '2015-08-10 07:00:05', 1, 0, 0, 0, 1, 1, 0, 'hinh_2_20150810_1476162565.jpg', 'hinh_2_20150810_1476162565.jpg', 0, 469, 1, 1, 3, '', '', '', 1),
(6, 71, 5, 'Con người thumb', 'con-nguoi-thumb-6', '', '', '2015-08-11 04:25:12', 0, 0, 0, 0, 1, 1, 0, 'con_ngi_thumb_20150811_2077145597.jpeg', 'con_ngi_thumb_20150811_2077145597.jpeg', 0, 0, 1, 0, 1, '', '', '', 0),
(7, 74, 6, 'Biển cả thumb', 'bien-ca-thumb-7', '', '', '2015-08-11 04:34:00', 0, 0, 0, 0, 1, 1, 0, 'bin_c_thumb_20150811_1999985099.jpg', 'bin_c_thumb_20150811_1999985099.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(8, 75, 7, 'Hoa thumb', 'hoa-thumb-8', '', '', '2015-08-11 04:34:31', 0, 0, 0, 0, 1, 1, 0, 'hoa_thumb_20150811_1471895289.jpg', 'hoa_thumb_20150811_1471895289.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(9, 76, 4, 'Hình 3', 'hinh-3-9', '', '', '2015-08-11 04:35:33', 2, 0, 0, 0, 1, 1, 0, 'hinh_3_1_20150811_1393625950.jpg', 'hinh_3_1_20150811_1393625950.jpg', 0, 469, 1, 1, 4, '', '', '', 1),
(10, 77, 5, 'Con người 1', 'con-nguoi-1-10', '', '', '2015-08-11 05:22:45', 2, 0, 0, 0, 1, 1, 0, 'con_ngi_1_20150811_1979671750.jpg', 'con_ngi_1_20150811_1979671750.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(11, 78, 5, 'Con người 2', 'con-nguoi-2-11', '', '', '2015-08-11 05:23:06', 1, 0, 0, 0, 1, 1, 0, 'con_ngi_2_20150811_1964833314.jpg', 'con_ngi_2_20150811_1964833314.jpg', 0, 469, 1, 1, 3, '', '', '', 1),
(12, 79, 7, 'Hoa 1', 'hoa-1-12', '', '', '2015-08-11 05:24:35', 1, 0, 0, 0, 1, 1, 0, 'hoa_1_20150811_1538952387.jpg', 'hoa_1_20150811_1538952387.jpg', 0, 469, 1, 1, 2, '', '', '', 1),
(13, 80, 7, 'Hoa 2', 'hoa-2-13', '', '', '2015-08-11 05:24:49', 1, 0, 0, 0, 1, 1, 0, 'hoa_2_20150811_1570577050.jpg', 'hoa_2_20150811_1570577050.jpg', 0, 469, 1, 1, 3, '', '', '', 1),
(14, 81, 7, 'Hoa 3', 'hoa-3-14', '', '', '2015-08-11 05:24:58', 2, 0, 0, 0, 1, 1, 0, 'hoa_3_20150811_1634342026.jpg', 'hoa_3_20150811_1634342026.jpg', 0, 469, 1, 1, 4, '', '', '', 1),
(15, 82, 6, 'Biển cả 1', 'bien-ca-1-15', '', '', '2015-08-11 05:26:50', 1, 0, 0, 0, 1, 1, 0, 'bin_c_1_20150811_1849123710.jpg', 'bin_c_1_20150811_1849123710.jpg', 0, 469, 1, 1, 2, '', '', '', 1),
(16, 83, 6, 'Biển cả 2', 'bien-ca-2-16', '', '', '2015-08-11 05:27:03', 1, 0, 0, 0, 1, 1, 0, 'bin_c_2_20150811_2065392986.jpg', 'bin_c_2_20150811_2065392986.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(17, 84, 6, 'Biển cả 3', 'bien-ca-3-17', '', '', '2015-08-11 05:27:16', 1, 0, 0, 0, 1, 1, 0, 'bin_c_3_20150811_1147612553.jpg', 'bin_c_3_20150811_1147612553.jpg', 0, 469, 1, 1, 4, '', '', '', 1),
(18, 89, 8, 'Tình yêu thumb', 'tinh-yeu-thumb-18', '', '', '2015-08-14 02:36:42', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_thumb_20150814_1700804955.jpg', 'tinh_yeu_thumb_20150814_1700804955.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(19, 91, 9, 'Đất nước đổi mới thumb', 'dat-nuoc-doi-moi-thumb-19', '', '', '2015-08-14 03:37:28', 0, 0, 0, 0, 1, 1, 0, 't_nc_i_mi_thumb_20150814_1496193896.jpg', 't_nc_i_mi_thumb_20150814_1496193896.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(20, 97, 10, 'Thể thao thumb', 'the-thao-thumb-20', '', '', '2015-08-14 03:39:38', 0, 0, 0, 0, 1, 1, 0, 'th_thao_thumb_20150814_2067578400.jpg', 'th_thao_thumb_20150814_2067578400.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(21, 98, 11, 'Ẩm thực thumb', 'am-thuc-thumb-21', '', '', '2015-08-14 03:39:55', 0, 0, 0, 0, 1, 1, 0, 'm_thc_thumb_20150814_2032601703.jpg', 'm_thc_thumb_20150814_2032601703.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(22, 99, 12, 'Sáng tạo nghệ thuật thumb', 'sang-tao-nghe-thuat-thumb-22', '', '', '2015-08-14 03:40:12', 0, 0, 0, 0, 1, 1, 0, 'sang_to_ngh_thut_thumb_20150814_1074847709.jpg', 'sang_to_ngh_thut_thumb_20150814_1074847709.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(23, 100, 13, 'Động vật thumb', 'dong-vat-thumb-23', '', '', '2015-08-14 03:40:24', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_thumb_20150814_1520485400.jpg', 'ng_vt_thumb_20150814_1520485400.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(24, 101, 14, 'Chủ đề khác thumb', 'chu-de-khac-thumb-24', '', '', '2015-08-14 03:40:42', 0, 0, 0, 0, 1, 1, 0, 'ch__khac_thumb_20150814_1637033220.jpg', 'ch__khac_thumb_20150814_1637033220.jpg', 0, 0, 1, 0, 1, '', '', '', 0),
(25, 102, 4, 'Thắng cảnh 4', 'thang-canh-4-25', '', '', '2015-08-14 03:56:44', 1, 0, 0, 0, 1, 1, 0, 'thng_cnh_4_20150814_1868169533.jpg', 'thng_cnh_4_20150814_1868169533.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(26, 103, 4, 'Thắng cảnh 5', 'thang-canh-5-26', '', '', '2015-08-14 03:57:00', 1, 0, 0, 0, 1, 1, 0, 'thng_cnh_5_20150814_1247864509.jpg', 'thng_cnh_5_20150814_1247864509.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(27, 104, 5, 'Con người 3', 'con-nguoi-3-27', '', '', '2015-08-14 04:03:05', 1, 0, 0, 0, 1, 1, 0, 'con_ngi_3_20150814_1787708454.jpg', 'con_ngi_3_20150814_1787708454.jpg', 0, 469, 1, 1, 4, '', '', '', 1),
(28, 105, 5, 'Con người 4', 'con-nguoi-4-28', '', '', '2015-08-14 04:03:22', 1, 0, 0, 0, 1, 1, 0, 'con_ngi_4_20150814_1389065543.jpg', 'con_ngi_4_20150814_1389065543.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(29, 106, 5, 'Con người 5', 'con-nguoi-5-29', '', '', '2015-08-14 04:03:35', 2, 0, 0, 0, 1, 1, 0, 'con_ngi_5_20150814_1398362120.jpg', 'con_ngi_5_20150814_1398362120.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(30, 107, 6, 'Núi rừng 1', 'nui-rung-1-30', '', '', '2015-08-14 04:06:50', 0, 0, 0, 0, 1, 1, 0, 'nui_rng_1_20150814_1428522192.jpg', 'nui_rng_1_20150814_1428522192.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(31, 108, 6, 'Núi rừng 2', 'nui-rung-2-31', '', '', '2015-08-14 04:07:06', 0, 0, 0, 0, 1, 1, 0, 'nui_rng_2_20150814_1814653648.jpg', 'nui_rng_2_20150814_1814653648.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(32, 109, 7, 'Hoa 4', 'hoa-4-32', '', '', '2015-08-14 04:16:26', 0, 0, 0, 0, 1, 1, 0, 'hoa_4_20150814_1570788549.jpg', 'hoa_4_20150814_1570788549.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(33, 110, 7, 'Hoa 5', 'hoa-5-33', '', '', '2015-08-14 04:16:49', 0, 0, 0, 0, 1, 1, 0, 'hoa_5_20150814_1917197385.jpg', 'hoa_5_20150814_1917197385.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(34, 111, 8, 'Tình yêu 1', 'tinh-yeu-1-34', '', '', '2015-08-14 04:19:24', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_1_20150814_1584961406.jpg', 'tinh_yeu_1_20150814_1584961406.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(35, 112, 8, 'Tình yêu 2', 'tinh-yeu-2-35', '', '', '2015-08-14 04:19:49', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_2_20150814_2058423327.jpg', 'tinh_yeu_2_20150814_2058423327.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(36, 113, 8, 'Tình yêu 3', 'tinh-yeu-3-36', '', '', '2015-08-14 04:20:03', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_3_20150814_1388408735.jpg', 'tinh_yeu_3_20150814_1388408735.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(37, 114, 8, 'Tình yêu 4', 'tinh-yeu-4-37', '', '', '2015-08-14 04:20:16', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_4_20150814_1360109794.jpg', 'tinh_yeu_4_20150814_1360109794.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(38, 115, 8, 'Tình yêu 5', 'tinh-yeu-5-38', '', '', '2015-08-14 04:20:28', 0, 0, 0, 0, 1, 1, 0, 'tinh_yeu_5_20150814_1155524372.jpg', 'tinh_yeu_5_20150814_1155524372.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(39, 116, 9, 'Đất nước 1', 'dat-nuoc-1-39', '', '', '2015-08-14 04:29:44', 0, 0, 0, 0, 1, 1, 0, 't_nc_1_20150814_1913160741.jpg', 't_nc_1_20150814_1913160741.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(40, 117, 9, 'Đất nước 2', 'dat-nuoc-2-40', '', '', '2015-08-14 04:30:01', 0, 0, 0, 0, 1, 1, 0, 't_nc_2_20150814_2011745165.jpg', 't_nc_2_20150814_2011745165.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(41, 118, 9, 'Đất nước 3', 'dat-nuoc-3-41', '', '', '2015-08-14 04:30:25', 0, 0, 0, 0, 1, 1, 0, 't_nc_3_20150814_1445362112.jpg', 't_nc_3_20150814_1445362112.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(42, 119, 9, 'Đất nước 4', 'dat-nuoc-4-42', '', '', '2015-08-14 04:30:45', 0, 0, 0, 0, 1, 1, 0, 't_nc_4_20150814_1988987360.jpg', 't_nc_4_20150814_1988987360.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(43, 120, 9, 'Đất nước 5', 'dat-nuoc-5-43', '', '', '2015-08-14 04:31:08', 0, 0, 0, 0, 1, 1, 0, 't_nc_5_20150814_1791835575.jpg', 't_nc_5_20150814_1791835575.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(44, 121, 10, 'Thể thao 1', 'the-thao-1-44', '', '', '2015-08-14 04:49:44', 0, 0, 0, 0, 1, 1, 0, 'th_thao_1_20150814_1134393820.jpg', 'th_thao_1_20150814_1134393820.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(45, 122, 10, 'Thể thao 2', 'the-thao-2-45', '', '', '2015-08-14 04:49:56', 0, 0, 0, 0, 1, 1, 0, 'th_thao_2_20150814_1077889776.jpg', 'th_thao_2_20150814_1077889776.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(46, 123, 10, 'Thể thao 3', 'the-thao-3-46', '', '', '2015-08-14 04:50:10', 0, 0, 0, 0, 1, 1, 0, 'th_thao_3_20150814_1718306823.jpg', 'th_thao_3_20150814_1718306823.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(47, 124, 10, 'Thể thao 4', 'the-thao-4-47', '', '', '2015-08-14 04:50:26', 0, 0, 0, 0, 1, 1, 0, 'th_thao_4_20150814_2066765985.jpg', 'th_thao_4_20150814_2066765985.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(48, 125, 10, 'Thể thao 5', 'the-thao-5-48', '', '', '2015-08-14 04:50:39', 0, 0, 0, 0, 1, 1, 0, 'th_thao_5_20150814_1214190209.jpg', 'th_thao_5_20150814_1214190209.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(49, 126, 11, 'Ẩm thực 1', 'am-thuc-1-49', '', '', '2015-08-14 04:55:16', 0, 0, 0, 0, 1, 1, 0, 'm_thc_1_20150814_1604015970.jpg', 'm_thc_1_20150814_1604015970.jpg', 0, 469, 1, 1, 2, '', '', '', 1),
(50, 127, 11, 'Ẩm thực 2', 'am-thuc-2-50', '', '', '2015-08-14 04:55:36', 0, 0, 0, 0, 1, 1, 0, 'm_thc_2_20150814_1519020250.jpg', 'm_thc_2_20150814_1519020250.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(51, 128, 11, 'Ẩm thực 3', 'am-thuc-3-51', '', '', '2015-08-14 04:55:50', 0, 0, 0, 0, 1, 1, 0, 'm_thc_3_20150814_1114939278.jpg', 'm_thc_3_20150814_1114939278.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(52, 129, 11, 'Ẩm thực 4', 'am-thuc-4-52', '', '', '2015-08-14 04:56:05', 0, 0, 0, 0, 1, 1, 0, 'm_thc_4_20150814_1336136056.jpg', 'm_thc_4_20150814_1336136056.jpg', 0, 469, 1, 1, 5, '', '', '', 1),
(53, 130, 11, 'Ẩm thực 5', 'am-thuc-5-53', '', '', '2015-08-14 04:56:17', 0, 0, 0, 0, 1, 1, 0, 'm_thc_5_20150814_1013732675.jpg', 'm_thc_5_20150814_1013732675.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(54, 131, 12, 'Sáng tạo 1', 'sang-tao-1-54', '', '', '2015-08-14 06:37:24', 0, 0, 0, 0, 1, 1, 0, 'sang_to_1_20150814_1353685450.jpg', 'sang_to_1_20150814_1353685450.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(55, 132, 12, 'Sáng tạo 2', 'sang-tao-2-55', '', '', '2015-08-14 06:37:57', 0, 0, 0, 0, 1, 1, 0, 'sang_to_2_20150814_1227393594.jpg', 'sang_to_2_20150814_1227393594.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(56, 133, 12, 'Sáng tạo 3', 'sang-tao-3-56', '', '', '2015-08-14 06:38:20', 0, 0, 0, 0, 1, 1, 0, 'sang_to_3_20150814_1840605619.jpg', 'sang_to_3_20150814_1840605619.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(57, 134, 12, 'Sáng tạo 4', 'sang-tao-4-57', '', '', '2015-08-14 06:38:47', 0, 0, 0, 0, 1, 1, 0, 'sang_to_4_20150814_1775241530.jpg', 'sang_to_4_20150814_1775241530.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(58, 135, 12, 'Sáng tạo 5', 'sang-tao-5-58', '', '', '2015-08-14 06:39:07', 0, 0, 0, 0, 1, 1, 0, 'sang_to_5_20150814_1793989793.jpg', 'sang_to_5_20150814_1793989793.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(59, 136, 13, 'Động vật 1', 'dong-vat-1-59', '', '', '2015-08-14 06:55:05', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_1_20150814_1061995731.jpg', 'ng_vt_1_20150814_1061995731.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(60, 137, 13, 'Động vật 2', 'dong-vat-2-60', '', '', '2015-08-14 06:55:37', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_2_20150814_1293901851.jpg', 'ng_vt_2_20150814_1293901851.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(61, 138, 13, 'Động vật 3', 'dong-vat-3-61', '', '', '2015-08-14 06:55:54', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_3_20150814_1051397564.jpg', 'ng_vt_3_20150814_1051397564.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(62, 139, 13, 'Động vật 4', 'dong-vat-4-62', '', '', '2015-08-14 06:56:25', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_4_20150814_1951633112.jpg', 'ng_vt_4_20150814_1951633112.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(63, 140, 13, 'Động vật 5', 'dong-vat-5-63', '', '', '2015-08-14 06:56:39', 0, 0, 0, 0, 1, 1, 0, 'ng_vt_5_20150814_1028588783.jpg', 'ng_vt_5_20150814_1028588783.jpg', 0, 469, 1, 1, 6, '', '', '', 1),
(64, 141, 14, 'Khác 1', 'khac-1-64', '', '', '2015-08-14 07:01:20', 0, 0, 0, 0, 1, 1, 0, 'khac_1_20150814_1554187545.jpg', 'khac_1_20150814_1554187545.jpg', 0, 469, 1, 1, 2, '', '', '', 0),
(65, 142, 14, 'Khác 2', 'khac-2-65', '', '', '2015-08-14 07:01:34', 0, 0, 0, 0, 1, 1, 0, 'khac_2_20150814_1517251209.jpg', 'khac_2_20150814_1517251209.jpg', 0, 469, 1, 1, 3, '', '', '', 0),
(66, 143, 14, 'Khác 3', 'khac-3-66', '', '', '2015-08-14 07:01:45', 0, 0, 0, 0, 1, 1, 0, 'khac_3_20150814_1877275431.jpg', 'khac_3_20150814_1877275431.jpg', 0, 469, 1, 1, 4, '', '', '', 0),
(67, 144, 14, 'Khác 4', 'khac-4-67', '', '', '2015-08-14 07:02:05', 1, 0, 0, 0, 1, 1, 0, 'khac_4_20150814_1298384655.jpg', 'khac_4_20150814_1298384655.jpg', 0, 469, 1, 1, 5, '', '', '', 0),
(68, 145, 14, 'Khác 5', 'khac-5-68', '', '', '2015-08-14 07:02:17', 1, 0, 0, 0, 1, 1, 0, 'khac_5_20150814_1477788088.jpg', 'khac_5_20150814_1477788088.jpg', 0, 469, 1, 1, 6, '', '', '', 0),
(70, 164, 4, 'Thắng cảnh 6', 'thang-canh-6-70', '', '', '2015-08-31 07:09:30', 6, 0, 0, 0, 1, 1, 0, 'thng_cnh_6_20150831_1941343509.jpg', 'thng_cnh_6_20150831_1941343509.jpg', 0, 469, 1, 1, 7, '', '', '', 0),
(71, 166, 7, 'Hoa nghệ thuật', 'hoa-nghe-thuat-71', NULL, '', '2015-09-09 03:57:50', 1, 0, 0, 0, 1, 1, 0, 'hoa_ngh_thut_20150909_1230044140.jpg', 'hoa_ngh_thut_20150909_1230044140.jpg', 0, 470, 1, 1, 7, '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_category_details`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_category_details` (
  `id` int(11) NOT NULL,
  `details_key` varchar(255) NOT NULL,
  `details_value` text NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`,`details_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_catg`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_catg` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(2048) NOT NULL DEFAULT '',
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(1) unsigned NOT NULL DEFAULT '0',
  `description` text,
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `hidden` tinyint(1) NOT NULL DEFAULT '0',
  `in_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(100) NOT NULL DEFAULT '',
  `owner` int(11) DEFAULT '0',
  `thumbnail` int(11) DEFAULT NULL,
  `img_position` int(10) DEFAULT '0',
  `catpath` varchar(2048) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `exclude_toplists` int(1) NOT NULL,
  `exclude_search` int(1) NOT NULL,
  PRIMARY KEY (`cid`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `analk_joomgallery_catg`
--

INSERT INTO `analk_joomgallery_catg` (`cid`, `asset_id`, `name`, `alias`, `parent_id`, `lft`, `rgt`, `level`, `description`, `access`, `published`, `hidden`, `in_hidden`, `password`, `owner`, `thumbnail`, `img_position`, `catpath`, `params`, `metakey`, `metadesc`, `exclude_toplists`, `exclude_search`) VALUES
(1, 0, 'ROOT', 'root', 0, 0, 24, 0, NULL, 1, 1, 0, 0, '', 0, NULL, 0, '', '', '', '', 0, 0),
(4, 60, 'Thắng cảnh', 'thang-canh', 1, 21, 22, 1, '', 1, 1, 0, 0, '', 0, 3, -1, 'thng_cnh_4', '', '', '', 0, 0),
(5, 70, 'Con người', 'con-nguoi', 1, 19, 20, 1, '', 1, 1, 0, 0, '', 0, 6, -1, 'con_ngi_5', '', '', '', 0, 0),
(6, 72, 'Biển cả - Núi rừng', 'bien-ca-nui-rung', 1, 17, 18, 1, '', 1, 1, 0, 0, '', 0, 7, -1, 'bin_c_-_nui_rng_6', '', '', '', 0, 0),
(7, 73, 'Hoa', 'hoa', 1, 15, 16, 1, '', 1, 1, 0, 0, '', 0, 8, -1, 'hoa_7', '', '', '', 0, 0),
(8, 88, 'Tình yêu', 'tinh-yeu', 1, 13, 14, 1, '', 1, 1, 0, 0, '', 0, 18, -1, 'tinh_yeu_8', '', '', '', 0, 0),
(9, 90, 'Đất nước đổi mới', 'dat-nuoc-doi-moi', 1, 11, 12, 1, '', 1, 1, 0, 0, '', 0, 19, -1, 't_nc_i_mi_9', '', '', '', 0, 0),
(10, 92, 'Thể thao', 'the-thao', 1, 9, 10, 1, '', 1, 1, 0, 0, '', 0, 20, -1, 'th_thao_10', '', '', '', 0, 0),
(11, 93, 'Ẩm thực', 'am-thuc', 1, 7, 8, 1, '', 1, 1, 0, 0, '', 0, 21, -1, 'm_thc_11', '', '', '', 0, 0),
(12, 94, 'Sáng tạo - nghệ thuật', 'sang-tao-nghe-thuat', 1, 5, 6, 1, '', 1, 1, 0, 0, '', 0, 22, -1, 'sang_to_-_ngh_thut_12', '', '', '', 0, 0),
(13, 95, 'Động vật', 'dong-vat', 1, 3, 4, 1, '', 1, 1, 0, 0, '', 0, 23, -1, 'ng_vt_13', '', '', '', 0, 0),
(14, 96, 'Chủ đề khác', 'chu-de-khac', 1, 1, 2, 1, '', 1, 1, 0, 0, '', 0, 24, -1, 'ch__khac_14', '', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_comments`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_comments` (
  `cmtid` int(11) NOT NULL AUTO_INCREMENT,
  `cmtpic` int(11) NOT NULL DEFAULT '0',
  `cmtip` varchar(15) NOT NULL DEFAULT '',
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `cmtname` varchar(50) NOT NULL DEFAULT '',
  `cmttext` text NOT NULL,
  `cmtdate` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cmtid`),
  KEY `idx_cmtpic` (`cmtpic`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_config`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_config` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `jg_pathimages` varchar(100) NOT NULL,
  `jg_pathoriginalimages` varchar(100) NOT NULL,
  `jg_paththumbs` varchar(100) NOT NULL,
  `jg_pathftpupload` varchar(100) NOT NULL,
  `jg_pathtemp` varchar(100) NOT NULL,
  `jg_wmpath` varchar(100) NOT NULL,
  `jg_wmfile` varchar(50) NOT NULL,
  `jg_use_real_paths` int(1) NOT NULL,
  `jg_checkupdate` int(1) NOT NULL,
  `jg_filenamewithjs` int(1) NOT NULL,
  `jg_filenamereplace` text NOT NULL,
  `jg_thumbcreation` varchar(5) NOT NULL,
  `jg_fastgd2thumbcreation` int(1) NOT NULL,
  `jg_impath` varchar(50) NOT NULL,
  `jg_resizetomaxwidth` int(1) NOT NULL,
  `jg_maxwidth` int(5) NOT NULL,
  `jg_picturequality` int(3) NOT NULL,
  `jg_useforresizedirection` int(1) NOT NULL,
  `jg_cropposition` int(1) NOT NULL,
  `jg_thumbwidth` int(5) NOT NULL,
  `jg_thumbheight` int(5) NOT NULL,
  `jg_thumbquality` int(3) NOT NULL,
  `jg_uploadorder` int(1) NOT NULL,
  `jg_useorigfilename` int(1) NOT NULL,
  `jg_filenamenumber` int(1) NOT NULL,
  `jg_delete_original` int(1) NOT NULL,
  `jg_msg_upload_type` int(1) NOT NULL,
  `jg_msg_upload_recipients` text NOT NULL,
  `jg_msg_download_type` int(1) NOT NULL,
  `jg_msg_download_recipients` text NOT NULL,
  `jg_msg_zipdownload` int(1) NOT NULL,
  `jg_msg_comment_type` int(1) NOT NULL,
  `jg_msg_comment_recipients` text NOT NULL,
  `jg_msg_comment_toowner` int(1) NOT NULL,
  `jg_msg_nametag_type` int(1) NOT NULL,
  `jg_msg_nametag_recipients` text NOT NULL,
  `jg_msg_nametag_totaggeduser` int(1) NOT NULL,
  `jg_msg_nametag_toowner` int(1) NOT NULL,
  `jg_msg_report_type` int(1) NOT NULL,
  `jg_msg_report_recipients` text NOT NULL,
  `jg_msg_report_toowner` int(1) NOT NULL,
  `jg_msg_rejectimg_type` int(1) NOT NULL,
  `jg_msg_global_from` int(1) NOT NULL,
  `jg_realname` int(1) NOT NULL,
  `jg_cooliris` int(1) NOT NULL,
  `jg_coolirislink` int(1) NOT NULL,
  `jg_contentpluginsenabled` int(1) NOT NULL,
  `jg_itemid` varchar(10) NOT NULL,
  `jg_ajaxcategoryselection` int(1) NOT NULL,
  `jg_disableunrequiredchecks` int(1) NOT NULL,
  `jg_userspace` int(1) NOT NULL,
  `jg_useruploaddefaultcat` int(1) NOT NULL,
  `jg_approve` int(1) NOT NULL,
  `jg_unregistered_permissions` int(1) NOT NULL,
  `jg_maxusercat` int(5) NOT NULL,
  `jg_maxuserimage` int(9) NOT NULL,
  `jg_maxuserimage_timespan` int(9) NOT NULL,
  `jg_maxfilesize` int(9) NOT NULL,
  `jg_usercatacc` int(1) NOT NULL,
  `jg_usercatthumbalign` int(1) NOT NULL,
  `jg_useruploadsingle` int(1) NOT NULL,
  `jg_maxuploadfields` int(3) NOT NULL,
  `jg_useruploadajax` int(1) NOT NULL,
  `jg_useruploadbatch` int(1) NOT NULL,
  `jg_useruploadjava` int(1) NOT NULL,
  `jg_useruseorigfilename` int(1) NOT NULL,
  `jg_useruploadnumber` int(1) NOT NULL,
  `jg_special_gif_upload` int(1) NOT NULL,
  `jg_delete_original_user` int(1) NOT NULL,
  `jg_newpiccopyright` int(1) NOT NULL,
  `jg_newpicnote` int(1) NOT NULL,
  `jg_redirect_after_upload` int(1) NOT NULL,
  `jg_download` int(1) NOT NULL,
  `jg_download_unreg` int(1) NOT NULL,
  `jg_download_hint` int(1) NOT NULL,
  `jg_downloadfile` int(1) NOT NULL,
  `jg_downloadwithwatermark` int(1) NOT NULL,
  `jg_showrating` int(1) NOT NULL,
  `jg_maxvoting` int(1) NOT NULL,
  `jg_ratingcalctype` int(1) NOT NULL,
  `jg_ratingdisplaytype` int(1) NOT NULL,
  `jg_ajaxrating` int(1) NOT NULL,
  `jg_votingonlyonce` int(1) NOT NULL,
  `jg_votingonlyreg` int(1) NOT NULL,
  `jg_showcomment` int(1) NOT NULL,
  `jg_anoncomment` int(1) NOT NULL,
  `jg_namedanoncomment` int(1) NOT NULL,
  `jg_anonapprovecom` int(1) NOT NULL,
  `jg_approvecom` int(1) NOT NULL,
  `jg_bbcodesupport` int(1) NOT NULL,
  `jg_smiliesupport` int(1) NOT NULL,
  `jg_anismilie` int(1) NOT NULL,
  `jg_smiliescolor` varchar(10) NOT NULL,
  `jg_report_images` int(1) NOT NULL,
  `jg_report_unreg` int(1) NOT NULL,
  `jg_report_hint` int(1) NOT NULL,
  `jg_alternative_layout` varchar(255) NOT NULL,
  `jg_anchors` int(1) NOT NULL,
  `jg_tooltips` int(1) NOT NULL,
  `jg_dyncrop` int(1) NOT NULL,
  `jg_dyncropposition` int(1) NOT NULL,
  `jg_dyncropwidth` int(5) NOT NULL,
  `jg_dyncropheight` int(5) NOT NULL,
  `jg_dyncropbgcol` varchar(12) NOT NULL,
  `jg_hideemptycats` int(1) NOT NULL,
  `jg_skipcatview` int(1) NOT NULL,
  `jg_imgalign` int(3) NOT NULL,
  `jg_showrestrictedcats` int(1) NOT NULL,
  `jg_showrestrictedhint` int(1) NOT NULL,
  `jg_firstorder` varchar(20) NOT NULL,
  `jg_secondorder` varchar(20) NOT NULL,
  `jg_thirdorder` varchar(20) NOT NULL,
  `jg_pagetitle_cat` text NOT NULL,
  `jg_pagetitle_detail` text NOT NULL,
  `jg_showgalleryhead` int(1) NOT NULL,
  `jg_showpathway` int(1) NOT NULL,
  `jg_completebreadcrumbs` int(1) NOT NULL,
  `jg_search` int(1) NOT NULL,
  `jg_searchcols` int(1) NOT NULL,
  `jg_searchthumbalign` int(1) NOT NULL,
  `jg_searchtextalign` int(1) NOT NULL,
  `jg_showsearchdownload` int(1) NOT NULL,
  `jg_showsearchfavourite` int(1) NOT NULL,
  `jg_search_report_images` int(1) NOT NULL,
  `jg_showsearcheditorlinks` int(1) NOT NULL,
  `jg_showallpics` int(1) NOT NULL,
  `jg_showallhits` int(1) NOT NULL,
  `jg_showbacklink` int(1) NOT NULL,
  `jg_suppresscredits` int(1) NOT NULL,
  `jg_showuserpanel` int(1) NOT NULL,
  `jg_showuserpanel_hint` int(1) NOT NULL,
  `jg_showuserpanel_unreg` int(1) NOT NULL,
  `jg_showallpicstoadmin` int(1) NOT NULL,
  `jg_showminithumbs` int(1) NOT NULL,
  `jg_openjs_padding` int(3) NOT NULL,
  `jg_openjs_background` varchar(12) NOT NULL,
  `jg_dhtml_border` varchar(12) NOT NULL,
  `jg_show_title_in_popup` int(1) NOT NULL,
  `jg_show_description_in_popup` int(1) NOT NULL,
  `jg_lightbox_speed` int(3) NOT NULL,
  `jg_lightbox_slide_all` int(1) NOT NULL,
  `jg_resize_js_image` int(1) NOT NULL,
  `jg_disable_rightclick_original` int(1) NOT NULL,
  `jg_showgallerysubhead` int(1) NOT NULL,
  `jg_showallcathead` int(1) NOT NULL,
  `jg_colcat` int(1) NOT NULL,
  `jg_catperpage` int(1) NOT NULL,
  `jg_ordercatbyalpha` int(1) NOT NULL,
  `jg_showgallerypagenav` int(1) NOT NULL,
  `jg_showcatcount` int(1) NOT NULL,
  `jg_showcatthumb` int(1) NOT NULL,
  `jg_showrandomcatthumb` int(1) NOT NULL,
  `jg_ctalign` int(1) NOT NULL,
  `jg_showtotalcatimages` int(1) NOT NULL,
  `jg_showtotalcathits` int(1) NOT NULL,
  `jg_showcatasnew` int(1) NOT NULL,
  `jg_catdaysnew` int(3) NOT NULL,
  `jg_showdescriptioningalleryview` int(1) NOT NULL,
  `jg_uploadicongallery` int(1) NOT NULL,
  `jg_showsubsingalleryview` int(1) NOT NULL,
  `jg_category_rss` int(9) NOT NULL,
  `jg_category_rss_icon` varchar(10) NOT NULL,
  `jg_uploadiconcategory` int(1) NOT NULL,
  `jg_showcathead` int(1) NOT NULL,
  `jg_usercatorder` int(1) NOT NULL,
  `jg_usercatorderlist` varchar(50) NOT NULL,
  `jg_showcatdescriptionincat` int(1) NOT NULL,
  `jg_showpagenav` int(1) NOT NULL,
  `jg_showpiccount` int(1) NOT NULL,
  `jg_perpage` int(3) NOT NULL,
  `jg_catthumbalign` int(1) NOT NULL,
  `jg_colnumb` int(3) NOT NULL,
  `jg_detailpic_open` varchar(50) NOT NULL,
  `jg_lightboxbigpic` int(1) NOT NULL,
  `jg_showtitle` int(1) NOT NULL,
  `jg_showpicasnew` int(1) NOT NULL,
  `jg_daysnew` int(3) NOT NULL,
  `jg_showhits` int(1) NOT NULL,
  `jg_showdownloads` int(1) NOT NULL,
  `jg_showauthor` int(1) NOT NULL,
  `jg_showowner` int(1) NOT NULL,
  `jg_showcatcom` int(1) NOT NULL,
  `jg_showcatrate` int(1) NOT NULL,
  `jg_showcatdescription` int(1) NOT NULL,
  `jg_showcategorydownload` int(1) NOT NULL,
  `jg_showcategoryfavourite` int(1) NOT NULL,
  `jg_category_report_images` int(1) NOT NULL,
  `jg_showcategoryeditorlinks` int(1) NOT NULL,
  `jg_showsubcathead` int(1) NOT NULL,
  `jg_showsubcatcount` int(1) NOT NULL,
  `jg_colsubcat` int(3) NOT NULL,
  `jg_subperpage` int(3) NOT NULL,
  `jg_showpagenavsubs` int(1) NOT NULL,
  `jg_subcatthumbalign` int(1) NOT NULL,
  `jg_showsubthumbs` int(1) NOT NULL,
  `jg_showrandomsubthumb` int(1) NOT NULL,
  `jg_showdescriptionincategoryview` int(1) NOT NULL,
  `jg_ordersubcatbyalpha` int(1) NOT NULL,
  `jg_showtotalsubcatimages` int(1) NOT NULL,
  `jg_showtotalsubcathits` int(1) NOT NULL,
  `jg_uploadiconsubcat` int(1) NOT NULL,
  `jg_showdetailpage` int(1) NOT NULL,
  `jg_disabledetailpage` int(1) NOT NULL,
  `jg_showdetailnumberofpics` int(1) NOT NULL,
  `jg_cursor_navigation` int(1) NOT NULL,
  `jg_disable_rightclick_detail` int(1) NOT NULL,
  `jg_detail_report_images` int(1) NOT NULL,
  `jg_showdetaileditorlinks` int(1) NOT NULL,
  `jg_showdetailtitle` int(1) NOT NULL,
  `jg_showdetail` int(1) NOT NULL,
  `jg_showdetailaccordion` int(1) NOT NULL,
  `jg_accordionduration` int(3) NOT NULL,
  `jg_accordiondisplay` int(3) NOT NULL,
  `jg_accordionopacity` int(1) NOT NULL,
  `jg_accordionalwayshide` int(1) NOT NULL,
  `jg_accordioninitialeffect` int(1) NOT NULL,
  `jg_showdetaildescription` int(1) NOT NULL,
  `jg_showdetaildatum` int(1) NOT NULL,
  `jg_showdetailhits` int(1) NOT NULL,
  `jg_showdetaildownloads` int(1) NOT NULL,
  `jg_showdetailrating` int(1) NOT NULL,
  `jg_showdetailfilesize` int(1) NOT NULL,
  `jg_showdetailauthor` int(1) NOT NULL,
  `jg_showoriginalfilesize` int(1) NOT NULL,
  `jg_showdetaildownload` int(1) NOT NULL,
  `jg_watermark` int(1) NOT NULL,
  `jg_watermarkpos` int(1) NOT NULL,
  `jg_bigpic` int(1) NOT NULL,
  `jg_bigpic_unreg` int(1) NOT NULL,
  `jg_bigpic_open` varchar(50) NOT NULL,
  `jg_bbcodelink` int(1) NOT NULL,
  `jg_showcommentsunreg` int(1) NOT NULL,
  `jg_showcommentsarea` int(1) NOT NULL,
  `jg_send2friend` int(1) NOT NULL,
  `jg_minis` int(1) NOT NULL,
  `jg_motionminis` int(1) NOT NULL,
  `jg_motionminiWidth` int(3) NOT NULL,
  `jg_motionminiHeight` int(3) NOT NULL,
  `jg_miniWidth` int(3) NOT NULL,
  `jg_miniHeight` int(3) NOT NULL,
  `jg_minisprop` int(1) NOT NULL,
  `jg_nameshields` int(1) NOT NULL,
  `jg_nameshields_others` int(1) NOT NULL,
  `jg_nameshields_unreg` int(1) NOT NULL,
  `jg_show_nameshields_unreg` int(1) NOT NULL,
  `jg_nameshields_height` int(3) NOT NULL,
  `jg_nameshields_width` int(3) NOT NULL,
  `jg_slideshow` int(1) NOT NULL,
  `jg_slideshow_timer` int(3) NOT NULL,
  `jg_slideshow_transition` int(1) NOT NULL,
  `jg_slideshow_transtime` int(3) NOT NULL,
  `jg_slideshow_maxdimauto` int(1) NOT NULL,
  `jg_slideshow_width` int(3) NOT NULL,
  `jg_slideshow_heigth` int(3) NOT NULL,
  `jg_slideshow_infopane` int(1) NOT NULL,
  `jg_slideshow_carousel` int(1) NOT NULL,
  `jg_slideshow_arrows` int(1) NOT NULL,
  `jg_slideshow_repeat` int(1) NOT NULL,
  `jg_showexifdata` int(1) NOT NULL,
  `jg_showgeotagging` int(1) NOT NULL,
  `jg_geotaggingkey` text NOT NULL,
  `jg_subifdtags` text NOT NULL,
  `jg_ifdotags` text NOT NULL,
  `jg_gpstags` text NOT NULL,
  `jg_showiptcdata` int(1) NOT NULL,
  `jg_iptctags` text NOT NULL,
  `jg_showtoplist` int(1) NOT NULL,
  `jg_toplist` int(3) NOT NULL,
  `jg_topthumbalign` int(1) NOT NULL,
  `jg_toptextalign` int(1) NOT NULL,
  `jg_toplistcols` int(3) NOT NULL,
  `jg_whereshowtoplist` int(1) NOT NULL,
  `jg_showrate` int(1) NOT NULL,
  `jg_showlatest` int(1) NOT NULL,
  `jg_showcom` int(1) NOT NULL,
  `jg_showthiscomment` int(1) NOT NULL,
  `jg_showmostviewed` int(1) NOT NULL,
  `jg_showtoplistdownload` int(1) NOT NULL,
  `jg_showtoplistfavourite` int(1) NOT NULL,
  `jg_toplist_report_images` int(1) NOT NULL,
  `jg_showtoplisteditorlinks` int(1) NOT NULL,
  `jg_favourites` int(1) NOT NULL,
  `jg_showdetailfavourite` int(1) NOT NULL,
  `jg_favouritesshownotauth` int(1) NOT NULL,
  `jg_maxfavourites` int(5) NOT NULL,
  `jg_zipdownload` int(1) NOT NULL,
  `jg_usefavouritesforpubliczip` int(1) NOT NULL,
  `jg_usefavouritesforzip` int(1) NOT NULL,
  `jg_allimagesofcategory` int(1) NOT NULL,
  `jg_showfavouritesdownload` int(1) NOT NULL,
  `jg_showfavouriteseditorlinks` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `analk_joomgallery_config`
--

INSERT INTO `analk_joomgallery_config` (`id`, `group_id`, `ordering`, `jg_pathimages`, `jg_pathoriginalimages`, `jg_paththumbs`, `jg_pathftpupload`, `jg_pathtemp`, `jg_wmpath`, `jg_wmfile`, `jg_use_real_paths`, `jg_checkupdate`, `jg_filenamewithjs`, `jg_filenamereplace`, `jg_thumbcreation`, `jg_fastgd2thumbcreation`, `jg_impath`, `jg_resizetomaxwidth`, `jg_maxwidth`, `jg_picturequality`, `jg_useforresizedirection`, `jg_cropposition`, `jg_thumbwidth`, `jg_thumbheight`, `jg_thumbquality`, `jg_uploadorder`, `jg_useorigfilename`, `jg_filenamenumber`, `jg_delete_original`, `jg_msg_upload_type`, `jg_msg_upload_recipients`, `jg_msg_download_type`, `jg_msg_download_recipients`, `jg_msg_zipdownload`, `jg_msg_comment_type`, `jg_msg_comment_recipients`, `jg_msg_comment_toowner`, `jg_msg_nametag_type`, `jg_msg_nametag_recipients`, `jg_msg_nametag_totaggeduser`, `jg_msg_nametag_toowner`, `jg_msg_report_type`, `jg_msg_report_recipients`, `jg_msg_report_toowner`, `jg_msg_rejectimg_type`, `jg_msg_global_from`, `jg_realname`, `jg_cooliris`, `jg_coolirislink`, `jg_contentpluginsenabled`, `jg_itemid`, `jg_ajaxcategoryselection`, `jg_disableunrequiredchecks`, `jg_userspace`, `jg_useruploaddefaultcat`, `jg_approve`, `jg_unregistered_permissions`, `jg_maxusercat`, `jg_maxuserimage`, `jg_maxuserimage_timespan`, `jg_maxfilesize`, `jg_usercatacc`, `jg_usercatthumbalign`, `jg_useruploadsingle`, `jg_maxuploadfields`, `jg_useruploadajax`, `jg_useruploadbatch`, `jg_useruploadjava`, `jg_useruseorigfilename`, `jg_useruploadnumber`, `jg_special_gif_upload`, `jg_delete_original_user`, `jg_newpiccopyright`, `jg_newpicnote`, `jg_redirect_after_upload`, `jg_download`, `jg_download_unreg`, `jg_download_hint`, `jg_downloadfile`, `jg_downloadwithwatermark`, `jg_showrating`, `jg_maxvoting`, `jg_ratingcalctype`, `jg_ratingdisplaytype`, `jg_ajaxrating`, `jg_votingonlyonce`, `jg_votingonlyreg`, `jg_showcomment`, `jg_anoncomment`, `jg_namedanoncomment`, `jg_anonapprovecom`, `jg_approvecom`, `jg_bbcodesupport`, `jg_smiliesupport`, `jg_anismilie`, `jg_smiliescolor`, `jg_report_images`, `jg_report_unreg`, `jg_report_hint`, `jg_alternative_layout`, `jg_anchors`, `jg_tooltips`, `jg_dyncrop`, `jg_dyncropposition`, `jg_dyncropwidth`, `jg_dyncropheight`, `jg_dyncropbgcol`, `jg_hideemptycats`, `jg_skipcatview`, `jg_imgalign`, `jg_showrestrictedcats`, `jg_showrestrictedhint`, `jg_firstorder`, `jg_secondorder`, `jg_thirdorder`, `jg_pagetitle_cat`, `jg_pagetitle_detail`, `jg_showgalleryhead`, `jg_showpathway`, `jg_completebreadcrumbs`, `jg_search`, `jg_searchcols`, `jg_searchthumbalign`, `jg_searchtextalign`, `jg_showsearchdownload`, `jg_showsearchfavourite`, `jg_search_report_images`, `jg_showsearcheditorlinks`, `jg_showallpics`, `jg_showallhits`, `jg_showbacklink`, `jg_suppresscredits`, `jg_showuserpanel`, `jg_showuserpanel_hint`, `jg_showuserpanel_unreg`, `jg_showallpicstoadmin`, `jg_showminithumbs`, `jg_openjs_padding`, `jg_openjs_background`, `jg_dhtml_border`, `jg_show_title_in_popup`, `jg_show_description_in_popup`, `jg_lightbox_speed`, `jg_lightbox_slide_all`, `jg_resize_js_image`, `jg_disable_rightclick_original`, `jg_showgallerysubhead`, `jg_showallcathead`, `jg_colcat`, `jg_catperpage`, `jg_ordercatbyalpha`, `jg_showgallerypagenav`, `jg_showcatcount`, `jg_showcatthumb`, `jg_showrandomcatthumb`, `jg_ctalign`, `jg_showtotalcatimages`, `jg_showtotalcathits`, `jg_showcatasnew`, `jg_catdaysnew`, `jg_showdescriptioningalleryview`, `jg_uploadicongallery`, `jg_showsubsingalleryview`, `jg_category_rss`, `jg_category_rss_icon`, `jg_uploadiconcategory`, `jg_showcathead`, `jg_usercatorder`, `jg_usercatorderlist`, `jg_showcatdescriptionincat`, `jg_showpagenav`, `jg_showpiccount`, `jg_perpage`, `jg_catthumbalign`, `jg_colnumb`, `jg_detailpic_open`, `jg_lightboxbigpic`, `jg_showtitle`, `jg_showpicasnew`, `jg_daysnew`, `jg_showhits`, `jg_showdownloads`, `jg_showauthor`, `jg_showowner`, `jg_showcatcom`, `jg_showcatrate`, `jg_showcatdescription`, `jg_showcategorydownload`, `jg_showcategoryfavourite`, `jg_category_report_images`, `jg_showcategoryeditorlinks`, `jg_showsubcathead`, `jg_showsubcatcount`, `jg_colsubcat`, `jg_subperpage`, `jg_showpagenavsubs`, `jg_subcatthumbalign`, `jg_showsubthumbs`, `jg_showrandomsubthumb`, `jg_showdescriptionincategoryview`, `jg_ordersubcatbyalpha`, `jg_showtotalsubcatimages`, `jg_showtotalsubcathits`, `jg_uploadiconsubcat`, `jg_showdetailpage`, `jg_disabledetailpage`, `jg_showdetailnumberofpics`, `jg_cursor_navigation`, `jg_disable_rightclick_detail`, `jg_detail_report_images`, `jg_showdetaileditorlinks`, `jg_showdetailtitle`, `jg_showdetail`, `jg_showdetailaccordion`, `jg_accordionduration`, `jg_accordiondisplay`, `jg_accordionopacity`, `jg_accordionalwayshide`, `jg_accordioninitialeffect`, `jg_showdetaildescription`, `jg_showdetaildatum`, `jg_showdetailhits`, `jg_showdetaildownloads`, `jg_showdetailrating`, `jg_showdetailfilesize`, `jg_showdetailauthor`, `jg_showoriginalfilesize`, `jg_showdetaildownload`, `jg_watermark`, `jg_watermarkpos`, `jg_bigpic`, `jg_bigpic_unreg`, `jg_bigpic_open`, `jg_bbcodelink`, `jg_showcommentsunreg`, `jg_showcommentsarea`, `jg_send2friend`, `jg_minis`, `jg_motionminis`, `jg_motionminiWidth`, `jg_motionminiHeight`, `jg_miniWidth`, `jg_miniHeight`, `jg_minisprop`, `jg_nameshields`, `jg_nameshields_others`, `jg_nameshields_unreg`, `jg_show_nameshields_unreg`, `jg_nameshields_height`, `jg_nameshields_width`, `jg_slideshow`, `jg_slideshow_timer`, `jg_slideshow_transition`, `jg_slideshow_transtime`, `jg_slideshow_maxdimauto`, `jg_slideshow_width`, `jg_slideshow_heigth`, `jg_slideshow_infopane`, `jg_slideshow_carousel`, `jg_slideshow_arrows`, `jg_slideshow_repeat`, `jg_showexifdata`, `jg_showgeotagging`, `jg_geotaggingkey`, `jg_subifdtags`, `jg_ifdotags`, `jg_gpstags`, `jg_showiptcdata`, `jg_iptctags`, `jg_showtoplist`, `jg_toplist`, `jg_topthumbalign`, `jg_toptextalign`, `jg_toplistcols`, `jg_whereshowtoplist`, `jg_showrate`, `jg_showlatest`, `jg_showcom`, `jg_showthiscomment`, `jg_showmostviewed`, `jg_showtoplistdownload`, `jg_showtoplistfavourite`, `jg_toplist_report_images`, `jg_showtoplisteditorlinks`, `jg_favourites`, `jg_showdetailfavourite`, `jg_favouritesshownotauth`, `jg_maxfavourites`, `jg_zipdownload`, `jg_usefavouritesforpubliczip`, `jg_usefavouritesforzip`, `jg_allimagesofcategory`, `jg_showfavouritesdownload`, `jg_showfavouriteseditorlinks`) VALUES
(1, 1, 1, 'images/joomgallery/details/', 'images/joomgallery/originals/', 'images/joomgallery/thumbnails/', 'administrator/components/com_joomgallery/temp/ftp_upload/', 'administrator/components/com_joomgallery/temp/', 'media/joomgallery/images/', 'watermark.png', 0, 0, 1, 'Š|S,Œ|O,Ž|Z,š|s,œ|oe,ž|z,Ÿ|Y,¥|Y,µ|u,À|A,Á|A,Â|A,Ã|A,Ä|AE,Å|A,Æ|A,Ç|C,È|E,É|E,Ê|E,Ë|E,Ì|I,Í|I,Î|I,Ï|I,Ð|D,Ñ|N,Ò|O,Ó|O,Ô|O,Õ|O,Ö|OE,Ø|O,Ù|U,Ú|U,Û|U,Ü|UE,Ý|Y,à|a,á|a,â|a,ã|a,ä|ae,å|a,æ|a,ç|c,è|e,é|e,ê|e,ë|e,ì|i,í|i,î|i,ï|i,ð|o,ñ|n,ò|o,ó|o,ô|o,õ|o,ö|oe,ø|o,ù|u,ú|u,û|u,ü|ue,ý|y,ÿ|y,ß|ss,ă|a,ş|s,ţ|t,ț|t,Ț|T,Ș|S,ș|s,Ş|S', 'gd2', 1, '', 1, 400, 100, 0, 2, 133, 100, 100, 2, 0, 0, 0, 1, '468', 0, '-1', 0, 0, '-1', 0, 0, '-1', 1, 0, 0, '-1', 0, 1, 0, 0, 0, 0, 1, '', 0, 0, 1, 0, 1, 0, 10, 500, 0, 10000000, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 2, 1, 0, 5, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'grey', 0, 1, 1, '_:default', 1, 1, 0, 2, 100, 100, '#ffffff', 0, 0, 0, 1, 1, 'ordering ASC', 'imgdate DESC', 'imgtitle DESC', '#page_title - [! COM_JOOMGALLERY_COMMON_CATEGORY!]: #cat', '#page_title - [! COM_JOOMGALLERY_COMMON_CATEGORY!]: #cat - [! COM_JOOMGALLERY_COMMON_IMAGE!]:  #img', 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 3, 1, 3, 1, 1, 1, 0, 1, 1, 10, '#ffffff', '#808080', 1, 1, 5, 1, 1, 1, 1, 1, 3, 9, 0, 1, 1, 1, 3, 1, 0, 1, 1, 7, 1, 1, 0, 10, 'rss', 0, 1, 1, 'date,title', 1, 2, 1, 8, 1, 2, '0', 1, 1, 1, 10, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 2, 8, 1, 3, 2, 3, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 300, 1, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 9, 1, 1, '6', 0, 1, 2, 1, 1, 2, 400, 50, 28, 28, 2, 0, 1, 1, 0, 10, 6, 1, 6000, 0, 2000, 0, 640, 480, 0, 0, 0, 0, 0, 0, '', '', '', '', 0, '', 2, 12, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_countstop`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_countstop` (
  `cspicid` int(11) NOT NULL DEFAULT '0',
  `csip` varchar(20) NOT NULL,
  `cssessionid` varchar(200) DEFAULT NULL,
  `cstime` datetime DEFAULT NULL,
  KEY `idx_cspicid` (`cspicid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_joomgallery_countstop`
--

INSERT INTO `analk_joomgallery_countstop` (`cspicid`, `csip`, `cssessionid`, `cstime`) VALUES
(70, '::1', '99e30728450d8afd04175d6466d3d8c4', '2015-09-15 13:56:21');

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_image_details`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_image_details` (
  `id` int(11) NOT NULL,
  `details_key` varchar(255) NOT NULL,
  `details_value` text NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`,`details_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_joomgallery_image_details`
--

INSERT INTO `analk_joomgallery_image_details` (`id`, `details_key`, `details_value`, `ordering`) VALUES
(3, 'additional.like', '', 2),
(3, 'additional.price', '', 1),
(4, 'additional.like', '20', 2),
(4, 'additional.price', '100000', 1),
(5, 'additional.like', '15', 2),
(5, 'additional.price', '75000', 1),
(9, 'additional.like', '50', 2),
(9, 'additional.price', '150000', 1),
(10, 'additional.like', '75', 2),
(10, 'additional.price', '400000', 1),
(11, 'additional.like', '33', 2),
(11, 'additional.price', '450000', 1),
(12, 'additional.like', '12', 2),
(12, 'additional.price', '50000', 1),
(13, 'additional.like', '44', 2),
(13, 'additional.price', '210000', 1),
(14, 'additional.like', '22', 2),
(14, 'additional.price', '77000', 1),
(15, 'additional.like', '32', 2),
(15, 'additional.price', '330000', 1),
(16, 'additional.like', '26', 2),
(16, 'additional.price', '350000', 1),
(17, 'additional.like', '11', 2),
(17, 'additional.price', '125000', 1),
(25, 'additional.like', '24', 2),
(25, 'additional.price', '200000', 1),
(26, 'additional.like', '52', 2),
(26, 'additional.price', '320000', 1),
(27, 'additional.like', '12', 2),
(27, 'additional.price', '100000', 1),
(28, 'additional.like', '16', 2),
(28, 'additional.price', '160000', 1),
(29, 'additional.like', '27', 2),
(29, 'additional.price', '170000', 1),
(30, 'additional.like', '54', 2),
(30, 'additional.price', '250000', 1),
(31, 'additional.like', '23', 2),
(31, 'additional.price', '152000', 1),
(32, 'additional.like', '14', 2),
(32, 'additional.price', '140000', 1),
(33, 'additional.like', '18', 2),
(33, 'additional.price', '123000', 1),
(34, 'additional.like', '21', 2),
(34, 'additional.price', '210000', 1),
(35, 'additional.like', '22', 2),
(35, 'additional.price', '220000', 1),
(36, 'additional.like', '23', 2),
(36, 'additional.price', '230000', 1),
(37, 'additional.like', '24', 2),
(37, 'additional.price', '240000', 1),
(38, 'additional.like', '25', 2),
(38, 'additional.price', '250000', 1),
(39, 'additional.like', '26', 2),
(39, 'additional.price', '260000', 1),
(40, 'additional.like', '27', 2),
(40, 'additional.price', '270000', 1),
(41, 'additional.like', '28', 2),
(41, 'additional.price', '280000', 1),
(42, 'additional.like', '29', 2),
(42, 'additional.price', '290000', 1),
(43, 'additional.like', '30', 2),
(43, 'additional.price', '300000', 1),
(44, 'additional.like', '36', 2),
(44, 'additional.price', '360000', 1),
(45, 'additional.like', '37', 2),
(45, 'additional.price', '370000', 1),
(46, 'additional.like', '38', 2),
(46, 'additional.price', '380000', 1),
(47, 'additional.like', '39', 2),
(47, 'additional.price', '390000', 1),
(48, 'additional.like', '40', 2),
(48, 'additional.price', '400000', 1),
(49, 'additional.code', 'ZD839F2', 3),
(49, 'additional.like', '41', 2),
(49, 'additional.price', '410000', 1),
(49, 'additional.tags', 'tôm chiên, ẩm thực', 4),
(50, 'additional.like', '42', 2),
(50, 'additional.price', '420000', 1),
(51, 'additional.like', '43', 2),
(51, 'additional.price', '430000', 1),
(52, 'additional.like', '44', 2),
(52, 'additional.price', '440000', 1),
(53, 'additional.like', '45', 2),
(53, 'additional.price', '450000', 1),
(54, 'additional.like', '46', 2),
(54, 'additional.price', '460000', 1),
(55, 'additional.like', '47', 2),
(55, 'additional.price', '470000', 1),
(56, 'additional.like', '48', 2),
(56, 'additional.price', '480000', 1),
(57, 'additional.like', '49', 2),
(57, 'additional.price', '490000', 1),
(58, 'additional.like', '50', 2),
(58, 'additional.price', '500000', 1),
(59, 'additional.like', '51', 2),
(59, 'additional.price', '510000', 1),
(60, 'additional.like', '52', 2),
(60, 'additional.price', '520000', 1),
(61, 'additional.like', '53', 2),
(61, 'additional.price', '530000', 1),
(62, 'additional.like', '54', 2),
(62, 'additional.price', '540000', 1),
(63, 'additional.like', '55', 2),
(63, 'additional.price', '550000', 1),
(64, 'additional.like', '56', 2),
(64, 'additional.price', '560000', 1),
(65, 'additional.like', '57', 2),
(65, 'additional.price', '570000', 1),
(66, 'additional.like', '58', 2),
(66, 'additional.price', '580000', 1),
(67, 'additional.like', '59', 2),
(67, 'additional.price', '590000', 1),
(68, 'additional.code', 'ZD839F2', 3),
(68, 'additional.like', '60', 2),
(68, 'additional.price', '600000', 1),
(68, 'additional.tags', 'xe moto, chủ đề khác', 4),
(70, 'additional.code', '90A4IuV6uK', 3),
(70, 'additional.like', '', 4),
(70, 'additional.price', '500000', 2),
(70, 'additional.tags', 'bau huong, phú yên', 1),
(71, 'additional.code', 'XvaIPBUI0o', 3),
(71, 'additional.price', '150000', 1),
(71, 'additional.tags', 'hoa, nghe thuat', 4);

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_maintenance`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_maintenance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `title` text NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `orig` varchar(255) NOT NULL,
  `thumborphan` int(11) NOT NULL,
  `imgorphan` int(11) NOT NULL,
  `origorphan` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_nameshields`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_nameshields` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `npicid` int(11) NOT NULL DEFAULT '0',
  `nuserid` int(11) unsigned NOT NULL DEFAULT '0',
  `nxvalue` int(11) NOT NULL DEFAULT '0',
  `nyvalue` int(11) NOT NULL DEFAULT '0',
  `by` int(11) NOT NULL DEFAULT '0',
  `nuserip` varchar(15) NOT NULL DEFAULT '0',
  `ndate` datetime NOT NULL,
  `nzindex` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`),
  KEY `idx_picid` (`npicid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_orphans`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_orphans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullpath` varchar(255) NOT NULL,
  `type` varchar(7) NOT NULL,
  `refid` int(11) NOT NULL,
  `title` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fullpath` (`fullpath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_users`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uuserid` int(11) NOT NULL DEFAULT '0',
  `piclist` text,
  `layout` int(1) NOT NULL,
  `time` datetime NOT NULL,
  `zipname` varchar(70) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `idx_uid` (`uuserid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `analk_joomgallery_users`
--

INSERT INTO `analk_joomgallery_users` (`uid`, `uuserid`, `piclist`, `layout`, `time`, `zipname`) VALUES
(1, 469, '70', 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_joomgallery_votes`
--

CREATE TABLE IF NOT EXISTS `analk_joomgallery_votes` (
  `voteid` int(11) NOT NULL AUTO_INCREMENT,
  `picid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) unsigned NOT NULL DEFAULT '0',
  `userip` varchar(15) NOT NULL DEFAULT '0',
  `datevoted` datetime NOT NULL,
  `vote` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`voteid`),
  KEY `idx_picid` (`picid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_languages`
--

CREATE TABLE IF NOT EXISTS `analk_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `analk_languages`
--

INSERT INTO `analk_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 0, 1, 1),
(2, 'vi-VN', 'Vietnamese', 'Vietnamese', 'vi', 'vi', '', '', '', '', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_menu`
--

CREATE TABLE IF NOT EXISTS `analk_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_path` (`path`(255)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=173 ;

--
-- Dumping data for table `analk_menu`
--

INSERT INTO `analk_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 113, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 1, 10, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 2, 3, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 4, 5, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 6, 7, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 8, 9, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 21, 26, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 22, 23, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 24, 25, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 27, 32, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 28, 29, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 30, 31, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 33, 34, 0, '*', 1),
(19, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 1, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 35, 36, 0, '*', 1),
(20, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 0, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 37, 38, 0, '', 1),
(21, 'main', 'com_postinstall', 'Post-installation messages', '', 'Post-installation messages', 'index.php?option=com_postinstall', 'component', 0, 1, 1, 32, 0, '0000-00-00 00:00:00', 0, 1, 'class:postinstall', 0, '', 39, 40, 0, '*', 1),
(101, 'mainmenu', 'Trang chủ', 'home', '', 'home', 'index.php?option=com_content&view=featured', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"featured_categories":[""],"layout_type":"blog","num_leading_articles":"","num_intro_articles":"","num_columns":"","num_links":"","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"1","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 41, 42, 1, '*', 0),
(102, 'main', 'COM_JOOMGALLERY', 'com-joomgallery', '', 'com-joomgallery', 'index.php?option=com_joomgallery', 'component', 0, 1, 1, 10010, 0, '0000-00-00 00:00:00', 0, 1, '../media/joomgallery/images/joom_main.png', 0, '', 43, 70, 0, '', 1),
(103, 'main', 'COM_JOOMGALLERY_CATEGORY_MANAGER', 'com-joomgallery-category-manager', '', 'com-joomgallery/com-joomgallery-category-manager', 'index.php?option=com_joomgallery&controller=categories', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_categories.png', 0, '', 44, 45, 0, '', 1),
(104, 'main', 'COM_JOOMGALLERY_IMAGE_MANAGER', 'com-joomgallery-image-manager', '', 'com-joomgallery/com-joomgallery-image-manager', 'index.php?option=com_joomgallery&controller=images', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_pictures.png', 0, '', 46, 47, 0, '', 1),
(105, 'main', 'COM_JOOMGALLERY_COMMENTS_MANAGER', 'com-joomgallery-comments-manager', '', 'com-joomgallery/com-joomgallery-comments-manager', 'index.php?option=com_joomgallery&controller=comments', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_comments.png', 0, '', 48, 49, 0, '', 1),
(106, 'main', 'COM_JOOMGALLERY_IMAGE_UPLOAD', 'com-joomgallery-image-upload', '', 'com-joomgallery/com-joomgallery-image-upload', 'index.php?option=com_joomgallery&controller=upload', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_pictureupload.png', 0, '', 50, 51, 0, '', 1),
(107, 'main', 'COM_JOOMGALLERY_AJAX_UPLOAD', 'com-joomgallery-ajax-upload', '', 'com-joomgallery/com-joomgallery-ajax-upload', 'index.php?option=com_joomgallery&controller=ajaxupload', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_ajaxupload.png', 0, '', 52, 53, 0, '', 1),
(108, 'main', 'COM_JOOMGALLERY_BATCH_UPLOAD', 'com-joomgallery-batch-upload', '', 'com-joomgallery/com-joomgallery-batch-upload', 'index.php?option=com_joomgallery&controller=batchupload', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_batchupload.png', 0, '', 54, 55, 0, '', 1),
(109, 'main', 'COM_JOOMGALLERY_FTP_UPLOAD', 'com-joomgallery-ftp-upload', '', 'com-joomgallery/com-joomgallery-ftp-upload', 'index.php?option=com_joomgallery&controller=ftpupload', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_ftpupload.png', 0, '', 56, 57, 0, '', 1),
(110, 'main', 'COM_JOOMGALLERY_JAVA_UPLOAD', 'com-joomgallery-java-upload', '', 'com-joomgallery/com-joomgallery-java-upload', 'index.php?option=com_joomgallery&controller=jupload', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_jupload.png', 0, '', 58, 59, 0, '', 1),
(111, 'main', 'COM_JOOMGALLERY_CONFIGURATION_MANAGER', 'com-joomgallery-configuration-manager', '', 'com-joomgallery/com-joomgallery-configuration-manager', 'index.php?option=com_joomgallery&controller=config', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_config.png', 0, '', 60, 61, 0, '', 1),
(112, 'main', 'COM_JOOMGALLERY_CUSTOMIZE_CSS', 'com-joomgallery-customize-css', '', 'com-joomgallery/com-joomgallery-customize-css', 'index.php?option=com_joomgallery&controller=cssedit', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_css.png', 0, '', 62, 63, 0, '', 1),
(113, 'main', 'COM_JOOMGALLERY_MIGRATION_MANAGER', 'com-joomgallery-migration-manager', '', 'com-joomgallery/com-joomgallery-migration-manager', 'index.php?option=com_joomgallery&controller=migration', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_migration.png', 0, '', 64, 65, 0, '', 1),
(114, 'main', 'COM_JOOMGALLERY_MAINTENANCE_MANAGER', 'com-joomgallery-maintenance-manager', '', 'com-joomgallery/com-joomgallery-maintenance-manager', 'index.php?option=com_joomgallery&controller=maintenance', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_maintenance.png', 0, '', 66, 67, 0, '', 1),
(115, 'main', 'COM_JOOMGALLERY_HELP', 'com-joomgallery-help', '', 'com-joomgallery/com-joomgallery-help', 'index.php?option=com_joomgallery&controller=help', 'component', 0, 102, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, 'media/joomgallery/images/joom_information.png', 0, '', 68, 69, 0, '', 1),
(129, 'main', 'COM_RECHARGE', 'com-recharge', '', 'com-recharge', 'index.php?option=com_recharge', 'component', 0, 1, 1, 10037, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_recharge/assets/images/s_com_recharge.png', 0, '', 71, 74, 0, '', 1),
(130, 'main', 'COM_RECHARGE_TITLE_CACGIAODICH', 'com-recharge-title-cacgiaodich', '', 'com-recharge/com-recharge-title-cacgiaodich', 'index.php?option=com_recharge&view=cacgiaodich', 'component', 0, 129, 2, 10037, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_recharge/assets/images/s_cacgiaodich.png', 0, '', 72, 73, 0, '', 1),
(131, 'main', 'COM_ORDERS', 'com-orders', '', 'com-orders', 'index.php?option=com_orders', 'component', 0, 1, 1, 10038, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_orders/assets/images/s_com_orders.png', 0, '', 75, 78, 0, '', 1),
(132, 'main', 'COM_ORDERS_TITLE_DONHANG', 'com-orders-title-donhang', '', 'com-orders/com-orders-title-donhang', 'index.php?option=com_orders&view=donhang', 'component', 0, 131, 2, 10038, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_orders/assets/images/s_donhang.png', 0, '', 76, 77, 0, '', 1),
(133, 'mainmenu', 'Thư viện ảnh', 'gallery', '', 'gallery', '#', 'url', 1, 1, 1, 10010, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 79, 84, 0, '*', 0),
(134, 'mainmenu', 'Tất cả', 'tat-ca', '', 'gallery/tat-ca', 'index.php?option=com_joomgallery&view=gallery', 'component', 1, 133, 2, 10010, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 80, 81, 0, '*', 0),
(135, 'mainmenu', 'Thắng cảnh', 'thang-canh', '', 'gallery/thang-canh', 'index.php?option=com_joomgallery&view=category&catid=4', 'component', 1, 133, 2, 10010, 468, '2015-09-04 00:04:31', 0, 1, '', 0, '{"disable_global_info":"0","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 82, 83, 0, '*', 0),
(136, 'mainmenu', 'Tin tức', 'tin-tuc', '', 'tin-tuc', 'index.php?option=com_content&view=category&layout=blog&id=8', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"layout_type":"blog","show_category_heading_title_text":"","show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_no_articles":"","show_subcat_desc":"","show_cat_num_articles":"","show_cat_tags":"","page_subheading":"","num_leading_articles":"","num_intro_articles":"","num_columns":"","num_links":"","multi_column_order":"","show_subcategory_content":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_featured":"","show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 85, 86, 0, '*', 0),
(137, 'mainmenu', 'Giới thiệu', 'gioi-thieu', '', 'gioi-thieu', 'index.php?option=com_content&view=article&id=1', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 87, 88, 0, '*', 0),
(138, 'hiddenmenu', 'Đăng nhập', 'dang-nhap', '', 'dang-nhap', 'index.php?option=com_users&view=login', 'component', 1, 1, 1, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"login_redirect_url":"","logindescription_show":"1","login_description":"","login_image":"","logout_redirect_url":"","logoutdescription_show":"1","logout_description":"","logout_image":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 89, 90, 0, '*', 0),
(139, 'hiddenmenu', 'Đăng ký', 'dang-ky', '', 'dang-ky', 'index.php?option=com_users&view=registration', 'component', 1, 1, 1, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 91, 92, 0, '*', 0),
(140, 'usermenu', 'Tác phẩm', 'ca-nhan', '', 'ca-nhan', 'index.php?option=com_joomgallery&view=userpanel', 'component', 1, 1, 1, 10010, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 11, 12, 0, '*', 0),
(141, 'usermenu', 'Chỉnh sửa thông tin', 'chinh-sua-thong-tin', '', 'chinh-sua-thong-tin', 'index.php?option=com_users&view=profile&layout=edit', 'component', 1, 1, 1, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 15, 16, 0, '*', 0),
(142, 'hiddenmenu', 'Xem người dùng', 'xem-nguoi-dung', '', 'xem-nguoi-dung', 'index.php?option=com_recharge&view=user', 'component', 1, 1, 1, 10037, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 93, 94, 0, '*', 0),
(143, 'usermenu', 'Nạp thẻ', 'nap-the', '', 'nap-the', 'index.php?option=com_recharge&view=recharge', 'component', 1, 1, 1, 10037, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 17, 18, 0, '*', 0),
(144, 'usermenu', 'Lịch sử nạp thẻ', 'lich-su-nap-the', '', 'lich-su-nap-the', 'index.php?option=com_recharge&view=history', 'component', 1, 1, 1, 10037, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 19, 20, 0, '*', 0),
(163, 'main', 'jNews', 'jnews', '', 'jnews', 'index.php?option=com_jnews', 'component', 0, 1, 1, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/jnewsletter_icon.png', 0, '', 95, 112, 0, '', 1),
(164, 'main', 'Lists', 'lists', '', 'jnews/lists', 'index.php?option=com_jnews&act=list', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/lists.png', 0, '', 96, 97, 0, '', 1),
(165, 'main', 'Subscribers', 'subscribers', '', 'jnews/subscribers', 'index.php?option=com_jnews&act=subscribers', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/subscribers.png', 0, '', 98, 99, 0, '', 1),
(166, 'main', 'Newsletters', 'newsletters', '', 'jnews/newsletters', 'index.php?option=com_jnews&act=mailing&listype=1', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/newsletter.png', 0, '', 100, 101, 0, '', 1),
(167, 'main', 'Statistics', 'statistics', '', 'jnews/statistics', 'index.php?option=com_jnews&act=statistics', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/statistics.png', 0, '', 102, 103, 0, '', 1),
(168, 'main', 'Queue', 'queue', '', 'jnews/queue', 'index.php?option=com_jnews&act=queue', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/queue.png', 0, '', 104, 105, 0, '', 1),
(169, 'main', 'Templates', 'templates', '', 'jnews/templates', 'index.php?option=com_jnews&act=templates', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/templates.png', 0, '', 106, 107, 0, '', 1),
(170, 'main', 'Configuration', 'configuration', '', 'jnews/configuration', 'index.php?option=com_jnews&act=configuration', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/configuration.png', 0, '', 108, 109, 0, '', 1),
(171, 'main', 'About', 'about', '', 'jnews/about', 'index.php?option=com_jnews&act=about', 'component', 0, 163, 2, 10059, 0, '0000-00-00 00:00:00', 0, 1, '../administrator/components/com_jnews/images/16/about.png', 0, '', 110, 111, 0, '', 1),
(172, 'usermenu', 'Tác phẩm yêu thích', 'tac-pham-yeu-thich', '', 'tac-pham-yeu-thich', 'index.php?option=com_recharge&view=favourite', 'component', 1, 1, 1, 10037, 468, '2015-09-14 21:38:52', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":"","page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 13, 14, 0, '*', 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_menu_types`
--

CREATE TABLE IF NOT EXISTS `analk_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `analk_menu_types`
--

INSERT INTO `analk_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(2, 'hiddenmenu', 'Hidden Menu', ''),
(3, 'usermenu', 'User Menu', '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_messages`
--

CREATE TABLE IF NOT EXISTS `analk_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `analk_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_modules`
--

CREATE TABLE IF NOT EXISTS `analk_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `analk_modules`
--

INSERT INTO `analk_modules` (`id`, `asset_id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 39, 'Main Menu', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(2, 40, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 41, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(4, 42, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(8, 43, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 44, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 45, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(12, 46, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 47, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 48, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 49, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(16, 50, 'Login Form', '', '', 7, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"greeting":"1","name":"0"}', 0, '*'),
(17, 51, 'Breadcrumbs', '', '', 1, 'position-2', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"showHere":"0","showHome":"1","homeText":"Trang chủ","showLast":"1","separator":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(79, 52, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(86, 53, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(87, 54, 'JoomGallery News', '', '', 1, 'joom_cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_feed', 1, 1, 'cache=1\n    cache_time=15\n    moduleclass_sfx=\n    rssurl=http://www.en.joomgallery.net/feed/rss.html\n    rssrtl=0\n    rsstitle=1\n    rssdesc=0\n    rssimage=1\n    rssitems=3\n    rssitemdesc=1\n    word_count=200', 1, '*'),
(91, 87, 'JoomSearch', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_joomsearch', 1, 1, '', 0, '*'),
(92, 150, 'Tin tức', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{"catid":["8"],"count":"3","show_featured":"","ordering":"c_dsc","user_id":"0","layout":"_:default","moduleclass_sfx":"3","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(93, 156, 'Thông tin', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_articles_latest', 1, 1, '{"catid":["9"],"count":"4","show_featured":"","ordering":"c_dsc","user_id":"0","layout":"_:default","moduleclass_sfx":"2","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(94, 157, 'Bảo trợ bởi', '', '<ul class="ul-reset footer-ul">\r\n<li><a href="#">Vnexpress.net</a></li>\r\n<li><a href="#">Tuoitre.com.vn</a></li>\r\n<li><a href="#">Tuoitre.com.vn</a></li>\r\n<li><a href="#">Ingo.net</a></li>\r\n</ul>', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"col-sm-2","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(95, 158, 'Liên hệ', '', '<ul class="ul-reset footer-ul">\r\n<li>Khoảnh Khắc Việt Nam</li>\r\n<li>Email: <a href="mailto:kkvn@vdca.org.vn">kkvn@vdca.org.vn</a></li>\r\n<li>Hotline: 04.3.6338833</li>\r\n</ul>', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"col-sm-2","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(96, 160, 'Tác phẩm chọn lọc', '', 'Những tác phẩm được chọn lọc bởi Khoảnh Khắc Việt Nam', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_special_gallery', 1, 1, '{"module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(97, 161, 'Tác phẩm mới', '', 'Những tác phẩm mới nhất vừa được đưa lên', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_new_gallery', 1, 1, '{"module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(98, 162, 'Tác phẩm đang được yêu thích nhất', '', 'Những tác phẩm được thích nhiều nhất trong thời gian gần đây', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_like_gallery', 1, 1, '{"module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(99, 165, 'Thành viên mới', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_users_latest', 1, 1, '{"shownumber":"8","filter_groups":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(100, 170, 'Newsletter', '', '', 1, 'position-7', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_jnews', 1, 1, '{"use_new":"1","linear":"0","moduleclass_sfx":"","cssfile":"default.css","effect":"default","listids":"0","showlistname":"1","defaultchecked":"1","dropdown":"0","selecteddrop":"0","red_url":"http:\\/\\/localhost\\/kkvn\\/index.php?option=com_content&view=article&id=10","introtext":"","posttext":"","fieldsize":"10","shownamefield":"1","req_name":"1","column1":"0","receivehtmldefault":"1","showreceivehtml":"1","show_terms":"0","check_terms":"0","terms_condition":"","enable_captcha":"0","button_text":"","button_img":"","button_text_change":"","button_img_change":"","mootools_btntext":"","mootools_boxw":"200","mootools_boxh":"210","mod_align":"","cache":"0","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(101, 172, 'UserMenu', '', '', 1, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"usermenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"kkvn:user","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*');

-- --------------------------------------------------------

--
-- Table structure for table `analk_modules_menu`
--

CREATE TABLE IF NOT EXISTS `analk_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_modules_menu`
--

INSERT INTO `analk_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(79, 0),
(86, 0),
(87, 0),
(92, 0),
(93, 0),
(94, 0),
(95, 0),
(96, 0),
(97, 0),
(98, 0),
(99, 0),
(100, 0),
(101, 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_orders`
--

CREATE TABLE IF NOT EXISTS `analk_orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `author` int(11) NOT NULL,
  `price` varchar(20) NOT NULL,
  `push_notification` tinyint(4) NOT NULL DEFAULT '0',
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_overrider`
--

CREATE TABLE IF NOT EXISTS `analk_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_postinstall_messages`
--

CREATE TABLE IF NOT EXISTS `analk_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) NOT NULL DEFAULT '',
  `language_extension` varchar(255) NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `analk_postinstall_messages`
--

INSERT INTO `analk_postinstall_messages` (`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES
(1, 700, 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', 1, 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', 1),
(2, 700, 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', 1, 'message', '', '', '', '', '3.2.0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `analk_recharge`
--

CREATE TABLE IF NOT EXISTS `analk_recharge` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `serial` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `provider` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `message` varchar(255) NOT NULL,
  `amount` varchar(10) NOT NULL,
  `trans_id` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `analk_recharge`
--

INSERT INTO `analk_recharge` (`id`, `userid`, `serial`, `code`, `provider`, `status`, `message`, `amount`, `trans_id`, `time`) VALUES
(3, 469, '36100300092955', '11630131797050', 'VNP', 50, 'card does not exist or used', '1000000', '008492015090813092355ee84b7984d4', '1441694946');

-- --------------------------------------------------------

--
-- Table structure for table `analk_redirect_links`
--

CREATE TABLE IF NOT EXISTS `analk_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) DEFAULT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_link_old` (`old_url`),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_schemas`
--

CREATE TABLE IF NOT EXISTS `analk_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_schemas`
--

INSERT INTO `analk_schemas` (`extension_id`, `version_id`) VALUES
(700, '3.4.0-2015-02-26'),
(10010, '3.2.1');

-- --------------------------------------------------------

--
-- Table structure for table `analk_session`
--

CREATE TABLE IF NOT EXISTS `analk_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_session`
--

INSERT INTO `analk_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('e9ftsg8450ot8v53l7u1hjdb55', 0, 0, '1442300212', '__default|a:9:{s:15:"session.counter";i:68;s:19:"session.timer.start";i:1442287427;s:18:"session.timer.last";i:1442300201;s:17:"session.timer.now";i:1442300211;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0";s:8:"registry";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":1:{s:5:"users";O:8:"stdClass":1:{s:5:"login";O:8:"stdClass":1:{s:4:"form";O:8:"stdClass":2:{s:4:"data";a:0:{}s:6:"return";s:22:"http://localhost/kkvn/";}}}}s:9:"separator";s:1:".";}s:4:"user";O:5:"JUser":35:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";s:3:"469";s:4:"name";s:9:"Trung aaa";s:8:"username";s:20:"nttrung211@yahoo.com";s:5:"email";s:20:"nttrung211@yahoo.com";s:8:"password";s:60:"$2y$10$vQnsdTTfHByqjvj9z.IcnOxl.DdwSH0oD0lAfxOBpG2AfFZ6NfOEO";s:14:"password_clear";s:0:"";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"0";s:12:"registerDate";s:19:"2015-08-10 02:33:25";s:13:"lastvisitDate";s:19:"2015-09-14 09:31:58";s:10:"activation";s:0:"";s:6:"params";s:92:"{"editor":"","timezone":"","language":"","admin_style":"","admin_language":"","helpsite":""}";s:6:"groups";a:1:{i:2;s:1:"2";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:12:"requireReset";s:1:"0";s:10:"\\0\\0\\0_params";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":6:{s:6:"editor";s:0:"";s:8:"timezone";s:0:"";s:8:"language";s:0:"";s:11:"admin_style";s:0:"";s:14:"admin_language";s:0:"";s:8:"helpsite";s:0:"";}s:9:"separator";s:1:".";}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:2;}s:14:"\\0\\0\\0_authLevels";a:3:{i:0;i:1;i:1;i:1;i:2;i:2;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:13:"\\0\\0\\0userHelper";O:18:"JUserWrapperHelper":0:{}s:5:"phone";s:10:"0909702522";s:7:"balance";s:7:"1000000";s:6:"status";s:150:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse at scelerisque tellus. Vivamus posuere erat nisl, in ullamcorper orci gravida et.";s:4:"hits";s:2:"11";s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:6:"otpKey";s:0:"";s:4:"otep";s:0:"";s:16:"push_buy_gallery";s:1:"0";s:9:"push_news";s:1:"0";s:9:"gcm_regid";s:0:"";}s:13:"session.token";s:32:"99e30728450d8afd04175d6466d3d8c4";s:17:"application.queue";a:4:{i:0;a:2:{s:7:"message";s:50:"Ảnh đã được xóa khỏi mục yêu thích.";s:4:"type";s:7:"message";}i:1;a:2:{s:7:"message";s:50:"Ảnh đã được xóa khỏi mục yêu thích.";s:4:"type";s:7:"message";}i:2;a:2:{s:7:"message";s:50:"Ảnh đã được xóa khỏi mục yêu thích.";s:4:"type";s:7:"message";}i:3;a:2:{s:7:"message";s:48:"Ảnh đã được thêm vào mục ưu thích.";s:4:"type";s:7:"message";}}}', 469, 'nttrung211@yahoo.com'),
('mqcvqnh3rgrqmaqc1qt650nos4', 1, 0, '1442291933', '__default|a:8:{s:15:"session.counter";i:80;s:19:"session.timer.start";i:1442287418;s:18:"session.timer.last";i:1442291931;s:17:"session.timer.now";i:1442291932;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0";s:8:"registry";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":4:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:0:"";}s:9:"com_menus";O:8:"stdClass":2:{s:5:"items";O:8:"stdClass":4:{s:8:"menutype";s:8:"usermenu";s:10:"limitstart";i:0;s:4:"list";a:2:{s:12:"fullordering";s:9:"a.lft ASC";s:5:"limit";s:2:"20";}s:6:"filter";a:5:{s:6:"search";s:0:"";s:9:"published";s:0:"";s:6:"access";s:0:"";s:8:"language";s:0:"";s:5:"level";s:0:"";}}s:4:"edit";O:8:"stdClass":2:{s:4:"item";O:8:"stdClass":4:{s:4:"data";N;s:4:"type";N;s:4:"link";N;s:2:"id";a:1:{i:0;i:172;}}s:4:"menu";O:8:"stdClass":1:{s:4:"data";N;}}}s:4:"item";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:8:"menutype";s:10:"hiddenmenu";}}s:11:"com_modules";O:8:"stdClass":3:{s:7:"modules";O:8:"stdClass":1:{s:6:"filter";O:8:"stdClass":1:{s:18:"client_id_previous";i:0;}}s:4:"edit";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":1:{s:4:"data";N;}}s:3:"add";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:12:"extension_id";N;s:6:"params";N;}}}}s:9:"separator";s:1:".";}s:4:"user";O:5:"JUser":35:{s:9:"\\0\\0\\0isRoot";b:1;s:2:"id";s:3:"468";s:4:"name";s:10:"Super User";s:8:"username";s:5:"admin";s:5:"email";s:20:"nttrung211@gmail.com";s:8:"password";s:60:"$2y$10$oT0XHTx1CBuK2fsHgZkICeE4JgHRRXFO5oFDR9cd59VNVGiRNcaPe";s:14:"password_clear";s:0:"";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:12:"registerDate";s:19:"2015-08-02 16:50:48";s:13:"lastvisitDate";s:19:"2015-09-14 09:11:20";s:10:"activation";s:1:"0";s:6:"params";s:0:"";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:12:"requireReset";s:1:"0";s:10:"\\0\\0\\0_params";O:24:"Joomla\\Registry\\Registry":2:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}s:9:"separator";s:1:".";}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\\0\\0\\0_authLevels";a:5:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:6;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:13:"\\0\\0\\0userHelper";O:18:"JUserWrapperHelper":0:{}s:5:"phone";s:0:"";s:7:"balance";s:1:"0";s:6:"status";s:0:"";s:4:"hits";s:1:"0";s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:6:"otpKey";s:0:"";s:4:"otep";s:0:"";s:16:"push_buy_gallery";s:1:"0";s:9:"push_news";s:1:"0";s:9:"gcm_regid";s:0:"";}s:13:"session.token";s:32:"31e9710f56f288500bdbbefdcf76ef00";}', 468, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `analk_tags`
--

CREATE TABLE IF NOT EXISTS `analk_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `analk_tags`
--

INSERT INTO `analk_tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES
(1, 0, 0, 1, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '', '', '', '', 0, '2011-01-01 00:00:01', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `analk_template_styles`
--

CREATE TABLE IF NOT EXISTS `analk_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `analk_template_styles`
--

INSERT INTO `analk_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(4, 'beez3', 0, '0', 'Beez3 - Default', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/joomla_black.png","sitetitle":"Joomla!","sitedescription":"Open Source Content Management","navposition":"left","templatecolor":"personal","html5":"0"}'),
(5, 'hathor', 1, '0', 'Hathor - Default', '{"showSiteName":"0","colourChoice":"","boldText":"0"}'),
(7, 'protostar', 0, '0', 'protostar - Default', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}'),
(8, 'isis', 1, '1', 'isis - Default', '{"templateColor":"#10223e","headerColor":"#1a3867","sidebarColor":"#0088cc","linkColor":"#0088cc","logoFile":"","loginLogoFile":"images\\/banners\\/white.png","admin_menus":1,"displayHeader":1,"statusFixed":1,"stickyToolbar":1}'),
(9, 'kkvn', 0, '1', 'kkvn - Mặc định', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `analk_ucm_base`
--

CREATE TABLE IF NOT EXISTS `analk_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `analk_ucm_content`
--

CREATE TABLE IF NOT EXISTS `analk_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_ucm_history`
--

CREATE TABLE IF NOT EXISTS `analk_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `analk_ucm_history`
--

INSERT INTO `analk_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(1, 1, 1, '', '2015-08-05 04:59:24', 468, 1686, '52b1e5e277209daed79b6b8371f6dbc1d445b74d', '{"id":1,"asset_id":59,"title":"Kho\\u1ea3nh kh\\u1eafc","alias":"khoanh-khac","introtext":"<p>asdasd<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-08-05 04:59:24","created_by":"468","created_by_alias":"","modified":"2015-08-05 04:59:24","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-05 04:59:24","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(2, 8, 5, '', '2015-08-14 08:04:44', 468, 557, 'e9bada45bfca0171cc21ee4ae620c8838d4d37df', '{"id":8,"asset_id":146,"parent_id":"1","lft":"11","rgt":12,"level":1,"path":null,"extension":"com_content","title":"Tin t\\u1ee9c","alias":"tin-tuc","note":"","description":"","published":"1","checked_out":null,"checked_out_time":null,"access":"1","params":"{\\"category_layout\\":\\"\\",\\"image\\":\\"\\",\\"image_alt\\":\\"\\"}","metadesc":"","metakey":"","metadata":"{\\"author\\":\\"\\",\\"robots\\":\\"\\"}","created_user_id":"468","created_time":"2015-08-14 08:04:44","modified_user_id":null,"modified_time":"2015-08-14 08:04:44","hits":"0","language":"*","version":null}', 0),
(3, 1, 1, '', '2015-08-14 08:16:21', 468, 3768, '98ce1deeb0e84a42760005e469a10074d2877510', '{"id":1,"asset_id":"59","title":"Gi\\u1edbi thi\\u1ec7u","alias":"khoanh-khac","introtext":"<p>In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<\\/p>","fulltext":"","state":1,"catid":"2","created":"2015-08-05 04:59:24","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:16:21","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:15:23","publish_up":"2015-08-05 04:59:24","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(4, 2, 1, '', '2015-08-14 08:18:48', 468, 3847, '4483106b51d8456b21b5bbba0b084f21ee4fdf9f', '{"id":2,"asset_id":147,"title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh","alias":"da-nang-trip-du-lich-ket-hop-chup-anh","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"2","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:18:48","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(5, 3, 1, '', '2015-08-14 08:18:59', 468, 3834, '718edf8e7f57a7ae87ca940c16dee8953105ce82', '{"id":3,"asset_id":148,"title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (2)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-2","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":0,"catid":"2","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:18:59","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(6, 3, 1, '', '2015-08-14 08:19:08', 468, 3872, 'e86c32f97afd50074e472f5407b92bbb09e22c77', '{"id":3,"asset_id":"148","title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (2)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-2","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"2","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:08","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:18:59","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(7, 4, 1, '', '2015-08-14 08:19:13', 468, 3834, '6792614dee28c138fd599c7485fe5aa2bde88d7a', '{"id":4,"asset_id":149,"title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (3)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-3","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":0,"catid":"2","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:13","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(8, 4, 1, '', '2015-08-14 08:19:21', 468, 3872, '9e4405c87d502d08c938b80450250579ec976ee5', '{"id":4,"asset_id":"149","title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (3)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-3","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"2","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:21","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:19:13","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(9, 2, 1, '', '2015-08-14 08:19:34', 468, 3866, '8e16d158e6f814ed01ddcd1de2d342cf3d4eb810', '{"id":2,"asset_id":"147","title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh","alias":"da-nang-trip-du-lich-ket-hop-chup-anh","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"8","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:34","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:19:29","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"2","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(10, 3, 1, '', '2015-08-14 08:19:44', 468, 3872, 'b3b13322b78028fff9f433261e350b13eca224fc', '{"id":3,"asset_id":"148","title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (2)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-2","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"8","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:44","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:19:37","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":3,"ordering":"1","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(11, 4, 1, '', '2015-08-14 08:19:53', 468, 3872, '09ddca6dad348b3fe479b602eda8c284f7cd4f65', '{"id":4,"asset_id":"149","title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (3)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-3","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":1,"catid":"8","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-14 08:19:53","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-14 08:19:47","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":3,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(12, 9, 5, '', '2015-08-17 06:32:56', 468, 561, '230af3736c54eeff8e28ae6147adaa5079a3f4ff', '{"id":9,"asset_id":151,"parent_id":"1","lft":"13","rgt":14,"level":1,"path":null,"extension":"com_content","title":"Th\\u00f4ng tin","alias":"thong-tin","note":"","description":"","published":"1","checked_out":null,"checked_out_time":null,"access":"1","params":"{\\"category_layout\\":\\"\\",\\"image\\":\\"\\",\\"image_alt\\":\\"\\"}","metadesc":"","metakey":"","metadata":"{\\"author\\":\\"\\",\\"robots\\":\\"\\"}","created_user_id":"468","created_time":"2015-08-17 06:32:56","modified_user_id":null,"modified_time":"2015-08-17 06:32:56","hits":"0","language":"*","version":null}', 0),
(13, 5, 1, '', '2015-08-17 06:33:19', 468, 3834, 'ed0104f2154c73eeb191fd0aa455f4a2535530a1', '{"id":5,"asset_id":152,"title":"\\u0110\\u00e0 N\\u1eb5ng Trip- Du l\\u1ecbch k\\u1ebft h\\u1ee3p ch\\u1ee5p \\u1ea3nh (4)","alias":"da-nang-trip-du-lich-ket-hop-chup-anh-4","introtext":"In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis.<br \\/>","fulltext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","state":0,"catid":"8","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:33:19","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(14, 5, 1, '', '2015-08-17 06:33:54', 468, 3459, '94da49d718f135ded0493b3e14a18c0c2287442f', '{"id":5,"asset_id":"152","title":"Mua t\\u00e1c ph\\u1ea9m","alias":"mua-tac-pham","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":1,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:33:54","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-17 06:33:19","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);
INSERT INTO `analk_ucm_history` (`version_id`, `ucm_item_id`, `ucm_type_id`, `version_note`, `save_date`, `editor_user_id`, `character_count`, `sha1_hash`, `version_data`, `keep_forever`) VALUES
(15, 6, 1, '', '2015-08-17 06:34:04', 468, 3427, '709fbc79f1f9e4f4a87f6dd63038e5455712cfe9', '{"id":6,"asset_id":153,"title":"Mua t\\u00e1c ph\\u1ea9m (2)","alias":"mua-tac-pham-2","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":0,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:34:04","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(16, 6, 1, '', '2015-08-17 06:34:21', 468, 3481, '788ec6fbfc309ca573dd83895b590ec2411c5b9f', '{"id":6,"asset_id":"153","title":"B\\u1ea3n quy\\u1ec1n t\\u00e1c ph\\u1ea9m","alias":"ban-quyen-tac-pham","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":1,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:34:21","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-17 06:34:04","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(17, 7, 1, '', '2015-08-17 06:34:26', 468, 3449, 'ac04ce7e5ff78ace35249594c52abac425f1d700', '{"id":7,"asset_id":154,"title":"B\\u1ea3n quy\\u1ec1n t\\u00e1c ph\\u1ea9m (2)","alias":"ban-quyen-tac-pham-2","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":0,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:34:26","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(18, 7, 1, '', '2015-08-17 06:34:44', 468, 3464, 'fd2f68405c7b5a4bbd345976c928c6ffafc48617', '{"id":7,"asset_id":"154","title":"Thanh to\\u00e1n online","alias":"thanh-toan-online","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":1,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:34:44","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-17 06:34:26","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(19, 8, 1, '', '2015-08-17 06:34:48', 468, 3432, '61f83be39ea5e5af8ac619dc51d846e2256dc306', '{"id":8,"asset_id":155,"title":"Thanh to\\u00e1n online (2)","alias":"thanh-toan-online-2","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":0,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:34:48","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-14 08:18:48","publish_down":"","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(20, 8, 1, '', '2015-08-17 06:35:01', 468, 3451, '937b67bd155f05c23f4304a19498770cfdb95389', '{"id":8,"asset_id":"155","title":"Quy \\u0111\\u1ecbnh","alias":"quy-dinh","introtext":"Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.<br \\/><br \\/> In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus. In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.In ipsum lectus, pharetra vel rutrum at, gravida sollicitudin ipsum. Nam id pharetra felis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed feugiat ligula id augue gravida dapibus.","fulltext":"","state":1,"catid":"9","created":"2015-08-14 08:18:48","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:35:01","modified_by":"468","checked_out":"468","checked_out_time":"2015-08-17 06:34:48","publish_up":"2015-08-14 08:18:48","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"images\\\\\\/2.jpg\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":2,"ordering":"0","metakey":"","metadesc":"","access":"1","hits":"0","metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(21, 9, 1, '', '2015-08-17 06:48:53', 468, 2202, '6b18d075a01f93c7b6c3924f1cb78f289b9d1897', '{"id":9,"asset_id":159,"title":"Th\\u00f4ng tin cu\\u1ed1i trang","alias":"thong-tin-cuoi-trang","introtext":"B\\u1ea3n quy\\u1ec1n thu\\u1ed9c v\\u1ec1 H\\u1ed9i Truy\\u1ec1n Th\\u00f4ng S\\u1ed1 Vi\\u1ec7t Nam. Gi\\u1ea5y ph\\u00e9p cung c\\u1ea5p m\\u1ea1ng x\\u00e3 h\\u1ed9i tr\\u1ef1c tuy\\u1ebfn s\\u1ed1 43\\/GXN - TT\\u0110T.<br \\/> Gi\\u1ea5y ph\\u00e9p t\\u1ed5 ch\\u1ee9c thi t\\u00e1c ph\\u1ea9m nhi\\u1ebfp \\u1ea3nh \\"Kho\\u1ea3nh kh\\u1eafc Vi\\u1ec7t Nam\\" s\\u1ed1 152\\/MTNATL-NA ban h\\u00e0nh ng\\u00e0y 05\\/4\\/2013.<br \\/> Ch\\u1ecbu tr\\u00e1ch nhi\\u1ec7m n\\u1ed9i dung: \\u00d4ng Nguy\\u1ec5n L\\u00e2m Thanh - T\\u1ed5ng th\\u01b0 k\\u00fd","fulltext":"","state":1,"catid":"2","created":"2015-08-17 06:48:53","created_by":"468","created_by_alias":"","modified":"2015-08-17 06:48:53","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-08-17 06:48:53","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0),
(22, 10, 1, '', '2015-09-13 17:57:45', 468, 1871, 'bec0c5d8b9c940799de737c76925a412fed0ce02', '{"id":10,"asset_id":168,"title":"C\\u00e1m \\u01a1n \\u0111\\u00e3 theo d\\u00f5i","alias":"cam-on-da-theo-doi","introtext":"Ch\\u00fang t\\u00f4i \\u0111\\u00e3 l\\u01b0u email c\\u1ee7a b\\u1ea1n, c\\u00e1m \\u01a1n b\\u1ea1n \\u0111\\u00e3 theo d\\u00f5i<br \\/><br \\/>Kho\\u1ea3nh kh\\u1eafc Vi\\u1ec7t Nam","fulltext":"","state":1,"catid":"2","created":"2015-09-13 17:57:45","created_by":"468","created_by_alias":"","modified":"2015-09-13 17:57:45","modified_by":null,"checked_out":null,"checked_out_time":null,"publish_up":"2015-09-13 17:57:45","publish_down":"0000-00-00 00:00:00","images":"{\\"image_intro\\":\\"\\",\\"float_intro\\":\\"\\",\\"image_intro_alt\\":\\"\\",\\"image_intro_caption\\":\\"\\",\\"image_fulltext\\":\\"\\",\\"float_fulltext\\":\\"\\",\\"image_fulltext_alt\\":\\"\\",\\"image_fulltext_caption\\":\\"\\"}","urls":"{\\"urla\\":false,\\"urlatext\\":\\"\\",\\"targeta\\":\\"\\",\\"urlb\\":false,\\"urlbtext\\":\\"\\",\\"targetb\\":\\"\\",\\"urlc\\":false,\\"urlctext\\":\\"\\",\\"targetc\\":\\"\\"}","attribs":"{\\"show_title\\":\\"\\",\\"link_titles\\":\\"\\",\\"show_tags\\":\\"\\",\\"show_intro\\":\\"\\",\\"info_block_position\\":\\"\\",\\"show_category\\":\\"\\",\\"link_category\\":\\"\\",\\"show_parent_category\\":\\"\\",\\"link_parent_category\\":\\"\\",\\"show_author\\":\\"\\",\\"link_author\\":\\"\\",\\"show_create_date\\":\\"\\",\\"show_modify_date\\":\\"\\",\\"show_publish_date\\":\\"\\",\\"show_item_navigation\\":\\"\\",\\"show_icons\\":\\"\\",\\"show_print_icon\\":\\"\\",\\"show_email_icon\\":\\"\\",\\"show_vote\\":\\"\\",\\"show_hits\\":\\"\\",\\"show_noauth\\":\\"\\",\\"urls_position\\":\\"\\",\\"alternative_readmore\\":\\"\\",\\"article_layout\\":\\"\\",\\"show_publishing_options\\":\\"\\",\\"show_article_options\\":\\"\\",\\"show_urls_images_backend\\":\\"\\",\\"show_urls_images_frontend\\":\\"\\"}","version":1,"ordering":null,"metakey":"","metadesc":"","access":"1","hits":null,"metadata":"{\\"robots\\":\\"\\",\\"author\\":\\"\\",\\"rights\\":\\"\\",\\"xreference\\":\\"\\"}","featured":"0","language":"*","xreference":""}', 0);

-- --------------------------------------------------------

--
-- Table structure for table `analk_updates`
--

CREATE TABLE IF NOT EXISTS `analk_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=51 ;

--
-- Dumping data for table `analk_updates`
--

INSERT INTO `analk_updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES
(1, 3, 0, 'Hebrew', '', 'pkg_he-IL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/he-IL_details.xml', '', ''),
(2, 3, 0, 'EnglishAU', '', 'pkg_en-AU', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/en-AU_details.xml', '', ''),
(3, 3, 0, 'EnglishUS', '', 'pkg_en-US', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/en-US_details.xml', '', ''),
(4, 3, 0, 'Hungarian', '', 'pkg_hu-HU', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/hu-HU_details.xml', '', ''),
(5, 3, 0, 'Afrikaans', '', 'pkg_af-ZA', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/af-ZA_details.xml', '', ''),
(6, 3, 0, 'Arabic Unitag', '', 'pkg_ar-AA', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/ar-AA_details.xml', '', ''),
(7, 3, 0, 'Belarusian', '', 'pkg_be-BY', 'package', '', 0, '3.2.1.1', '', 'http://update.joomla.org/language/details3/be-BY_details.xml', '', ''),
(8, 3, 0, 'Bulgarian', '', 'pkg_bg-BG', 'package', '', 0, '3.3.0.1', '', 'http://update.joomla.org/language/details3/bg-BG_details.xml', '', ''),
(9, 3, 0, 'Catalan', '', 'pkg_ca-ES', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/ca-ES_details.xml', '', ''),
(10, 3, 0, 'Chinese Simplified', '', 'pkg_zh-CN', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/zh-CN_details.xml', '', ''),
(11, 3, 0, 'Croatian', '', 'pkg_hr-HR', 'package', '', 0, '3.4.3.2', '', 'http://update.joomla.org/language/details3/hr-HR_details.xml', '', ''),
(12, 3, 0, 'Czech', '', 'pkg_cs-CZ', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/cs-CZ_details.xml', '', ''),
(13, 3, 0, 'Danish', '', 'pkg_da-DK', 'package', '', 0, '3.4.2.2', '', 'http://update.joomla.org/language/details3/da-DK_details.xml', '', ''),
(14, 3, 0, 'Dutch', '', 'pkg_nl-NL', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/nl-NL_details.xml', '', ''),
(15, 3, 0, 'Estonian', '', 'pkg_et-EE', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/et-EE_details.xml', '', ''),
(16, 3, 0, 'Italian', '', 'pkg_it-IT', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/it-IT_details.xml', '', ''),
(17, 3, 0, 'Khmer', '', 'pkg_km-KH', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/km-KH_details.xml', '', ''),
(18, 3, 0, 'Korean', '', 'pkg_ko-KR', 'package', '', 0, '3.4.3.4', '', 'http://update.joomla.org/language/details3/ko-KR_details.xml', '', ''),
(19, 3, 0, 'Latvian', '', 'pkg_lv-LV', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/lv-LV_details.xml', '', ''),
(20, 3, 0, 'Macedonian', '', 'pkg_mk-MK', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/mk-MK_details.xml', '', ''),
(21, 3, 0, 'Norwegian Bokmal', '', 'pkg_nb-NO', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/nb-NO_details.xml', '', ''),
(22, 3, 0, 'Norwegian Nynorsk', '', 'pkg_nn-NO', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/nn-NO_details.xml', '', ''),
(23, 3, 0, 'Persian', '', 'pkg_fa-IR', 'package', '', 0, '3.4.3.2', '', 'http://update.joomla.org/language/details3/fa-IR_details.xml', '', ''),
(24, 3, 0, 'Polish', '', 'pkg_pl-PL', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/pl-PL_details.xml', '', ''),
(25, 3, 0, 'Portuguese', '', 'pkg_pt-PT', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/pt-PT_details.xml', '', ''),
(26, 3, 0, 'Russian', '', 'pkg_ru-RU', 'package', '', 0, '3.4.1.3', '', 'http://update.joomla.org/language/details3/ru-RU_details.xml', '', ''),
(27, 3, 0, 'Slovak', '', 'pkg_sk-SK', 'package', '', 0, '3.4.1.2', '', 'http://update.joomla.org/language/details3/sk-SK_details.xml', '', ''),
(28, 3, 0, 'Swedish', '', 'pkg_sv-SE', 'package', '', 0, '3.4.1.3', '', 'http://update.joomla.org/language/details3/sv-SE_details.xml', '', ''),
(29, 3, 0, 'Syriac', '', 'pkg_sy-IQ', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/sy-IQ_details.xml', '', ''),
(30, 3, 0, 'Tamil', '', 'pkg_ta-IN', 'package', '', 0, '3.4.3.2', '', 'http://update.joomla.org/language/details3/ta-IN_details.xml', '', ''),
(31, 3, 0, 'Thai', '', 'pkg_th-TH', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/th-TH_details.xml', '', ''),
(32, 3, 0, 'Turkish', '', 'pkg_tr-TR', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/tr-TR_details.xml', '', ''),
(33, 3, 0, 'Ukrainian', '', 'pkg_uk-UA', 'package', '', 0, '3.3.3.15', '', 'http://update.joomla.org/language/details3/uk-UA_details.xml', '', ''),
(34, 3, 0, 'Uyghur', '', 'pkg_ug-CN', 'package', '', 0, '3.3.0.1', '', 'http://update.joomla.org/language/details3/ug-CN_details.xml', '', ''),
(35, 3, 0, 'Albanian', '', 'pkg_sq-AL', 'package', '', 0, '3.1.1.1', '', 'http://update.joomla.org/language/details3/sq-AL_details.xml', '', ''),
(36, 3, 0, 'Hindi', '', 'pkg_hi-IN', 'package', '', 0, '3.3.6.1', '', 'http://update.joomla.org/language/details3/hi-IN_details.xml', '', ''),
(37, 3, 0, 'Portuguese Brazil', '', 'pkg_pt-BR', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/pt-BR_details.xml', '', ''),
(38, 3, 0, 'Serbian Latin', '', 'pkg_sr-YU', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/sr-YU_details.xml', '', ''),
(39, 3, 0, 'Spanish', '', 'pkg_es-ES', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/es-ES_details.xml', '', ''),
(40, 3, 0, 'Bosnian', '', 'pkg_bs-BA', 'package', '', 0, '3.4.1.1', '', 'http://update.joomla.org/language/details3/bs-BA_details.xml', '', ''),
(41, 3, 0, 'Serbian Cyrillic', '', 'pkg_sr-RS', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/sr-RS_details.xml', '', ''),
(42, 3, 0, 'Bahasa Indonesia', '', 'pkg_id-ID', 'package', '', 0, '3.3.0.2', '', 'http://update.joomla.org/language/details3/id-ID_details.xml', '', ''),
(43, 3, 0, 'Finnish', '', 'pkg_fi-FI', 'package', '', 0, '3.4.2.1', '', 'http://update.joomla.org/language/details3/fi-FI_details.xml', '', ''),
(44, 3, 0, 'Swahili', '', 'pkg_sw-KE', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/sw-KE_details.xml', '', ''),
(45, 3, 0, 'Montenegrin', '', 'pkg_srp-ME', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/srp-ME_details.xml', '', ''),
(46, 3, 0, 'EnglishCA', '', 'pkg_en-CA', 'package', '', 0, '3.3.6.1', '', 'http://update.joomla.org/language/details3/en-CA_details.xml', '', ''),
(47, 3, 0, 'FrenchCA', '', 'pkg_fr-CA', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/fr-CA_details.xml', '', ''),
(48, 3, 0, 'Welsh', '', 'pkg_cy-GB', 'package', '', 0, '3.3.0.2', '', 'http://update.joomla.org/language/details3/cy-GB_details.xml', '', ''),
(49, 3, 0, 'Sinhala', '', 'pkg_si-LK', 'package', '', 0, '3.3.1.1', '', 'http://update.joomla.org/language/details3/si-LK_details.xml', '', ''),
(50, 3, 0, 'Dari Persian', '', 'pkg_prs-AF', 'package', '', 0, '3.4.3.1', '', 'http://update.joomla.org/language/details3/prs-AF_details.xml', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_update_sites`
--

CREATE TABLE IF NOT EXISTS `analk_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=12 ;

--
-- Dumping data for table `analk_update_sites`
--

INSERT INTO `analk_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES
(1, 'Joomla! Core', 'collection', 'http://update.joomla.org/core/list.xml', 1, 1438536693, ''),
(2, 'Joomla! Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1438536693, ''),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist_3.xml', 1, 1438536692, ''),
(4, 'Joomla! Update Component Update Site', 'extension', 'http://update.joomla.org/core/extensions/com_joomlaupdate.xml', 1, 1438536692, ''),
(5, 'Articles Anywhere', 'extension', 'http://download.nonumber.nl/updates.php?e=articlesanywhere&type=.xml', 1, 1438536692, ''),
(6, 'Modules Anywhere', 'extension', 'http://download.nonumber.nl/updates.php?e=modulesanywhere&type=.xml', 1, 1438536692, ''),
(7, 'JoomGallery Update Service', 'collection', 'http://www.en.joomgallery.net/components/com_newversion/xml/extensions3.xml', 1, 0, ''),
(9, 'JoomGallery Update Service', 'collection', 'http://www.en.joomgallery.net/components/com_newversion/xml/extensions2.xml', 1, 0, ''),
(11, 'JoomGallery Update Service', 'collection', 'http://www.joomgallery.net/components/com_newversion/xml/extensions3.xml', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_update_sites_extensions`
--

CREATE TABLE IF NOT EXISTS `analk_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Dumping data for table `analk_update_sites_extensions`
--

INSERT INTO `analk_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600),
(3, 10002),
(4, 28),
(5, 10005),
(5, 10006),
(6, 10008),
(6, 10009),
(7, 10010),
(9, 10014),
(11, 10043);

-- --------------------------------------------------------

--
-- Table structure for table `analk_usergroups`
--

CREATE TABLE IF NOT EXISTS `analk_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `analk_usergroups`
--

INSERT INTO `analk_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 18, 'Public'),
(2, 1, 8, 15, 'Registered'),
(3, 2, 9, 14, 'Author'),
(4, 3, 10, 13, 'Editor'),
(5, 4, 11, 12, 'Publisher'),
(6, 1, 4, 7, 'Manager'),
(7, 6, 5, 6, 'Administrator'),
(8, 1, 16, 17, 'Super Users'),
(9, 1, 2, 3, 'Guest');

-- --------------------------------------------------------

--
-- Table structure for table `analk_users`
--

CREATE TABLE IF NOT EXISTS `analk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  `balance` int(11) NOT NULL DEFAULT '0',
  `status` text NOT NULL,
  `hits` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `push_buy_gallery` int(11) NOT NULL,
  `push_news` int(11) NOT NULL,
  `gcm_regid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=487 ;

--
-- Dumping data for table `analk_users`
--

INSERT INTO `analk_users` (`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`, `balance`, `status`, `hits`, `phone`, `push_buy_gallery`, `push_news`, `gcm_regid`) VALUES
(468, 'Super User', 'admin', 'nttrung211@gmail.com', '$2y$10$oT0XHTx1CBuK2fsHgZkICeE4JgHRRXFO5oFDR9cd59VNVGiRNcaPe', 0, 1, '2015-08-02 16:50:48', '2015-09-15 03:23:42', '0', '', '0000-00-00 00:00:00', 0, '', '', 0, 0, '', 0, '', 0, 0, ''),
(469, 'Trung aaa', 'nttrung211@yahoo.com', 'nttrung211@yahoo.com', '$2y$10$vQnsdTTfHByqjvj9z.IcnOxl.DdwSH0oD0lAfxOBpG2AfFZ6NfOEO', 0, 0, '2015-08-10 02:33:25', '2015-09-15 03:24:06', '', '{"editor":"","timezone":"","language":"","admin_style":"","admin_language":"","helpsite":""}', '0000-00-00 00:00:00', 0, '', '', 0, 1000000, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse at scelerisque tellus. Vivamus posuere erat nisl, in ullamcorper orci gravida et.', 11, '0909702522', 0, 0, ''),
(470, 'Nguyen Thanh Trung', 'trung@mywebcreations.dk', 'trung@mywebcreations.dk', '$2y$10$Fj/czzLYz6hl9YyegnemjeXyc4tuobVObjlSz11okJIYs1PfZ99K2', 0, 0, '2015-08-24 04:15:16', '2015-09-09 03:55:27', '', '{}', '0000-00-00 00:00:00', 0, '', '', 0, 0, '', 30, '0909702522', 0, 0, ''),
(485, 'thai nguyen', 'thai', 'thai@gmail.com', '$2y$10$FtYI96ETnKx8FR5HS5zEIOVdwtVqJ7DaDIa0t9nai6KaftidICRgC', 0, 0, '2015-09-11 04:01:22', '2015-09-11 04:14:46', '0', '{}', '0000-00-00 00:00:00', 0, '0', '0', 0, 0, '', 0, '0972440553', 1, 1, ''),
(486, 'Thai Nguyen', 'thaind', 'thaind@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0', '', '0000-00-00 00:00:00', 0, '0', '0', 0, 0, '', 0, '095638526', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `analk_users_gsm`
--

CREATE TABLE IF NOT EXISTS `analk_users_gsm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gcm_id` text NOT NULL,
  `device_id` text NOT NULL,
  `login_state` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `analk_users_gsm`
--

INSERT INTO `analk_users_gsm` (`id`, `user_id`, `gcm_id`, `device_id`, `login_state`) VALUES
(1, 100, 'weryertyertyert', '456345ERYR', 1),
(2, 100, 'weryertyertyertdfhdfghdfghdfghdfghdfg', '456345ERYRere', 1),
(3, 485, '', '72fadf771dbac15a', 1),
(4, 485, '', 'b77d36b4360735b4', 1),
(5, 486, '', '72fadf771dbac15a', 1);

-- --------------------------------------------------------

--
-- Table structure for table `analk_user_keys`
--

CREATE TABLE IF NOT EXISTS `analk_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) NOT NULL,
  `uastring` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_user_notes`
--

CREATE TABLE IF NOT EXISTS `analk_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `analk_user_profiles`
--

CREATE TABLE IF NOT EXISTS `analk_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

--
-- Dumping data for table `analk_user_profiles`
--

INSERT INTO `analk_user_profiles` (`user_id`, `profile_key`, `profile_value`, `ordering`) VALUES
(469, 'profilecover.file', '17d08e20666dddf3f7ff9401bf086e8b67eda881.jpg', 1),
(469, 'profilepicture.file', '3b663e70c8cccc70d7cc99a5efc8a14e4ef8334e.jpg', 1),
(470, 'profilecover.file', '61aa07246d36bb17cc61eb9712d27feaaca0433f.jpg', 1),
(470, 'profilepicture.file', 'fe8cfcd6be0d3fafad212db299385ca87f8ec54d.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `analk_user_usergroup_map`
--

CREATE TABLE IF NOT EXISTS `analk_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `analk_user_usergroup_map`
--

INSERT INTO `analk_user_usergroup_map` (`user_id`, `group_id`) VALUES
(468, 8),
(469, 2),
(470, 2),
(485, 2),
(486, 2);

-- --------------------------------------------------------

--
-- Table structure for table `analk_viewlevels`
--

CREATE TABLE IF NOT EXISTS `analk_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `analk_viewlevels`
--

INSERT INTO `analk_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 2, '[6,2,8]'),
(3, 'Special', 3, '[6,3,8]'),
(5, 'Guest', 1, '[9]'),
(6, 'Super Users', 4, '[8]');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
